#!/usr/bin/env python3
# ABOUTME: Decodes pre-RIFF CorelDRAW 2.x drawings ("WL"/Waldo .CDR) into a text summary and an SVG render.
# ABOUTME: Usage: cdr_waldo.py IN.CDR OUT_BASE  -> OUT_BASE.txt, OUT_BASE.svg; or --list LIST SRC_ROOT OUT_ROOT.

import math
import os
import struct
import sys
from collections import Counter
from xml.sax.saxutils import escape

CHUNK_NAMES = {0: 'rectangle', 1: 'ellipse', 2: 'curve', 3: 'text', 4: 'bitmap'}
ALIGN_NAMES = {0: 'none', 1: 'left', 2: 'center', 3: 'right'}
# Corel WFN font files -> closest generic SVG families (Toronto is Corel's Times clone)
FONT_FAMILIES = {
    'toronto': "'Times New Roman', Times, serif",
    'avalon': "'ITC Avant Garde Gothic', 'URW Gothic', sans-serif",
    'brunswik': "'Century Schoolbook', 'C059', serif",
    'swz': "Helvetica, Arial, sans-serif",
}


class Reader:
    def __init__(self, data):
        self.d = data

    def u8(self, o):
        return self.d[o]

    def u16(self, o):
        return struct.unpack_from('<H', self.d, o)[0]

    def s16(self, o):
        return struct.unpack_from('<h', self.d, o)[0]

    def u32(self, o):
        return struct.unpack_from('<I', self.d, o)[0]

    def fixed(self, o):
        # 16.16 fixed point, signed integer part
        v = self.u32(o)
        ip = (v >> 16) & 0xffff
        if ip >= 0x8000:
            ip -= 0x10000
        return ip + (v & 0xffff) / 65536.0


def mat_mul(a, b):
    # affine matrices as (a, b, c, d, e, f): x' = a*x + b*y + c ; y' = d*x + e*y + f
    return (a[0] * b[0] + a[1] * b[3], a[0] * b[1] + a[1] * b[4], a[0] * b[2] + a[1] * b[5] + a[2],
            a[3] * b[0] + a[4] * b[3], a[3] * b[1] + a[4] * b[4], a[3] * b[2] + a[4] * b[5] + a[5])


def mat_apply(m, x, y):
    return (m[0] * x + m[1] * y + m[2], m[3] * x + m[4] * y + m[5])


IDENTITY = (1.0, 0.0, 0.0, 0.0, 1.0, 0.0)


def cmyk_to_rgb(c, m, y, k):
    c, m, y, k = [min(max(v, 0), 100) / 100.0 for v in (c, m, y, k)]
    return tuple(int(round(255 * (1 - v) * (1 - k))) for v in (c, m, y))


def color_desc(model, value):
    b = [(value >> (8 * i)) & 0xff for i in range(4)]
    if model == 1:
        return 'CMYK(%d,%d,%d,%d)' % tuple(b), '#%02x%02x%02x' % cmyk_to_rgb(*b)
    if model == 0:
        idx = b[0] | (b[1] << 8)
        tint = b[2] | (b[3] << 8)
        grey = int(round(255 * (1 - min(tint, 100) / 100.0 * 0.6)))
        return 'Pantone#%d tint %d%%' % (idx, tint), '#%02x%02x%02x' % (grey, grey, grey)
    return 'model%d:%08x' % (model, value), '#808080'


class WaldoDoc:
    def __init__(self, path):
        self.path = path
        self.data = open(path, 'rb').read()
        self.r = Reader(self.data)
        self.warnings = []
        self.parse()

    def warn(self, msg):
        if msg not in self.warnings:
            self.warnings.append(msg)

    def parse(self):
        r = self.r
        if self.data[:2] != b'WL':
            raise ValueError('not a CorelDRAW WL file')
        self.version = r.u8(2)
        self.offsets = [r.u32(4 + 4 * i) for i in range(8)] + [r.u32(0x25 + 4 * i) for i in range(10)]
        self.parse_page()
        self.parse_thumbnail()
        self.parse_fonts()
        self.parse_index()
        self.walk()

    def parse_page(self):
        r = self.r
        o = self.offsets[0]
        self.page_flag = r.u8(o + 1)
        x0, y0, x1, y1 = (r.s16(o + 2 + 2 * i) for i in range(4))
        self.page = (min(x0, x1), min(y0, y1), max(x0, x1), max(y0, y1))
        self.page_w = self.page[2] - self.page[0]
        self.page_h = self.page[3] - self.page[1]

    def parse_thumbnail(self):
        r = self.r
        o = self.offsets[6]
        self.thumb = None
        if not o or o + 16 > len(self.data):
            return
        w, h, wb, planes, bpp = r.u16(o + 4), r.u16(o + 6), r.u16(o + 8), r.u8(o + 10), r.u8(o + 11)
        start = o + 16
        if 0 < w < 1024 and 0 < h < 1024 and planes == 1 and bpp == 1 and start + wb * h <= len(self.data):
            self.thumb = (w, h, wb, self.data[start:start + wb * h])

    def parse_fonts(self):
        r = self.r
        o = self.offsets[2]
        self.fonts = {}
        if not o:
            return
        n = r.u16(o)
        for i in range(n):
            e = o + 2 + 84 * i
            fid = r.u16(e)
            raw = self.data[e + 4:e + 84]
            name = raw.split(b'\0', 1)[0].decode('latin-1')
            self.fonts[fid] = name

    def parse_index(self):
        r = self.r
        self.records = {}
        self.type_counts = Counter()
        for base in (self.offsets[3], self.offsets[5], self.offsets[11]):
            if not base or base + 2 > len(self.data):
                continue
            n = r.u16(base)
            p = base + 2
            for _ in range(n):
                if p + 9 > len(self.data):
                    self.warn('index truncated at 0x%x' % p)
                    break
                t, rid, off = r.u8(p), r.u32(p + 1), r.u32(p + 5)
                p += 9
                self.records[(t, rid)] = off
                self.type_counts[t] += 1

    def node(self, nid):
        r = self.r
        off = self.records.get((1, nid))
        if off is None:
            return None
        if r.u32(off) != 0x18:
            self.warn('node 0x%x has unexpected length' % nid)
        bb = [r.s16(off + 18 + 2 * i) for i in range(4)]
        return {
            'id': nid, 'next': r.u16(off + 4), 'prev': r.u16(off + 6), 'child': r.u16(off + 8),
            'parent': r.u16(off + 10), 'more': r.u16(off + 16),
            'bbox': (min(bb[0], bb[2]), min(bb[1], bb[3]), max(bb[0], bb[2]), max(bb[1], bb[3])),
            'flags': r.u16(off + 26),
        }

    def more_transform(self, mid):
        r = self.r
        off = self.records.get((7, mid))
        if off is None:
            self.warn('missing transform record 0x%x' % mid)
            return IDENTITY
        if r.u32(off) != 0x3a:
            self.warn('transform record 0x%x has length 0x%x (only the first matrix is used)' % (mid, r.u32(off)))
        p = off + 0x26
        v = [r.fixed(p + 4 * i) for i in range(6)]
        return (v[0], v[1], v[2], v[3], v[4], v[5])

    def walk(self):
        self.objects = []
        self.counts = Counter()
        self.groups = 0
        self.wrapped = 0
        root = self.node(0)
        if root is None:
            raise ValueError('no root node')
        self.root_bbox = root['bbox']
        visited = set()
        self.tree = self._walk_children(root, IDENTITY, 0, visited)

    def _walk_children(self, parent, mat, depth, visited):
        # children are stored front-most first
        children = []
        cid = parent['child']
        while True:
            n = self.node(cid)
            if n is None or n['id'] in visited:
                if n is None:
                    self.warn('dangling node reference 0x%x' % cid)
                break
            visited.add(n['id'])
            m = mat
            if n['more']:
                m = mat_mul(mat, self.more_transform(n['more']))
            if n['flags'] & 0x01:
                self.groups += 1
                grp = {'kind': 'group', 'depth': depth, 'node': n, 'mat': m}
                self.objects.append(grp)
                children.append(grp)
                grp['children'] = self._walk_children(n, m, depth + 1, visited)
            else:
                obj = self.read_object(n, m, depth)
                if obj:
                    self.objects.append(obj)
                    children.append(obj)
            if not n['next']:
                break
            cid = n['next']
        return children

    def read_color(self, o):
        return self.r.u8(o), self.r.u32(o + 1)

    def read_outline(self, o):
        r = self.r
        ltype = r.u8(o)
        width = r.s16(o + 1)
        model, value = self.read_color(o + 7)
        ndash = r.u8(o + 19)
        dashes = list(self.data[o + 20:o + 20 + min(ndash, 10)])
        join = r.u16(o + 30)
        caps = r.u16(o + 32)
        return {'type': ltype, 'width': width, 'color': (model, value), 'dashes': dashes,
                'join': join, 'caps': caps}

    def read_fill(self, o):
        r = self.r
        ftype = r.u8(o)
        f = {'type': ftype}
        if ftype == 1:
            f['color'] = self.read_color(o + 1)
        elif ftype in (2, 4):
            f['angle'] = r.s16(o + 1) / 10.0
            f['color'] = self.read_color(o + 3)
            f['color2'] = self.read_color(o + 8)
        elif ftype not in (0,):
            self.warn('fill type %d approximated as grey' % ftype)
        return f

    def read_object(self, n, mat, depth):
        r = self.r
        off = self.records.get((2, n['child']))
        if off is None:
            self.warn('node 0x%x references missing object 0x%x' % (n['id'], n['child']))
            return None
        length = r.u32(off)
        b = off + 4
        end = b + length
        x0, y0 = r.s16(b), r.s16(b + 2)
        v = [r.fixed(b + 4 + 4 * i) for i in range(6)]
        local = (v[0], v[1], x0 + v[2], v[3], v[4], y0 + v[5])
        m = mat_mul(mat, local)
        ctype = r.u8(b + 28)
        so, oo, fo = r.u16(b + 29), r.u16(b + 31), r.u16(b + 33)
        obj = {'kind': CHUNK_NAMES.get(ctype, 'chunk%d' % ctype), 'depth': depth, 'node': n, 'mat': m,
               'outline': self.read_outline(b + oo) if oo else None,
               'fill': self.read_fill(b + fo) if fo else None}
        self.counts[obj['kind']] += 1
        s = b + so
        if ctype == 0:
            w, h, rad = r.s16(s), r.s16(s + 2), r.s16(s + 4)
            obj['rect'] = (w, h, rad)
            obj['path'] = rect_path(w, h, rad)
        elif ctype == 1:
            w, h, a1, a2, pie = r.s16(s), r.s16(s + 2), r.s16(s + 4), r.s16(s + 6), r.u16(s + 8)
            obj['ellipse'] = (w, h, a1 / 10.0, a2 / 10.0, pie)
            obj['path'] = ellipse_path(w, h, a1 / 10.0, a2 / 10.0, pie)
        elif ctype == 2:
            cnt = r.u16(s)
            maxcnt = max(0, (end - (s + 4)) // 5)
            if cnt > maxcnt:
                self.warn('curve 0x%x point count %d clipped to %d' % (n['id'], cnt, maxcnt))
                cnt = maxcnt
            pts = [(r.s16(s + 4 + 4 * i), r.s16(s + 6 + 4 * i)) for i in range(cnt)]
            types = list(self.data[s + 4 + 4 * cnt:s + 4 + 5 * cnt])
            obj['npoints'] = cnt
            obj['path'] = curve_path(pts, types)
        elif ctype == 3:
            obj['text'] = self.read_text(s, end)
        elif ctype == 4:
            w, h = r.s16(s), r.s16(s + 2)
            obj['bitmap'] = (w, h, r.u16(s + 14))
            obj['path'] = rect_path(w, h, 0)
        else:
            self.warn('unknown object chunk type %d' % ctype)
        self.fix_wrap(obj)
        return obj

    def fix_wrap(self, obj):
        # transform offsets are 16.16 values whose integer part can wrap; realign with the stored bbox
        m = obj['mat']
        if 'path' in obj:
            pb = path_bbox(transform_path(obj['path'], m))
            if pb is None:
                return
            cx, cy = (pb[0] + pb[2]) / 2.0, (pb[1] + pb[3]) / 2.0
        else:
            cx, cy = mat_apply(m, 0, 0)
        nb = obj['node']['bbox']
        kx = round(((nb[0] + nb[2]) / 2.0 - cx) / 65536.0)
        ky = round(((nb[1] + nb[3]) / 2.0 - cy) / 65536.0)
        if kx or ky:
            obj['mat'] = (m[0], m[1], m[2] + kx * 65536, m[3], m[4], m[5] + ky * 65536)
            self.wrapped += 1

    def read_text(self, s, end):
        r = self.r
        n = r.u16(s + 0x1f)
        maxn = max(0, (end - (s + 0x24) + 1) // 2)
        if n > maxn:
            self.warn('text char count %d clipped to %d' % (n, maxn))
            n = maxn
        # characters are 2-byte slots; only the low byte carries the code (the last slot may be cut short)
        chars = bytes(self.data[s + 0x24 + 2 * i] for i in range(n))
        return {'font': r.u16(s), 'style': r.u8(s + 2), 'size': r.u16(s + 3),
                'spacing': (r.u16(s + 7), r.u16(s + 9), r.u16(s + 11)),
                'align': r.u16(s + 0x15), 'string': chars.decode('cp1252', errors='replace')}


def rect_path(w, h, rad):
    rad = abs(rad)
    if rad <= 0:
        return [('M', [(0, 0)]), ('L', [(0, h)]), ('L', [(w, h)]), ('L', [(w, 0)]), ('Z', [])]
    sx = 1 if w >= 0 else -1
    sy = 1 if h >= 0 else -1
    k = 0.5523 * rad
    pts = []
    pts.append(('M', [(sx * rad, 0)]))
    pts.append(('L', [(w - sx * rad, 0)]))
    pts.append(('C', [(w - sx * rad + sx * k, 0), (w, sy * rad - sy * k), (w, sy * rad)]))
    pts.append(('L', [(w, h - sy * rad)]))
    pts.append(('C', [(w, h - sy * rad + sy * k), (w - sx * rad + sx * k, h), (w - sx * rad, h)]))
    pts.append(('L', [(sx * rad, h)]))
    pts.append(('C', [(sx * rad - sx * k, h), (0, h - sy * rad + sy * k), (0, h - sy * rad)]))
    pts.append(('L', [(0, sy * rad)]))
    pts.append(('C', [(0, sy * rad - sy * k), (sx * rad - sx * k, 0), (sx * rad, 0)]))
    pts.append(('Z', []))
    return pts


def is_closed_ellipse(e):
    w, h, a1, a2, pie = e
    return bool(pie) or abs(a2 - a1) % 360 < 1e-6


def ellipse_path(w, h, a1, a2, pie):
    cx, cy = w / 2.0, h / 2.0
    rx, ry = abs(cx), abs(cy)
    full = abs(a1 - a2) < 1e-6 or abs(a2 - a1) % 360 < 1e-6
    start = math.radians(a1)
    stop = math.radians(a2) if not full else start + 2 * math.pi
    while stop <= start:
        stop += 2 * math.pi
    segs = max(1, int(math.ceil((stop - start) / (math.pi / 2) - 1e-9)))
    step = (stop - start) / segs
    k = 4.0 / 3.0 * math.tan(step / 4.0)

    def pt(a):
        return (cx + rx * math.cos(a), cy + ry * math.sin(a))

    def der(a):
        return (-rx * math.sin(a), ry * math.cos(a))

    path = [('M', [pt(start)])]
    a = start
    for _ in range(segs):
        b = a + step
        p0, p3 = pt(a), pt(b)
        d0, d3 = der(a), der(b)
        path.append(('C', [(p0[0] + k * d0[0], p0[1] + k * d0[1]), (p3[0] - k * d3[0], p3[1] - k * d3[1]), p3]))
        a = b
    if full:
        path.append(('Z', []))
    elif pie:
        path.append(('L', [(cx, cy)]))
        path.append(('Z', []))
    return path


def curve_path(pts, types):
    # node type bits: 0x40|0x80 select move/line/curve-end/control, 0x08 marks a closed subpath
    path = []
    ctrl = []
    for (x, y), t in zip(pts, types):
        kind = t & 0xc0
        closed = bool(t & 0x08)
        if kind == 0x00:
            ctrl = []
            path.append(('M', [(x, y)]))
        elif kind == 0x40:
            ctrl = []
            path.append(('L', [(x, y)]))
            if closed:
                path.append(('Z', []))
        elif kind == 0x80:
            if len(ctrl) >= 2:
                path.append(('C', [ctrl[0], ctrl[1], (x, y)]))
            else:
                path.append(('L', [(x, y)]))
            ctrl = []
            if closed:
                path.append(('Z', []))
        else:
            ctrl.append((x, y))
    return path


def transform_path(path, m):
    return [(op, [mat_apply(m, x, y) for x, y in pts]) for op, pts in path]


def path_bbox(path):
    xs = [p[0] for _, pts in path for p in pts]
    ys = [p[1] for _, pts in path for p in pts]
    if not xs:
        return None
    return (min(xs), min(ys), max(xs), max(ys))


class SvgWriter:
    def __init__(self, doc):
        self.doc = doc
        self.left = doc.page[0]
        self.top = doc.page[3]

    def xy(self, x, y):
        return (x - self.left, self.top - y)

    def fmt(self, v):
        s = '%.1f' % v
        return s[:-2] if s.endswith('.0') else s

    def path_d(self, path):
        out = []
        for op, pts in path:
            coords = ' '.join('%s,%s' % tuple(self.fmt(c) for c in self.xy(*p)) for p in pts)
            out.append(op + coords)
        return ' '.join(out)

    def style(self, obj):
        fill = obj.get('fill')
        if obj['kind'] == 'ellipse' and not is_closed_ellipse(obj['ellipse']):
            # open arcs keep their fill attribute but are drawn unfilled
            fill = None
        outl = obj.get('outline')
        attrs = []
        if fill and fill['type'] == 1:
            attrs.append('fill="%s"' % color_desc(*fill['color'])[1])
        elif fill and fill['type'] in (2, 4):
            attrs.append('fill="%s"' % color_desc(*fill['color'])[1])
        elif fill and fill['type'] not in (0,):
            attrs.append('fill="#c0c0c0"')
        else:
            attrs.append('fill="none"')
        if outl and outl['type'] in (1, 2) and outl['width'] >= 0:
            w = max(outl['width'], 3)
            attrs.append('stroke="%s" stroke-width="%s"' % (color_desc(*outl['color'])[1], w))
            if outl['type'] == 2 and outl['dashes']:
                attrs.append('stroke-dasharray="%s"' % ' '.join(str(max(1, d) * w) for d in outl['dashes']))
            attrs.append('stroke-linejoin="%s"' % {0: 'miter', 1: 'round', 2: 'bevel'}.get(outl['join'], 'miter'))
            attrs.append('stroke-linecap="%s"' % {0: 'butt', 1: 'round', 2: 'square'}.get(outl['caps'], 'butt'))
        else:
            attrs.append('stroke="none"')
        return ' '.join(attrs)

    def text_elem(self, obj):
        doc = self.doc
        t = obj['text']
        m = obj['mat']
        # page matrix: flip y and move origin to page top-left; glyphs need a local y flip
        page = (1.0, 0.0, -self.left, 0.0, -1.0, self.top)
        full = mat_mul(mat_mul(page, m), (1.0, 0.0, 0.0, 0.0, -1.0, 0.0))
        a, c, e, b, d, f = full
        fname = doc.fonts.get(t['font'], '')
        family = FONT_FAMILIES.get(os.path.splitext(fname)[0].lower(), 'serif')
        anchor = {2: 'middle', 3: 'end'}.get(t['align'], 'start')
        fill = obj.get('fill')
        color = color_desc(*fill['color'])[1] if fill and fill['type'] in (1, 2, 4) else 'none'
        stroke = ''
        outl = obj.get('outline')
        if outl and outl['type'] in (1, 2):
            stroke = ' stroke="%s" stroke-width="%s"' % (color_desc(*outl['color'])[1], max(outl['width'], 1))
        lines = t['string'].replace('\r\n', '\n').replace('\r', '\n').split('\n')
        lh = t['size'] * (t['spacing'][2] or 100) / 100.0
        parts = ['<text transform="matrix(%.5f %.5f %.5f %.5f %.1f %.1f)" font-family="%s" font-size="%d" '
                 'text-anchor="%s" fill="%s"%s xml:space="preserve">' %
                 (a, b, c, d, e, f, escape(family, {'"': '&quot;'}), t['size'], anchor, color, stroke)]
        for i, line in enumerate(lines):
            parts.append('<tspan x="0" y="%s">%s</tspan>' % (self.fmt(i * lh), escape(line)))
        parts.append('</text>')
        return ''.join(parts)

    def emit(self, children, out):
        # SVG paints later elements on top, so walk the front-to-back list backwards
        for obj in reversed(children):
            if obj['kind'] == 'group':
                out.append('<g id="group-%x">' % obj['node']['id'])
                self.emit(obj['children'], out)
                out.append('</g>')
            elif obj['kind'] == 'text':
                out.append(self.text_elem(obj))
            elif 'path' in obj:
                d = self.path_d(transform_path(obj['path'], obj['mat']))
                if d:
                    out.append('<path d="%s" %s/>' % (d, self.style(obj)))

    def render(self):
        doc = self.doc
        w, h = doc.page_w, doc.page_h
        out = ['<?xml version="1.0" encoding="UTF-8"?>',
               '<svg xmlns="http://www.w3.org/2000/svg" width="%.3fin" height="%.3fin" viewBox="0 0 %d %d">'
               % (w / 1000.0, h / 1000.0, w, h),
               '<title>%s</title>' % escape(os.path.basename(doc.path)),
               '<desc>Decoded from CorelDRAW 2.x (WL) drawing; units 0.001 inch</desc>',
               '<rect x="0" y="0" width="%d" height="%d" fill="#ffffff" stroke="#c0c0c0" stroke-width="5"/>' % (w, h)]
        self.emit(doc.tree, out)
        out.append('</svg>')
        return '\n'.join(out) + '\n'


def inch(v):
    return '%.3f' % (v / 1000.0)


def describe(doc, relname):
    lines = []
    size = len(doc.data)
    orient = 'landscape' if doc.page_w > doc.page_h else 'portrait'
    lines.append('File: %s' % relname)
    lines.append('Format: CorelDRAW 2.x drawing, pre-RIFF "WL" (Waldo) container, version byte 0x%02X (%d)'
                 % (doc.version, doc.version))
    lines.append('File size: %d bytes' % size)
    lines.append('Page: %s x %s in (%s); native units 0.001 in, origin at page centre, y up'
                 % (inch(doc.page_w), inch(doc.page_h), orient))
    rb = doc.root_bbox
    lines.append('Drawing extent (in, page-centred): x %s .. %s, y %s .. %s'
                 % (inch(rb[0]), inch(rb[2]), inch(rb[1]), inch(rb[3])))
    if doc.thumb:
        lines.append('Preview bitmap: %dx%d monochrome' % (doc.thumb[0], doc.thumb[1]))
    lines.append('Record index: %s' % ', '.join('type%d=%d' % kv for kv in sorted(doc.type_counts.items())))
    kinds = ['rectangle', 'ellipse', 'curve', 'text', 'bitmap']
    cnt = ', '.join('%s %d' % (k, doc.counts.get(k, 0)) for k in kinds)
    extra = [k for k in doc.counts if k not in kinds]
    if extra:
        cnt += ', ' + ', '.join('%s %d' % (k, doc.counts[k]) for k in extra)
    lines.append('Objects: groups %d, %s' % (doc.groups, cnt))
    npts = sum(o.get('npoints', 0) for o in doc.objects)
    if npts:
        lines.append('Curve nodes total: %d' % npts)
    fills = Counter()
    outls = Counter()
    colors = Counter()
    for o in doc.objects:
        f = o.get('fill')
        if f is not None:
            fills[{0: 'none', 1: 'solid', 2: 'linear', 4: 'radial', 7: 'pattern', 10: 'full-colour'}
                  .get(f['type'], 'type%d' % f['type'])] += 1
            if 'color' in f:
                colors[color_desc(*f['color'])[0]] += 1
        ol = o.get('outline')
        if ol is not None:
            outls[{0: 'none', 1: 'solid', 2: 'dashed'}.get(ol['type'], 'type%d' % ol['type'])] += 1
            if ol['type']:
                colors[color_desc(*ol['color'])[0]] += 1
    if fills:
        lines.append('Fills: %s' % ', '.join('%s %d' % kv for kv in sorted(fills.items())))
    if outls:
        lines.append('Outlines: %s' % ', '.join('%s %d' % kv for kv in sorted(outls.items())))
    if colors:
        lines.append('Colours used: %s' % ', '.join('%s x%d' % kv for kv in colors.most_common()))
    if doc.fonts:
        lines.append('Fonts: %s' % ', '.join('%s (id %d)' % (v, k) for k, v in sorted(doc.fonts.items())))
    else:
        lines.append('Fonts: none')
    for w in doc.warnings:
        lines.append('Warning: %s' % w)

    texts = [o for o in doc.objects if o['kind'] == 'text']
    lines.append('')
    lines.append('Text strings: %d' % len(texts))
    lines.append('(position = text anchor point in inches from page top-left, x right / y down; '
                 'listed top-to-bottom, left-to-right)')
    rows = []
    for o in texts:
        t = o['text']
        x, y = mat_apply(o['mat'], 0, 0)
        px, py = x - doc.page[0], doc.page[3] - y
        m = o['mat']
        sx = math.hypot(m[0], m[3])
        sy = math.hypot(m[1], m[4])
        rot = math.degrees(math.atan2(m[3], m[0]))
        info = '%s %.1fpt' % (doc.fonts.get(t['font'], 'font%d' % t['font']), t['size'] * 0.072)
        if t['style'] != 1:
            info += ' style=%d' % t['style']
        info += ' align=%s' % ALIGN_NAMES.get(t['align'], t['align'])
        if abs(sx - 1) > 0.01 or abs(sy - 1) > 0.01:
            info += ' scale=%.2fx%.2f' % (sx, sy)
        if abs(rot) > 0.5:
            info += ' rot=%.1f' % rot
        rows.append((round(py / 50.0), px, py, t['string'], info))
    rows.sort(key=lambda r: (r[0], r[1]))
    for _, px, py, s, info in rows:
        shown = s.replace('\r\n', ' | ').replace('\r', ' | ').replace('\n', ' | ')
        lines.append('  (%6s, %6s)  "%s"  [%s]' % (inch(px), inch(py), shown, info))

    lines.append('')
    lines.append('Object tree (stored order = front-most first; bbox in inches from page top-left):')
    for o in doc.objects:
        n = o['node']
        bb = n['bbox']
        box = '%s,%s-%s,%s' % (inch(bb[0] - doc.page[0]), inch(doc.page[3] - bb[3]),
                               inch(bb[2] - doc.page[0]), inch(doc.page[3] - bb[1]))
        desc = o['kind']
        if o['kind'] == 'text':
            desc += ' "%s"' % o['text']['string'].replace('\r\n', ' | ')
        elif o['kind'] == 'curve':
            desc += ' %d nodes' % o['npoints']
        elif o['kind'] == 'ellipse':
            e = o['ellipse']
            desc += ' %sx%s in' % (inch(abs(e[0])), inch(abs(e[1])))
            if not is_closed_ellipse(e) or e[4]:
                desc += ' arc %.1f..%.1f deg%s' % (e[2], e[3], ' pie' if e[4] else '')
        elif o['kind'] == 'rectangle':
            desc += ' %sx%s in' % (inch(abs(o['rect'][0])), inch(abs(o['rect'][1])))
        lines.append('  %s%s [%s]' % ('  ' * o['depth'], desc, box))
    return '\n'.join(lines) + '\n'


def convert(src, out_base, relname):
    doc = WaldoDoc(src)
    with open(out_base + '.txt', 'w', encoding='utf-8', newline='\n') as f:
        f.write(describe(doc, relname))
    with open(out_base + '.svg', 'w', encoding='utf-8', newline='\n') as f:
        f.write(SvgWriter(doc).render())
    return doc


def main(argv):
    if len(argv) == 5 and argv[1] == '--list':
        lst, src_root, out_root = argv[2:5]
        ok = fail = 0
        for rel in open(lst, encoding='utf-8'):
            rel = rel.strip()
            if not rel:
                continue
            out_base = os.path.join(out_root, rel)
            os.makedirs(os.path.dirname(out_base), exist_ok=True)
            try:
                doc = convert(os.path.join(src_root, rel), out_base, rel)
                ok += 1
                print('OK   %s  objects=%d text=%d warnings=%d' % (rel, len(doc.objects), doc.counts.get('text', 0),
                                                                  len(doc.warnings)))
            except Exception as ex:
                fail += 1
                print('FAIL %s: %s' % (rel, ex))
        print('converted %d, failed %d' % (ok, fail))
        return 1 if fail else 0
    if len(argv) == 3:
        convert(argv[1], argv[2], os.path.basename(argv[1]))
        return 0
    print('usage: cdr_waldo.py IN.CDR OUT_BASE | --list LIST SRC_ROOT OUT_ROOT', file=sys.stderr)
    return 2


if __name__ == '__main__':
    sys.exit(main(sys.argv))
