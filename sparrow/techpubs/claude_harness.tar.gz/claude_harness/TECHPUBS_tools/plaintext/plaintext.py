# ABOUTME: Normalizes the archive's plain-text files to UTF-8 with LF line endings.
# ABOUTME: Maps the few non-ASCII bytes found in them and strips word-processor residue and disk slack.
import os, re, sys

ROOT = '/home/mikro/atari/microbox'
SRC = os.path.join(ROOT, 'TECHPUBS')
DST = os.path.join(ROOT, 'TECHPUBS_txt')

# The files come from several machines/charsets; each byte below occurs with only one meaning.
BYTEMAP = {
    0xAE: '®', 0xB7: '•', 0xBD: '©', 0xE3: '©', 0xE6: 'µ', 0xF1: '±', 0xF9: '•',
    0xFE: '■',  # placeholder left by a PC export; stands for © or ™ depending on context
}

def convert(data):
    # Unknown word-processor markers inside SPARROWS.TXT and STBOOK.DOC
    data = re.sub(rb'\xdcj[\x00-\x02]{6}\xdc[\x8c\r]', b'', data)
    eof = data.find(b'\x1a')
    if eof >= 0:
        data = data[:eof]
    slack = re.search(rb'\x00{8}', data)
    if slack:
        data = data[:slack.start()]
    data = re.sub(rb'\xd1\x00\x00\xff\xff', b'', data)
    data = data.replace(b'\r\n', b'\n').replace(b'\r', b'\n')
    out = []
    for b in data:
        if b in BYTEMAP:
            out.append(BYTEMAP[b])
        elif b == 0x1F:          # soft hyphen
            continue
        elif b == 0x01:          # page-number placeholder
            out.append('#')
        elif b == 0x0B:          # vertical tab used for spacing
            out.append('\n')
        elif b in (0x09, 0x0A, 0x0C) or 0x20 <= b < 0x7F:
            out.append(chr(b))
        else:
            out.append('�')
    return ''.join(out)

def main():
    lst = sys.argv[1] if len(sys.argv) > 1 else os.path.join(ROOT, 'TECHPUBS_lists/plaintext.lst')
    for rel in open(lst).read().split('\n'):
        if not rel:
            continue
        text = convert(open(os.path.join(SRC, rel), 'rb').read())
        dst = os.path.join(DST, rel + '.txt')
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        with open(dst, 'w', encoding='utf-8', newline='\n') as f:
            f.write(text)
        if '�' in text:
            print('unmapped bytes:', rel, text.count('�'))

main()
