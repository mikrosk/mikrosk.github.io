#!/usr/bin/env python3
# ABOUTME: Converts WordPerfect 5.0/5.1 documents ("\xFFWPC" prefix, product 1, file type 10) to UTF-8 plain text.
# ABOUTME: Emits paragraphs, tabs, tables as text grids, headers/footers, footnotes, figure placeholders and WP charsets.
import os
import struct
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import wp5_charsets  # noqa: E402

FIXED_LEN = [4, 9, 11, 3, 3, 5, 6, 7, 4, 5, 6, 6, 8, 10, 10, 12]  # 0xC0..0xCF

# tab group type, computed as (flags & 0xE8) >> 3 (same interpretation as libwpd)
TAB_LEFT, TAB_DECIMAL, TAB_RIGHT, TAB_FLUSH_RIGHT = 0x00, 0x08, 0x09, 0x0C
TAB_BACK, TAB_CENTER_POS, TAB_CENTER, TAB_CENTER_MARGINS = 0x10, 0x18, 0x19, 0x1C

HF_NAMES = {0: 'Header A', 1: 'Header B', 2: 'Footer A', 3: 'Footer B'}
BOX_NAMES = {0: 'Figure', 1: 'Table Box', 2: 'Text Box', 3: 'User Box', 4: 'Equation'}


def warn(msg):
    print('wp5totext: ' + msg, file=sys.stderr)


# Text typed on an Atari ST and imported as IBM PC text: ST byte 0xBD (copyright) became
# CP437 0xBD, which WordPerfect stored as box-drawing set 3 char 36.
ATARI_ST_IMPORT_FIXUPS = {(3, 36): '\u00a9'}


def ext_char(ch, cset):
    if (cset, ch) in ATARI_ST_IMPORT_FIXUPS:
        return ATARI_ST_IMPORT_FIXUPS[(cset, ch)]
    if cset == 0:
        return chr(ch) if 0x20 <= ch < 0x7f else ' '
    simple = wp5_charsets.SIMPLE.get(cset)
    if simple and ch < len(simple) and simple[ch]:
        return chr(simple[ch])
    cplx = wp5_charsets.COMPLEX.get(cset, {}).get(ch)
    if cplx:
        # libwpd lists a combining accent before its base letter; Unicode wants it after
        if len(cplx) == 2 and 0x300 <= cplx[0] <= 0x36f:
            cplx = [cplx[1], cplx[0]]
        return ''.join(chr(c) for c in cplx)
    warn('unmapped extended character set %d char %d' % (cset, ch))
    return '\ufffd'


class Sink:
    """Collects lines; handles tabs and indents at line start."""

    def __init__(self, tab='\t', soft_return_breaks=False):
        self.lines = []
        self.cur = []
        self.pending = 0
        self.tab = tab
        self.soft_return_breaks = soft_return_breaks

    def text(self, s):
        if not self.cur and self.pending > 0:
            self.cur.append(self.tab * self.pending)
        self.pending = 0
        self.cur.append(s)

    def at_line_start(self):
        return not self.cur

    def tab_stop(self, kind):
        if self.at_line_start():
            if kind == TAB_BACK:
                self.pending = max(0, self.pending - 1)
            elif kind in (TAB_CENTER_MARGINS, TAB_FLUSH_RIGHT):
                pass
            else:
                self.pending += 1
        elif kind != TAB_BACK:
            self.cur.append(self.tab)

    def indent(self):
        if self.at_line_start():
            self.pending += 1
        else:
            self.cur.append(self.tab)

    def newline(self):
        self.lines.append(''.join(self.cur))
        self.cur = []
        self.pending = 0

    def soft_return(self):
        if self.soft_return_breaks:
            self.newline()
        else:
            self.text(' ')

    def ensure_line_start(self):
        if self.cur:
            self.newline()

    def block(self, lines):
        self.ensure_line_start()
        for ln in lines:
            self.cur = [ln]
            self.newline()

    def finish(self):
        if self.cur:
            self.newline()
        return [ln.rstrip() for ln in self.lines]


class Table:
    def __init__(self, ncols):
        self.ncols = ncols
        self.rows = []  # each row: list of [col, colspan, spanned_from_above, Sink]
        self.cell = None

    def new_row(self):
        self.rows.append([])
        self.cell = None

    def new_cell(self, col, colspan, spanned):
        if not self.rows:
            self.new_row()
        self.cell = [col, max(1, colspan), spanned, Sink(tab='  ', soft_return_breaks=True)]
        self.rows[-1].append(self.cell)

    def sink(self):
        if self.cell is None:
            self.new_cell(len(self.rows[-1]) if self.rows else 0, 1, False)
        return self.cell[3]

    def render(self):
        ncols = self.ncols
        cells = []
        for row in self.rows:
            rc = []
            for col, span, spanned, sink in row:
                lines = sink.finish()
                while lines and not lines[-1].strip():
                    lines.pop()
                while lines and not lines[0].strip():
                    lines.pop(0)
                if spanned:
                    lines = []
                lines = [ln.replace('\t', '  ') for ln in lines]
                rc.append((col, span, lines))
                ncols = max(ncols, col + span)
            cells.append(rc)
        if ncols == 0:
            return []
        width = [1] * ncols
        for rc in cells:
            for col, span, lines in rc:
                if span == 1:
                    width[col] = max(width[col], max([len(x) for x in lines] + [0]))
        for rc in cells:
            for col, span, lines in rc:
                if span > 1:
                    need = max([len(x) for x in lines] + [0])
                    have = sum(width[col:col + span]) + 3 * (span - 1)
                    if need > have:
                        width[col + span - 1] += need - have
        sep = '+' + '+'.join('-' * (w + 2) for w in width) + '+'
        out = [sep]
        for rc in cells:
            # fill uncovered columns with empty cells so the grid stays rectangular
            slots = []
            pos = 0
            for col, span, lines in sorted(rc, key=lambda c: c[0]):
                if col < pos:
                    continue
                if col > pos:
                    slots.extend((c, 1, []) for c in range(pos, col))
                slots.append((col, span, lines))
                pos = col + span
            slots.extend((c, 1, []) for c in range(pos, ncols))
            height = max([len(s[2]) for s in slots] + [1])
            for i in range(height):
                parts = []
                for col, span, lines in slots:
                    w = sum(width[col:col + span]) + 3 * (span - 1)
                    parts.append(' ' + (lines[i] if i < len(lines) else '').ljust(w) + ' ')
                out.append(('|' + '|'.join(parts) + '|').rstrip())
            out.append(sep)
        return out


class Converter:
    def __init__(self, data):
        self.d = data
        self.notes = []

    def u16(self, p):
        return struct.unpack_from('<H', self.d, p)[0]

    # ---- document summary packet (index type 1)
    def summary(self, docptr):
        d = self.d
        p = 16
        seen = set()
        while p and p + 10 <= docptr and p not in seen:
            seen.add(p)
            typ, n, size, nxt = struct.unpack_from('<HHHI', d, p)
            if typ != 0xFFFB:
                warn('unexpected index header 0x%04x at 0x%x' % (typ, p))
                break
            for i in range(n - 1):
                et, ln, off = struct.unpack_from('<HII', d, p + 10 + i * 10)
                if et == 1 and ln >= 114 and off + ln <= docptr:
                    return self._summary_text(d[off:off + ln])
            p = nxt
        return None

    @staticmethod
    def _summary_text(pk):
        def field(b):
            return b.split(b'\0')[0].decode('cp437').strip()
        parts = []
        name, typ, created = field(pk[26:94]), field(pk[94:114]), field(pk[0:26])
        if name:
            parts.append('Descriptive name: ' + name)
        if typ:
            parts.append('Descriptive type: ' + typ)
        if created:
            parts.append('Created: ' + created)
        rest = pk[114:].split(b'\xff')[0].split(b'\0')
        for label, val in zip(('Subject', 'Author', 'Typist', 'Comment'), rest):
            val = val.decode('cp437').strip()
            if val:
                parts.append(label + ': ' + val)
        return parts

    # ---- stream parser
    def parse(self, start, end, sink_stack):
        d = self.d
        p = start
        table = None

        def sink():
            return table.sink() if table else sink_stack

        while p < end:
            c = d[p]
            if 0x20 <= c <= 0x7e:
                q = p
                while q < end and 0x20 <= d[q] <= 0x7e:
                    q += 1
                sink().text(d[p:q].decode('ascii'))
                p = q
                continue
            if c < 0x20:
                if c == 0x0A:
                    sink().newline()
                elif c == 0x0C:
                    sink().ensure_line_start()
                elif c in (0x0B, 0x0D):
                    sink().soft_return()
                elif c == 0x02:
                    sink().text('#')
                elif c not in (0x00, 0x1f):
                    # 0x1F only shows up as a discretionary hyphen inside words
                    warn('control code 0x%02x at 0x%x' % (c, p))
                p += 1
                continue
            if c in (0x7f, 0xff):
                p += 1
                continue
            if c < 0xc0:
                s = sink()
                if c in (0x8c, 0x99):
                    s.newline()
                elif c == 0xa0:
                    s.text(' ')
                elif c in (0xa9, 0xaa, 0xab):
                    s.text('-')
                elif c in (0xaf, 0xb0):
                    s.ensure_line_start()
                # 0x90 deletable return inside an over-long word, soft hyphens,
                # invisible returns and formatting toggles produce no text
                p += 1
                continue
            if c < 0xd0:
                ln = FIXED_LEN[c - 0xc0]
                if p + ln > end or d[p + ln - 1] != c:
                    warn('inconsistent fixed group 0x%02x at 0x%x' % (c, p))
                    p += 1
                    continue
                s = sink()
                if c == 0xc0:
                    s.text(ext_char(d[p + 1], d[p + 2]))
                elif c == 0xc1:
                    s.tab_stop((d[p + 1] & 0xE8) >> 3)
                elif c == 0xc2:
                    s.indent()
                p += ln
                continue
            # variable length group: code sub len16 ... len16 sub code
            if p + 4 > end:
                break
            sub = d[p + 1]
            ln = self.u16(p + 2)
            q = p + 4 + ln
            if (ln < 4 or q > end or self.u16(p + ln) != ln or d[p + ln + 2] != sub
                    or d[p + ln + 3] != c):
                warn('inconsistent variable group 0x%02x/%d at 0x%x' % (c, sub, p))
                p += 1
                continue
            table = self.group(c, sub, p, q, sink_stack, table)
            p = q
        if table:
            warn('table not closed at end of stream')
            sink_stack.block(table.render())
        return sink_stack

    def subdoc(self, start, end):
        return self.parse(start, end, Sink()).finish()

    def group(self, c, sub, p, q, sink_main, table):
        d = self.d
        if c == 0xd2 and sub == 0x0b:
            if table:
                sink_main.block(table.render())
            old = self.u16(p + 6)
            base = p + 4 + 2 + 2 + 20 + 5 * old
            ncols = self.u16(base + 2) if base + 4 <= q else 0
            sink_main.ensure_line_start()
            return Table(ncols if ncols <= 32 else 0)
        if c == 0xdc or c == 0xdd:
            if table is None:
                warn('table code 0x%02x/%d outside table at 0x%x' % (c, sub, p))
                return table
            if c == 0xdc and sub == 0:
                colspan = d[p + 6]
                table.new_cell(d[p + 5], colspan & 0x7f, bool(colspan & 0x80))
            elif (c == 0xdc and sub == 1) or (c == 0xdd and sub in (1, 3)):
                table.new_row()
            elif sub == 2:
                sink_main.block(table.render())
                return None
            return table
        s = table.sink() if table and c in (0xd5, 0xd6, 0xd8, 0xda) else sink_main
        if c == 0xd5:
            occurrence = d[p + 11]
            body_len = (q - p) - 26
            if occurrence and body_len > 0:
                lines = self.subdoc(p + 22, p + 22 + body_len)
                while lines and not lines[0].strip():
                    lines.pop(0)
                while lines and not lines[-1].strip():
                    lines.pop()
                name = HF_NAMES.get(sub, 'Header/Footer %d' % sub)
                s.block(['[%s]' % name] + lines + ['[/%s]' % name])
            return table
        if c == 0xd6:
            flags = d[p + 4]
            num = self.u16(p + 5)
            pos = p + 7
            if sub == 0:
                extra = d[pos]
                pos += 1 + 2 * (extra + 1) + 9
            else:
                pos += 4
            ref = chr(num) if flags & 0x80 else str(num)
            kind = 'Footnote' if sub == 0 else 'Endnote'
            lines = self.subdoc(pos, q - 4) if pos < q - 4 else []
            s.text('[%s]' % ref)
            self.notes.append((kind, ref, lines))
            return table
        if c == 0xd8:
            if sub == 1:
                s.text(d[p + 21:q - 4].decode('cp437'))
            elif sub == 3:
                s.text('#')
            else:
                warn('display group subtype %d at 0x%x' % (sub, p))
            return table
        if c == 0xda:
            if sub in BOX_NAMES and q - p >= 0x7d:
                label = BOX_NAMES[sub]
                content = d[p + 0x34]
                if content & 0x80 or content == 0x02:
                    fname = d[p + 0x35:p + 0x42].split(b'\0')[0].decode('cp437')
                    label += ': ' + fname
                cap_end = p + 0x79 + self.u16(p + 0x77)
                if cap_end > q - 4:
                    warn('box group %d with unexpected layout at 0x%x' % (sub, p))
                    cap_end = p + 0x79
                caption = ' '.join(x.strip() for x in self.subdoc(p + 0x79, cap_end) if x.strip())
                if caption:
                    label += '; caption: ' + caption
                if content == 0x10:
                    s.block(['[%s]' % label] + self.subdoc(cap_end, q - 4) + ['[/%s]' % BOX_NAMES[sub]])
                else:
                    if cap_end != q - 4:
                        warn('box group %d content type 0x%02x at 0x%x not decoded' % (sub, content, p))
                    s.block(['[%s]' % label])
            return table
        if c == 0xd9 and sub == 2:
            warn('document comment at 0x%x not decoded' % p)
        return table

    def convert(self):
        d = self.d
        if d[:4] != b'\xffWPC':
            raise ValueError('not a WordPerfect prefix file')
        docptr, prod, ftype, major, minor, enc = struct.unpack_from('<IBBBBH', d, 4)
        if prod != 1 or ftype != 10 or major != 0:
            raise ValueError('not a WordPerfect 5.x document (product %d type %d version %d.%d)'
                             % (prod, ftype, major, minor))
        if enc:
            raise ValueError('document is password protected')
        out = []
        summ = self.summary(docptr)
        if summ:
            out.append('[Document summary: %s]' % '; '.join(summ))
            out.append('')
        body = self.parse(docptr, len(d), Sink()).finish()
        out.extend(body)
        if self.notes:
            out.append('')
            for kind, ref, lines in self.notes:
                first = lines[0] if lines else ''
                out.append('[%s %s] %s' % (kind, ref, first))
                out.extend(lines[1:])
        # vertical whitespace reserved for page layout or figures carries no text
        text = []
        blanks = 0
        for ln in out:
            blanks = blanks + 1 if not ln.strip() else 0
            if blanks <= 2:
                text.append(ln)
        while text and not text[-1].strip():
            text.pop()
        return '\n'.join(text) + '\n'


def convert_file(src, dst):
    with open(src, 'rb') as f:
        text = Converter(f.read()).convert()
    os.makedirs(os.path.dirname(dst) or '.', exist_ok=True)
    with open(dst, 'w', encoding='utf-8', newline='\n') as f:
        f.write(text)


def main(argv):
    if len(argv) == 5 and argv[1] == '--batch':
        lst, src_root, dst_root = argv[2:5]
        failures = 0
        for rel in open(lst).read().split('\n'):
            rel = rel.strip()
            if not rel:
                continue
            print('== ' + rel, file=sys.stderr)
            try:
                convert_file(os.path.join(src_root, rel), os.path.join(dst_root, rel + '.txt'))
            except (ValueError, IndexError, struct.error) as e:
                failures += 1
                warn('FAILED %s: %s' % (rel, e))
        return 1 if failures else 0
    if len(argv) in (2, 3):
        if len(argv) == 3:
            convert_file(argv[1], argv[2])
        else:
            with open(argv[1], 'rb') as f:
                sys.stdout.write(Converter(f.read()).convert())
        return 0
    print('usage: wp5totext.py IN.WP [OUT.txt]\n'
          '       wp5totext.py --batch LIST SRC_ROOT DST_ROOT', file=sys.stderr)
    return 2


if __name__ == '__main__':
    sys.exit(main(sys.argv))
