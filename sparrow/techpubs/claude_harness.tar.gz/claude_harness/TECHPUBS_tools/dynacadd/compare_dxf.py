# ABOUTME: Cross-checks decoded DynaCADD .DPT geometry against an ASCII DXF export of the same drawing.
# ABOUTME: Finds the translation between the two and reports how many lines, arcs, circles, solids and texts match.

import math
import sys
from collections import Counter

import dynacadd as dc


def read_dxf(path):
    raw = open(path, 'rb').read().decode('latin-1').replace('\r', '').split('\n')
    pairs = [(raw[i].strip(), raw[i + 1]) for i in range(0, len(raw) - 1, 2)]
    blocks, ents = {}, []
    section = None
    cur = None
    block_name = None
    items = []
    for code, val in pairs:
        if code == '0':
            if cur is not None:
                items.append((section, block_name, cur))
            cur = {'type': val}
            if val == 'ENDSEC':
                section = None
            continue
        if cur is None:
            continue
        if cur['type'] == 'SECTION' and code == '2':
            section = val
        cur.setdefault(code, []).append(val)
    if cur is not None:
        items.append((section, block_name, cur))
    # attach entities to blocks / entity section, join polyline vertices
    block_ents = {}
    top = []
    target = None
    poly = None
    for section, _, e in items:
        t = e['type']
        if section == 'BLOCKS':
            if t == 'BLOCK':
                target = block_ents.setdefault(e['2'][0], [])
                continue
            if t == 'ENDBLK':
                target = None
                continue
            dest = target if target is not None else []
        elif section == 'ENTITIES':
            dest = top
        else:
            continue
        if t == 'POLYLINE':
            poly = {'type': 'POLYLINE', 'closed': int(e.get('70', ['0'])[0]) & 1, 'v': [], '8': e.get('8', ['0'])}
            dest.append(poly)
        elif t == 'VERTEX' and poly is not None:
            poly['v'].append((float(e['10'][0]), float(e['20'][0])))
        elif t == 'SEQEND':
            poly = None
        else:
            dest.append(e)

    def expand(lst, dx, dy):
        for e in lst:
            if e['type'] == 'INSERT':
                ix, iy = float(e['10'][0]), float(e['20'][0])
                yield from expand(block_ents.get(e['2'][0], []), dx + ix, dy + iy)
            else:
                yield e, dx, dy

    out = []
    for e, dx, dy in expand(top, 0.0, 0.0):
        g = lambda c: float(e[c][0])
        t = e['type']
        if t == 'LINE':
            out.append(('line', [(g('10') + dx, g('20') + dy), (g('11') + dx, g('21') + dy)]))
        elif t == 'POLYLINE':
            v = [(x + dx, y + dy) for x, y in e['v']]
            segs = list(zip(v, v[1:])) + ([(v[-1], v[0])] if e['closed'] and len(v) > 2 else [])
            for a, b in segs:
                out.append(('pline', [a, b]))
        elif t == 'ARC':
            out.append(('arc', (g('10') + dx, g('20') + dy, g('40'), g('50'), g('51'))))
        elif t == 'CIRCLE':
            out.append(('circle', (g('10') + dx, g('20') + dy, g('40'))))
        elif t == 'SOLID':
            out.append(('solid', [(g('1%d' % i) + dx, g('2%d' % i) + dy) for i in range(4)]))
        elif t == 'TEXT':
            out.append(('text', (g('10') + dx, g('20') + dy, e.get('1', [''])[0])))
    return out


def key(x, y, q=0.01):
    return (round(x / q), round(y / q))


def main(dpt_path, dxf_path):
    ents, _, _ = dc.parse_dpt(open(dpt_path, 'rb').read())
    dxf = read_dxf(dxf_path)
    dpt_lines = [e['pts'] for e in ents if e['kind'] == 'line']
    dxf_lines = [p for k, p in dxf if k == 'line']
    # translation vote from line start points
    votes = Counter()
    sample = dpt_lines[:300]
    idx = {}
    for p in dxf_lines:
        idx.setdefault(round(math.hypot(p[1][0] - p[0][0], p[1][1] - p[0][1]), 3), []).append(p)
    for a in sample:
        L = round(math.hypot(a[1][0] - a[0][0], a[1][1] - a[0][1]), 3)
        for b in idx.get(L, []):
            for (ax, ay), (bx, by) in (((a[0]), (b[0])), ((a[0]), (b[1]))):
                votes[(round(bx - ax, 3), round(by - ay, 3))] += 1
    dx, dy = votes.most_common(1)[0][0] if votes else (0.0, 0.0)
    print('DPT %s vs DXF %s' % (dpt_path, dxf_path))
    print('translation DXF - DPT: (%s, %s)' % (dx, dy))

    def seg_key(p):
        a, b = key(*p[0]), key(*p[1])
        return (a, b) if a <= b else (b, a)

    dxf_seg = Counter(seg_key(p) for k, p in dxf if k in ('line', 'pline'))
    hit = 0
    for p in dpt_lines:
        k = seg_key([(p[0][0] + dx, p[0][1] + dy), (p[1][0] + dx, p[1][1] + dy)])
        if dxf_seg[k] > 0:
            dxf_seg[k] -= 1
            hit += 1
    print('lines: DPT %d, DXF LINE %d + polyline segments %d, matched %d' % (
        len(dpt_lines), len(dxf_lines), sum(1 for k, _ in dxf if k == 'pline'), hit))

    dxf_arcs = Counter((key(x, y), round(r, 2), round(a0 % 360, 1), round(a1 % 360, 1)) for k, (x, y, r, a0, a1) in
                       ((k, v) for k, v in dxf if k == 'arc'))
    dpt_arcs = [e for e in ents if e['type'] == 4]
    hit = 0
    for e in dpt_arcs:
        k = (key(e['c'][0] + dx, e['c'][1] + dy), round(e['rx'], 2), round(math.degrees(e['a0']) % 360, 1),
             round(math.degrees(e['a1']) % 360, 1))
        if dxf_arcs[k] > 0:
            dxf_arcs[k] -= 1
            hit += 1
    print('arcs: DPT %d, DXF %d, matched (centre, radius, start/end angle) %d' % (
        len(dpt_arcs), sum(1 for k, _ in dxf if k == 'arc'), hit))

    dxf_circ = Counter((key(x, y), round(r, 2)) for k, (x, y, r) in ((k, v) for k, v in dxf if k == 'circle'))
    dpt_circ = [e for e in ents if e['type'] == 3]
    hit = 0
    for e in dpt_circ:
        k = (key(e['c'][0] + dx, e['c'][1] + dy), round(e['rx'], 2))
        if dxf_circ[k] > 0:
            dxf_circ[k] -= 1
            hit += 1
    print('circles: DPT %d, DXF %d, matched %d' % (len(dpt_circ), sum(dxf_circ.values()) + hit, hit))

    dxf_sol = Counter(tuple(key(*p) for p in v) for k, v in dxf if k == 'solid')
    dpt_sol = [e for e in ents if e['type'] == 11]
    hit = 0
    for e in dpt_sol:
        k = tuple(key(x + dx, y + dy) for x, y in e['pts'])
        if dxf_sol[k] > 0:
            dxf_sol[k] -= 1
            hit += 1
    print('solids: DPT %d, DXF %d, matched %d' % (len(dpt_sol), sum(dxf_sol.values()) + hit, hit))

    dxf_txt = [v for k, v in dxf if k == 'text']
    dpt_txt = [e for e in ents if e['kind'] == 'text']
    names = Counter(t for _, _, t in dxf_txt)
    hit = 0
    for e in dpt_txt:
        s = e['text']
        for cand in (s, '%%U' + s):
            if names[cand] > 0:
                names[cand] -= 1
                hit += 1
                break
    print('texts: DPT %d, DXF %d, same strings %d' % (len(dpt_txt), len(dxf_txt), hit))
    ell = sum(1 for e in ents if e['type'] in (6, 7))
    if ell:
        print('ellipses/elliptical arcs in DPT: %d (DXF exports these as polylines)' % ell)


if __name__ == '__main__':
    main(sys.argv[1], sys.argv[2])
