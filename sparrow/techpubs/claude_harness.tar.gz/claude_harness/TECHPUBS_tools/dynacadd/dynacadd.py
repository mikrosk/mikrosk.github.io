# ABOUTME: Decodes DynaCADD 2.0 (Atari ST/TT) .DPT/.PRT entity files, .DWG settings files and .DEF exchange files.
# ABOUTME: Writes a readable .txt summary (layers, counts, all text strings) and an .svg render of the geometry.

import math
import os
import struct
import sys
from collections import Counter, OrderedDict
from xml.sax.saxutils import escape

DPT_MAGIC = b'DYNACADD2.0\0'
DPT_HEADER_LEN = 35
DWG_MAGIC = b'\x00\xc8'

TYPE_NAMES = {2: 'LINE', 3: 'CIRCLE', 4: 'ARC', 6: 'ELLIPSE', 7: 'ELLIPTICAL ARC', 8: 'TEXT', 11: 'SOLID'}


# ---------------------------------------------------------------- DPT / PRT

def parse_dpt(data):
    """Return (entities, end_offset, error). Entities are dicts in file order."""
    if not data.startswith(DPT_MAGIC):
        raise ValueError('not a DYNACADD2.0 entity file')
    ents = []
    p = DPT_HEADER_LEN
    while True:
        if p + 2 > len(data):
            return ents, p, 'truncated (no FFFF terminator)'
        t, = struct.unpack_from('>H', data, p)
        if t == 0xFFFF:
            return ents, p + 2, None
        # common part: type word, [text: string length word], two in-memory list pointers, 12 attribute bytes
        if t == 8:
            slen, = struct.unpack_from('>H', data, p + 2)
            hdr = 24
            size = 160 + 2 * slen
        elif t == 2:
            hdr, size = 22, 54
        elif t in (3, 4, 6, 7):
            hdr, size = 22, 78
        elif t == 11:
            hdr, size = 22, 86
        else:
            return ents, p, 'unknown record type 0x%04x at offset 0x%x' % (t, p)
        if p + size > len(data):
            return ents, p, 'truncated record at offset 0x%x' % p
        a = data[p + hdr - 12:p + hdr]
        e = {
            'type': t,
            'offset': p,
            'layer': a[1],
            'color': a[2],
            'style': a[3],
            'valid': a[7] == 1,
            'group': struct.unpack_from('>H', a, 10)[0],
        }
        body = p + hdr
        if t == 2:
            x1, y1, x2, y2 = struct.unpack_from('>4d', data, body)
            e.update(kind='line', pts=[(x1, y1), (x2, y2)])
        elif t in (3, 4, 6, 7):
            cx, cy, rx, ry, rot, a0, a1 = struct.unpack_from('>7d', data, body)
            e.update(kind='arc', c=(cx, cy), rx=rx, ry=ry, rot=rot, a0=a0, a1=a1)
        elif t == 11:
            v = struct.unpack_from('>8d', data, body)
            pts = [(v[0], v[1]), (v[2], v[3]), (v[4], v[5]), (v[6], v[7])]
            e.update(kind='solid', pts=pts)
        elif t == 8:
            x, y, w, h, slant, ang = struct.unpack_from('>6d', data, body)
            just, = struct.unpack_from('>H', data, body + 48)
            font_no, = struct.unpack_from('>H', data, body + 58)
            font = data[body + 60:body + 70].split(b'\0')[0].decode('latin-1')
            bb = struct.unpack_from('>8d', data, body + 70)
            raw = data[body + 136:body + 136 + slen].split(b'\0')[0]
            e.update(kind='text', x=x, y=y, w=w, h=h, slant=slant, angle=ang, just=just,
                     font_no=font_no, font=font,
                     bbox=[(bb[0], bb[1]), (bb[2], bb[3]), (bb[4], bb[5]), (bb[6], bb[7])],
                     text=raw.decode('latin-1'))
            if not all(math.isfinite(v) for v in (x, y, w, h, ang) + bb):
                e['valid'] = False
        ents.append(e)
        p += size


# ---------------------------------------------------------------- DWG

def parse_dwg(data):
    if not data.startswith(DWG_MAGIC) or len(data) < 0x52ae:
        raise ValueError('not a DynaCADD 2.0 drawing settings file')
    d = {}
    d['gcp_names'] = [data[0x1d6 + 9 * i:0x1d6 + 9 * i + 9].split(b'\0')[0].decode('latin-1') for i in range(7)]
    (d['sheet_w'], d['sheet_h'], d['scale'], d['origin_x'], d['origin_y'],
     d['view_w'], d['view_h']) = struct.unpack_from('>7d', data, 0x8ae)
    d['line_scale'], = struct.unpack_from('>d', data, 0xb1c)
    styles = []
    for k in range(64):
        o = 0xb24 + 0xaa * k
        name = data[o:o + 32].split(b'\0')[0].decode('latin-1')
        n = data[o + 32]
        pattern = list(data[o + 34:o + 34 + n]) if 0 < n <= 16 else []
        sc, = struct.unpack_from('>d', data, o + 162)
        styles.append({'name': name, 'scale': sc, 'pattern': pattern})
    d['styles'] = styles
    d['layer_names'] = [data[0x35a4 + 18 * i:0x35a4 + 18 * i + 18].split(b'\0')[0].decode('latin-1')
                        for i in range(256)]
    d['layer_on'] = list(data[0x48a4:0x48a4 + 256])
    d['layer_colors'] = list(data[0x49a4:0x49a4 + 256])
    d['palette'] = [struct.unpack_from('>3H', data, 0x4ca6 + 6 * i) for i in range(16)]
    return d


def style_name(dwg, idx):
    if dwg and idx < 58 and dwg['styles'][idx]['name']:
        name = dwg['styles'][idx]['name']
        # slot 0 is treated as solid: EasyDraw GEM exports of drawings whose slot 0 is "DASHED" show unbroken lines
        if idx == 0 and name != 'CONTINUOUS':
            return '%s, drawn solid' % name
        return name
    return 'solid' if idx == 0 else 'style%d' % idx


def layer_name(dwg, idx):
    if dwg and dwg['layer_names'][idx]:
        return dwg['layer_names'][idx]
    return str(idx)


# ---------------------------------------------------------------- DEF (DynaCADD exchange, text)

def parse_def(text):
    lines = [l.rstrip('\r') for l in text.split('\n')]
    header = OrderedDict()
    blocks = []
    i = 0
    header_keys = ('Version', 'Scale', 'Units', 'Width', 'Height', 'Line_Scale', 'Origin_X', 'Origin_Y',
                   'Color_By_Layer', 'Style_By_Layer', 'Weight_By_Layer', 'Layer', 'Color', 'Weight', 'Style')
    comments = []
    while i < len(lines):
        l = lines[i]
        if l.startswith('***'):
            comments.append(l)
            i += 1
        elif l in header_keys and i + 1 < len(lines) and l not in header:
            header[l] = lines[i + 1]
            i += 2
        elif l and any(ch.isalpha() for ch in l) and l not in ('End', 'EOF'):
            j = i + 1
            vals = []
            while j < len(lines) and lines[j] != 'End':
                vals.append(lines[j])
                j += 1
            blocks.append((l, vals))
            i = j + 1
        else:
            i += 1
    return comments, header, blocks


def def_entities(blocks):
    ents = []
    for kw, v in blocks:
        try:
            if kw == '2D_Line':
                x1, y1, x2, y2 = map(float, v[:4])
                ents.append({'type': 2, 'kind': 'line', 'pts': [(x1, y1), (x2, y2)], 'layer': 0, 'style': 0,
                             'color': 0, 'group': 0, 'valid': True})
            elif kw == '2D_Arc':
                cx, cy, r, a0, a1 = map(float, v[:5])
                ents.append({'type': 4, 'kind': 'arc', 'c': (cx, cy), 'rx': r, 'ry': r, 'rot': 0.0,
                             'a0': math.radians(a0), 'a1': math.radians(a1), 'layer': 0, 'style': 0,
                             'color': 0, 'group': 0, 'valid': True})
            elif kw == '2D_Text':
                x, y, w, h, slant, ang = map(float, v[:6])
                ents.append({'type': 8, 'kind': 'text', 'x': x, 'y': y, 'w': w, 'h': h, 'slant': slant,
                             'angle': ang, 'font': v[8], 'text': v[9] if len(v) > 9 else '', 'bbox': None,
                             'layer': 0, 'style': 0, 'color': 0, 'group': 0, 'valid': True})
        except (ValueError, IndexError):
            pass
    return ents


# ---------------------------------------------------------------- geometry helpers

def arc_point(e, t):
    cr, sr = math.cos(e['rot']), math.sin(e['rot'])
    px, py = e['rx'] * math.cos(t), e['ry'] * math.sin(t)
    return (e['c'][0] + px * cr - py * sr, e['c'][1] + px * sr + py * cr)


def arc_sweep(e):
    s = e['a1'] - e['a0']
    if s <= 0:
        s += 2 * math.pi
    return min(s, 2 * math.pi)


def is_full(e):
    return e['type'] in (3, 6) or arc_sweep(e) >= 2 * math.pi - 1e-9


def text_frame(e):
    """Lower-left corner, baseline length, height and angle (radians) used for rendering."""
    bb = e.get('bbox')
    if bb and all(math.isfinite(c) for p in bb for c in p):
        (x0, y0), (x1, y1), (x2, y2) = bb[0], bb[1], bb[2]
        length = math.hypot(x1 - x0, y1 - y0)
        height = math.hypot(x2 - x0, y2 - y0)
        if length > 0 and height > 0:
            return (x0, y0), length, height, math.atan2(y1 - y0, x1 - x0)
    n = max(len(e['text']), 1)
    return (e['x'], e['y']), e['w'] * n, e['h'], e['angle']


def entity_points(e):
    if e['kind'] in ('line', 'solid'):
        return e['pts']
    if e['kind'] == 'arc':
        sweep = arc_sweep(e) if not is_full(e) else 2 * math.pi
        n = max(8, int(64 * sweep / (2 * math.pi)))
        return [arc_point(e, e['a0'] + sweep * i / n) for i in range(n + 1)]
    if e['kind'] == 'text':
        (x0, y0), length, height, ang = text_frame(e)
        ux, uy = math.cos(ang), math.sin(ang)
        return [(x0, y0), (x0 + ux * length, y0 + uy * length), (x0 - uy * height, y0 + ux * height),
                (x0 + ux * length - uy * height, y0 + uy * length + ux * height)]
    return []


def extents(ents):
    xs, ys = [], []
    for e in ents:
        if not e['valid']:
            continue
        for x, y in entity_points(e):
            if math.isfinite(x) and math.isfinite(y):
                xs.append(x)
                ys.append(y)
    if not xs:
        return None
    return min(xs), min(ys), max(xs), max(ys)


def fmt(v):
    s = '%.4f' % v
    s = s.rstrip('0').rstrip('.')
    return '0' if s in ('-0', '') else s


# ---------------------------------------------------------------- SVG

def render_svg(ents, dwg, title):
    ext = extents(ents)
    if ext is None:
        return None
    x0, y0, x1, y1 = ext
    w, h = max(x1 - x0, 1e-6), max(y1 - y0, 1e-6)
    margin = 0.02 * max(w, h)
    vx, vy = x0 - margin, -(y1 + margin)
    vw, vh = w + 2 * margin, h + 2 * margin
    px = 2000.0 / max(vw, vh)
    diag = math.hypot(vw, vh)
    sw = diag / 2500.0

    def P(x, y):
        return '%s %s' % (fmt(x), fmt(-y))

    groups = OrderedDict()
    texts = []
    solids = []
    for e in ents:
        if not e['valid']:
            continue
        if e['kind'] == 'text':
            texts.append(e)
            continue
        if e['kind'] == 'solid':
            solids.append(e)
            continue
        key = (e['layer'], e['style'])
        seg = groups.setdefault(key, [])
        if e['kind'] == 'line':
            (ax, ay), (bx, by) = e['pts']
            seg.append('M%sL%s' % (P(ax, ay), P(bx, by)))
        elif e['kind'] == 'arc':
            rx, ry = abs(e['rx']), abs(e['ry'])
            rot = -math.degrees(e['rot'])
            if is_full(e):
                a = arc_point(e, 0.0)
                b = arc_point(e, math.pi)
                seg.append('M%sA%s %s %s 0 0 %sA%s %s %s 0 0 %s' % (
                    P(*a), fmt(rx), fmt(ry), fmt(rot), P(*b), fmt(rx), fmt(ry), fmt(rot), P(*a)))
            else:
                sweep = arc_sweep(e)
                a = arc_point(e, e['a0'])
                b = arc_point(e, e['a0'] + sweep)
                large = 1 if sweep > math.pi else 0
                # counter-clockwise in drawing coordinates becomes clockwise after the Y flip
                seg.append('M%sA%s %s %s %d 0 %s' % (P(*a), fmt(rx), fmt(ry), fmt(rot), large, P(*b)))

    out = []
    out.append('<?xml version="1.0" encoding="UTF-8"?>')
    out.append('<svg xmlns="http://www.w3.org/2000/svg" width="%d" height="%d" viewBox="%s %s %s %s">' % (
        round(vw * px), round(vh * px), fmt(vx), fmt(vy), fmt(vw), fmt(vh)))
    out.append('<title>%s</title>' % escape(title))
    out.append('<rect x="%s" y="%s" width="%s" height="%s" fill="#ffffff"/>' % (fmt(vx), fmt(vy), fmt(vw), fmt(vh)))
    out.append('<g fill="none" stroke="#000000" stroke-width="%s" stroke-linecap="round" stroke-linejoin="round">'
               % fmt(sw))
    for (layer, style), segs in groups.items():
        attrs = ''
        if style and dwg and style < 58:
            pat = dwg['styles'][style]['pattern']
            if len(pat) >= 3 and len(pat) % 2 == 1 and sum(pat) > 0:
                # pattern alternates on/off and starts and ends with "on"; the two ends join across periods
                period = max(dwg['styles'][style]['scale'] * dwg['line_scale'], diag / 400.0)
                unit = period / sum(pat)
                segs_on_off = [pat[-1] + pat[0]] + pat[1:-1]
                dashes = [max(v * unit, sw * 0.5) for v in segs_on_off]
                attrs = ' stroke-dasharray="%s" stroke-dashoffset="%s"' % (
                    ' '.join(fmt(v) for v in dashes), fmt(pat[-1] * unit))
        out.append('<path data-layer="%s" data-style="%s"%s d="%s"/>' % (
            escape(layer_name(dwg, layer)), escape(style_name(dwg, style)), attrs, ''.join(segs)))
    out.append('</g>')
    if solids:
        out.append('<g fill="#000000" stroke="#000000" stroke-width="%s">' % fmt(sw))
        for e in solids:
            out.append('<polygon points="%s"/>' % ' '.join('%s,%s' % (fmt(x), fmt(-y)) for x, y in e['pts']))
        out.append('</g>')
    if texts:
        out.append('<g fill="#000000" font-family="DejaVu Sans Mono, Consolas, Courier New, monospace">')
        for e in texts:
            s = e['text'].rstrip()
            if not s.strip():
                continue
            (tx, ty), length, height, ang = text_frame(e)
            fs = height / 0.72
            tl = length
            out.append('<text x="%s" y="%s" font-size="%s" textLength="%s" lengthAdjust="spacingAndGlyphs"%s>%s</text>' % (
                fmt(tx), fmt(-ty), fmt(fs), fmt(tl),
                (' transform="rotate(%s %s %s)"' % (fmt(-math.degrees(ang)), fmt(tx), fmt(-ty))) if abs(ang) > 1e-9 else '',
                escape(s)))
        out.append('</g>')
    out.append('</svg>')
    return '\n'.join(out) + '\n'


# ---------------------------------------------------------------- TXT reports

def entity_summary(ents, dwg):
    lines = []
    cnt = Counter(e['type'] for e in ents)
    lines.append('Entities: %d total (%s)' % (len(ents), ', '.join(
        '%s %d' % (TYPE_NAMES.get(t, 'type%d' % t), cnt[t]) for t in sorted(cnt))))
    bad = [e for e in ents if not e['valid']]
    if bad:
        lines.append('Invalid/unplaced entities (no usable coordinates, not rendered): %d' % len(bad))
    ext = extents(ents)
    if ext:
        lines.append('Extents: x %s .. %s, y %s .. %s (size %s x %s)' % (
            fmt(ext[0]), fmt(ext[2]), fmt(ext[1]), fmt(ext[3]), fmt(ext[2] - ext[0]), fmt(ext[3] - ext[1])))
    lc = Counter(e['layer'] for e in ents)
    lines.append('Layers used: ' + ', '.join('%d "%s" (%d)' % (l, layer_name(dwg, l), lc[l]) for l in sorted(lc)))
    sc = Counter(e['style'] for e in ents)
    lines.append('Line styles used: ' + ', '.join('%d "%s" (%d)' % (s, style_name(dwg, s), sc[s]) for s in sorted(sc)))
    cc = Counter(e['color'] for e in ents)
    lines.append('Colour indices used: ' + ', '.join('%d (%d)' % (c, cc[c]) for c in sorted(cc)))
    gc = Counter(e['group'] for e in ents)
    named = [g for g in sorted(gc) if g]
    if named:
        lines.append('Groups (unnamed, numbered; 0 = not grouped): ' + ', '.join('%d (%d)' % (g, gc[g]) for g in sorted(gc)))
    else:
        lines.append('Groups: none')
    return lines


def text_listing(ents, dwg):
    texts = [e for e in ents if e['kind'] == 'text']
    lines = ['', 'Text strings (%d), in file order; x,y = insertion point:' % len(texts)]
    for e in texts:
        if not e['valid']:
            lines.append('  [no position]  h=%s  layer=%s  "%s"' % (fmt(e['h']), layer_name(dwg, e['layer']), e['text']))
            continue
        ang = math.degrees(e['angle']) % 360.0
        lines.append('  x=%-10s y=%-10s h=%-7s w=%-7s angle=%-6s font=%-8s layer=%-8s "%s"' % (
            fmt(e['x']), fmt(e['y']), fmt(e['h']), fmt(e['w']), fmt(ang), e['font'],
            layer_name(dwg, e['layer']), e['text']))
    return lines


def dwg_settings_lines(dwg, used_layers=()):
    lines = []
    lines.append('Sheet: width %s, height %s, scale %s, origin (%s, %s)' % (
        fmt(dwg['sheet_w']), fmt(dwg['sheet_h']), fmt(dwg['scale']), fmt(dwg['origin_x']), fmt(dwg['origin_y'])))
    lines.append('Saved view window: %s x %s' % (fmt(dwg['view_w']), fmt(dwg['view_h'])))
    lines.append('Units: not recorded in a field identified so far')
    lines.append('Global line style scale: %s' % fmt(dwg['line_scale']))
    lay = []
    for i, n in enumerate(dwg['layer_names']):
        if (n and n != str(i)) or i in used_layers:
            lay.append('%d "%s" colour %d%s' % (i, n, dwg['layer_colors'][i], '' if dwg['layer_on'][i] else ' (off)'))
    lines.append('Named layers: ' + (', '.join(lay) if lay else 'none'))
    st = ['%d "%s" scale %s' % (i, s['name'], fmt(s['scale'])) for i, s in enumerate(dwg['styles'][:58]) if s['name']]
    lines.append('Line style table: ' + (', '.join(st) if st else 'empty'))
    lines.append('Construction planes: ' + ', '.join(n for n in dwg['gcp_names'] if n))
    return lines


def rel_note(path):
    return os.path.basename(path)


def find_companion(path, ext):
    base = os.path.splitext(path)[0]
    for cand in (base + ext, base + ext.lower()):
        if os.path.exists(cand):
            return cand
    return None


def convert_dpt(src, rel, out_base):
    data = open(src, 'rb').read()
    ents, end, err = parse_dpt(data)
    is_prt = src.upper().endswith('.PRT')
    dwg_path = None if is_prt else find_companion(src, '.DWG')
    dwg = parse_dwg(open(dwg_path, 'rb').read()) if dwg_path else None
    lines = []
    kind = 'part library (.PRT)' if is_prt else 'entity file (.DPT)'
    lines.append('DynaCADD 2.0 %s' % kind)
    lines.append('Source: %s (%d bytes)' % (rel, len(data)))
    lines.append('Record stream: %d records, ends at offset 0x%x%s' % (
        len(ents), end, (' - ' + err) if err else ' with FFFF terminator'))
    if dwg_path:
        lines.append('Drawing settings from: %s' % rel_note(dwg_path))
        lines.append('Sheet: width %s, height %s, scale %s' % (fmt(dwg['sheet_w']), fmt(dwg['sheet_h']), fmt(dwg['scale'])))
    lines.append('Units: not recorded in a field identified so far; coordinates are listed as stored')
    if not ents:
        if is_prt:
            lines.append('Parts contained: none (the library holds only the header and the end marker)')
        else:
            lines.append('Entities: none (file holds only the header and the end marker)')
        svg = None
    else:
        lines.extend(entity_summary(ents, dwg))
        lines.extend(text_listing(ents, dwg))
        svg = render_svg(ents, dwg, rel)
    write_outputs(out_base, lines, svg)
    return len(ents), svg is not None, err


def convert_dwg(src, rel, out_base):
    data = open(src, 'rb').read()
    dwg = parse_dwg(data)
    dpt_path = find_companion(src, '.DPT')
    lines = ['DynaCADD 2.0 drawing settings file (.DWG)', 'Source: %s (%d bytes)' % (rel, len(data))]
    used = ()
    if dpt_path:
        ents, _, err = parse_dpt(open(dpt_path, 'rb').read())
        used = set(e['layer'] for e in ents)
        lines.append('Holds no entity geometry. The drawing content is in %s (%d entities, %d text strings); '
                     'see %s.txt and %s.svg.' % (rel_note(dpt_path), len(ents),
                                                 sum(1 for e in ents if e['kind'] == 'text'),
                                                 rel_note(dpt_path), rel_note(dpt_path)))
    else:
        lines.append('Holds no entity geometry, and no same-named .DPT entity file exists, so the drawing content is not in the archive.')
    lines.extend(dwg_settings_lines(dwg, used))
    write_outputs(out_base, lines, None)
    return 0, False, None


def convert_def(src, rel, out_base):
    text = open(src, 'rb').read().decode('latin-1')
    comments, header, blocks = parse_def(text)
    ents = def_entities(blocks)
    lines = ['DynaCADD exchange file (.DEF, plain text)', 'Source: %s (%d bytes)' % (rel, len(text))]
    lines.extend(c for c in comments[:2])
    lines.append('Structure: keyword line, one value per line, "End" closes each record; '
                 'sections: header, current attributes, line styles, layers, colours, views, construction planes, '
                 'images, 2D entities, 3D entities, groups.')
    lines.append('Header: ' + ', '.join('%s=%s' % (k, v) for k, v in header.items()))
    kc = Counter(kw for kw, _ in blocks)
    lines.append('Records: ' + ', '.join('%s %d' % (k, kc[k]) for k in kc))
    styles = ['%s "%s" scale %s' % (v[0], v[1], v[2]) for kw, v in blocks if kw == 'Line_Style' and len(v) >= 3]
    lines.append('Line styles: ' + ', '.join(styles))
    lays = [(v[0], v[1], v[4]) for kw, v in blocks if kw == 'Layer_Definition' and len(v) >= 5]
    named = ['%s "%s" colour %s' % l for l in lays if l[1] != l[0]]
    lines.append('Layers: %d defined; named: %s' % (len(lays), ', '.join(named) if named else 'none'))
    lines.append('Layer_Definition values: index, name, then 5 numbers (third of them is the layer colour)')
    cols = ['%s=(%s)' % (v[0], ','.join(v[1:4])) for kw, v in blocks if kw == 'Color_Definition' and len(v) >= 4]
    lines.append('Colour table (index=(R,G,B) in 0..1000): ' + ', '.join(cols))
    gcps = ['%s' % v[1] for kw, v in blocks if kw == 'GCP_Definition' and len(v) >= 2]
    lines.append('Construction planes: ' + ', '.join(gcps))
    lines.append('Entity layouts: 2D_Line = x1,y1,x2,y2; 2D_Arc = cx,cy,r,start deg,end deg (counter-clockwise); '
                 '2D_Text = x,y,char width,height,slant?,angle,flag,value,font,text')
    dpt = find_companion(src, '.DPT')
    if dpt:
        dents, _, _ = parse_dpt(open(dpt, 'rb').read())
        same = len(dents) == len(ents) and all(same_entity(a, b) for a, b in zip(dents, ents))
        lines.append('Compared with %s: %s' % (rel_note(dpt), 'same entities, same order, same values (within 1e-6)'
                                                 if same else 'differs'))
    ext = extents(ents)
    if ext:
        lines.append('Extents: x %s .. %s, y %s .. %s' % (fmt(ext[0]), fmt(ext[2]), fmt(ext[1]), fmt(ext[3])))
    lines.extend(text_listing(ents, None))
    svg = render_svg(ents, None, rel) if ents else None
    write_outputs(out_base, lines, svg)
    return len(ents), svg is not None, None


def same_entity(a, b, tol=1e-6):
    if a['kind'] != b['kind']:
        return False
    if a['kind'] == 'line':
        vals = [(u, v) for p, q in zip(a['pts'], b['pts']) for u, v in zip(p, q)]
    elif a['kind'] == 'arc':
        vals = [(a['c'][0], b['c'][0]), (a['c'][1], b['c'][1]), (a['rx'], b['rx']), (a['a0'], b['a0']), (a['a1'], b['a1'])]
    elif a['kind'] == 'text':
        if a['text'] != b['text']:
            return False
        vals = [(a[k], b[k]) for k in ('x', 'y', 'w', 'h', 'angle')]
    else:
        return False
    return all(abs(u - v) < tol for u, v in vals)


def convert_macro_inf(src, rel, out_base):
    data = open(src, 'rb').read()
    slot = 141
    lines = ['DynaCADD macro definition file (MACRODEF.INF)', 'Source: %s (%d bytes)' % (rel, len(data))]
    lines.append('Structure: %d fixed slots of %d bytes, each a NUL-padded ASCII macro written in the typed '
                 'command language (abbreviated commands and keywords, X/Y/Z and IX/IY/IZ coordinates, '
                 '"," after each point, ";" after each command). Empty slots are omitted below.' % (
                     len(data) // slot, slot))
    lines.append('Content: 3D modelling macros - view rotation (RO AX/AY/AZ), inserting lines, circles, polygons '
                 '(I L, I CI, I POL), revolving (REVA angle, REVN steps), rotating (ROTAN, ROTN), projecting '
                 '(PROJD, PROJS) and translating profiles.')
    lines.append('')
    for i in range(len(data) // slot):
        chunk = data[i * slot:(i + 1) * slot]
        s = chunk.split(b'\0')[0].decode('latin-1').rstrip()
        if s:
            lines.append('slot %2d: %s' % (i, s))
    write_outputs(out_base, lines, None)
    return 0, False, None


def write_outputs(out_base, lines, svg):
    os.makedirs(os.path.dirname(out_base), exist_ok=True)
    with open(out_base + '.txt', 'w', encoding='utf-8', newline='\n') as f:
        f.write('\n'.join(lines) + '\n')
    if svg:
        with open(out_base + '.svg', 'w', encoding='utf-8', newline='\n') as f:
            f.write(svg)


def convert(src_root, rel, out_root):
    src = os.path.join(src_root, rel)
    out_base = os.path.join(out_root, rel)
    up = rel.upper()
    head = open(src, 'rb').read(64)
    if head.startswith(DPT_MAGIC):
        return convert_dpt(src, rel, out_base)
    if up.endswith('.DWG') and head.startswith(DWG_MAGIC):
        return convert_dwg(src, rel, out_base)
    if up.endswith('.DEF'):
        return convert_def(src, rel, out_base)
    if up.endswith('MACRODEF.INF'):
        return convert_macro_inf(src, rel, out_base)
    raise ValueError('unrecognised file')


def main(argv):
    if len(argv) != 4:
        print('usage: dynacadd.py <source root> <file list> <output root>', file=sys.stderr)
        return 2
    src_root, lst, out_root = argv[1:]
    ok = 0
    for rel in open(lst).read().split():
        try:
            n, has_svg, err = convert(src_root, rel, out_root)
            ok += 1
            print('%-50s entities=%-6d svg=%s%s' % (rel, n, 'yes' if has_svg else 'no', ('  WARN ' + err) if err else ''))
        except Exception as ex:
            print('%-50s FAILED: %s' % (rel, ex))
    print('converted %d files' % ok)
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv))
