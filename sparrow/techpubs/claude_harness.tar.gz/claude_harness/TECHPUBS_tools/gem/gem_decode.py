#!/usr/bin/env python3
# ABOUTME: Decodes GEM metafiles (.GEM from Easy-Draw, PageStream, GEM/3 apps) into a text summary with all strings and an SVG render.
# ABOUTME: Usage: gem_decode.py FILE.GEM OUTBASE  |  gem_decode.py --list LISTFILE SRCROOT OUTROOT
import math
import os
import struct
import sys
from collections import Counter

ATARI_LOW = {
    0x01: 0x21E7, 0x02: 0x21E9, 0x03: 0x21E8, 0x04: 0x21E6, 0x05: 0x1FBBD,
    0x06: 0x1FBBE, 0x07: 0x1FBBF, 0x08: 0x2713, 0x09: 0x1F552, 0x0A: 0x1F514,
    0x0B: 0x266A, 0x0C: 0x240C, 0x0D: 0x240D, 0x1A: 0x0259, 0x1B: 0x241B,
}
ATARI_HIGH = (
    "ÇüéâäàåçêëèïîìÄÅ" "ÉæÆôöòûùÿÖÜ¢£¥ßƒ" "áíóúñÑªº¿⌐¬½¼¡«»" "ãõØøœŒÀÃÕ¨´†¶©®™"
    "ĳĲאבגדהוזחטיכלמנ" "סעפצקרשתןךםףץ§∧∞" "αβΓπΣσµτΦΘΩδ∮ϕ∈∩" "≡±≥≤⌠⌡÷≈°∙·√ⁿ²³¯"
)


def atari_char(c):
    if c < 0 or c > 0xFF:
        return "�"
    if 0x20 <= c < 0x7F:
        return chr(c)
    if c == 0x7F:
        return "⌂"
    if c >= 0x80:
        return ATARI_HIGH[c - 0x80]
    if 0x10 <= c <= 0x19:
        return chr(0x1FBF0 + c - 0x10)
    if c in ATARI_LOW:
        return chr(ATARI_LOW[c])
    return "�"


def atari_str(codes):
    return "".join(atari_char(c) for c in codes)


VDI_COLORS = ["#FFFFFF", "#000000", "#FF0000", "#00FF00", "#0000FF", "#00FFFF", "#FFFF00", "#FF00FF",
              "#C0C0C0", "#808080", "#800000", "#008000", "#000080", "#008080", "#808000", "#800080"]

ATTR_OPS = {3, 4, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 32, 39,
            104, 106, 107, 108, 112, 113, 114, 129}
GDP_SHAPES = {1: {(2, 0)}, 2: {(4, 2)}, 3: {(4, 2)}, 4: {(3, 0)}, 5: {(2, 0)}, 6: {(2, 2)},
              7: {(2, 2)}, 8: {(2, 0)}, 9: {(2, 0)}, 13: {(0, 0), (1, 0)}}
GDP_NAMES = {1: "bar", 2: "arc", 3: "pie", 4: "circle", 5: "ellipse", 6: "elliptical arc",
             7: "elliptical pie", 8: "rounded box", 9: "filled rounded box", 10: "justified text",
             13: "bezier on/off"}
DH_ESCAPE = 18500  # non-standard escape after which coordinates are 64-bit floats


class Item:
    __slots__ = ("pos", "op", "np", "ni", "sub", "pts", "ints")

    def __init__(self, pos, op, np_, ni, sub, pts, ints):
        self.pos, self.op, self.np, self.ni, self.sub, self.pts, self.ints = pos, op, np_, ni, sub, pts, ints


def item_valid(w, p, n):
    """Returns item length in words if the item at p has a plausible opcode and shape, else 0."""
    if p + 4 > n:
        return 0
    op, np_, ni, sub = w[p:p + 4]
    if np_ < 0 or ni < 0 or np_ > 8192 or ni > 8192:
        return 0
    ln = 4 + 2 * np_ + ni
    if p + ln > n:
        return 0
    if op == 5:
        ok = np_ <= 4 and ni <= 512 and (1 <= sub <= 103 or sub == DH_ESCAPE)
        if ok and sub == 99:
            ok = ni >= 1
    elif op in (6, 7, 9):
        ok = np_ >= 1 and (ni == 0 or ni == (np_ + 1) // 2)
    elif op == 8:
        ok = np_ == 1 and ni <= 512
    elif op == 11:
        if sub == 10:
            ok = np_ == 2 and 2 <= ni <= 512
        else:
            ok = (np_, ni) in GDP_SHAPES.get(sub, ())
    elif op in ATTR_OPS:
        ok = np_ <= 2 and ni <= 64
    else:
        ok = False
    return ln if ok else 0


def chain_ok(w, p, n, count):
    for _ in range(count):
        if p == n - 1 and w[p] == -1:
            return True
        ln = item_valid(w, p, n)
        if not ln:
            return False
        p += ln
    return True


def text_fragments(w, a, b):
    out, run = [], []
    for c in list(w[a:b]) + [0]:
        if 32 <= c < 127:
            run.append(c)
        else:
            if len(run) >= 3 and any(chr(x).isalpha() for x in run):
                out.append(atari_str(run))
            run = []
    return out


def parse(data):
    n = len(data) // 2
    w = struct.unpack("<%dh" % n, data[:n * 2])
    if n < 4 or w[0] != -1:
        raise ValueError("not a GEM metafile (no FFFF id)")
    hl = w[1]
    hdr = {"hlen": hl, "version": w[2], "ndcrc": w[3], "ext": w[4:8], "page": w[8:10],
           "window": w[10:14] if hl >= 14 else None, "bitimage": w[14] if hl > 14 else None}
    items, notes, damage = [], [], []
    p = hl
    ended = False
    dh = False
    while p < n:
        if w[p] == -1:
            rest = w[p + 1:]
            if not rest or all(x in (0, -1) for x in rest):
                ended = True
                break
            notes.append("premature end marker at word %d with %d words following" % (p, len(rest)))
        ln = item_valid(w, p, n) if w[p] != -1 else 0
        if not ln:
            q = p + 1
            while q < n and not chain_ok(w, q, n, 6):
                q += 1
            frag = text_fragments(w, p, q)
            damage.append((p, q, frag))
            if q >= n:
                p = n
                break
            p = q
            continue
        op, np_, ni, sub = w[p:p + 4]
        pts = w[p + 4:p + 4 + 2 * np_]
        ints = w[p + 4 + 2 * np_:p + ln]
        if op == 5 and sub == DH_ESCAPE:
            dh = True
        if dh and op in (6, 7, 9) and np_ % 4 == 0:
            raw = data[2 * (p + 4):2 * (p + 4 + 2 * np_)]
            # each double is stored with its bytes swapped pairwise
            sw = bytes(raw[i ^ 1] for i in range(len(raw)))
            pts = struct.unpack("<%dd" % (np_ // 2), sw)
            items.append(Item(p, op, np_ // 4, ni, sub, pts, ints))
        else:
            items.append(Item(p, op, np_, ni, sub, pts, ints))
        p += ln
    if not ended:
        notes.append("no end marker (file truncated or damaged)")
    return hdr, items, notes, damage, n, dh


def ellipse_point(cx, cy, rx, ry, tenths):
    a = math.radians(tenths / 10.0)
    return cx + rx * math.cos(a), cy - ry * math.sin(a)


class Renderer:
    def __init__(self, hdr, items, dh):
        self.hdr, self.items, self.dh = hdr, items, dh
        win = hdr["window"]
        # y axis orientation from the coordinate window; PageStream writes a y-up window
        # although its coordinates grow downward
        self.ydown = True
        if win and win[1] < win[3] and not self.pagestream_like():
            self.ydown = False
        self.upm = None
        if win and hdr["page"][0] > 0 and win[2] != win[0] and not dh:
            self.upm = abs(win[2] - win[0]) / (hdr["page"][0] / 10.0)
        self.prims = []
        self.texts = []
        self.counts = Counter()
        self.bitimages = []

    def pagestream_like(self):
        win = self.hdr["window"]
        return win[0] == 0 and win[1] == 0 and self.hdr["ext"][0] == 0 and self.hdr["ext"][1] == 0

    def Y(self, y):
        return y if self.ydown else -y

    def pairs(self, pts):
        return [(pts[i], self.Y(pts[i + 1])) for i in range(0, len(pts) - 1, 2)]

    def run(self):
        st = dict(lt=1, lw=1, lc=1, le=(0, 0), ud=0xFFFF, fi=0, fs=1, fc=1, perim=1,
                  font=1, pt=None, th=None, rot=0, tc=1, eff=0, align=(0, 0), wr=1)
        block = 0
        in_block = False
        for it in self.items:
            op, sub, pts, ints = it.op, it.sub, it.pts, it.ints
            g = ints[0] if ints else None
            if op == 15 and ints:
                st["lt"] = g
            elif op == 16 and pts:
                st["lw"] = abs(pts[0])
            elif op == 17 and ints:
                st["lc"] = g
            elif op == 108 and len(ints) >= 2:
                st["le"] = (ints[0], ints[1])
            elif op == 113 and ints:
                st["ud"] = g & 0xFFFF
            elif op == 23 and ints:
                st["fi"] = g
            elif op == 24 and ints:
                st["fs"] = g
            elif op == 25 and ints:
                st["fc"] = g
            elif op == 104 and ints:
                st["perim"] = g
            elif op == 21 and ints:
                st["font"] = g
            elif op == 107 and ints:
                st["pt"], st["th"] = g, None
            elif op == 12 and len(pts) >= 2:
                st["th"], st["pt"] = abs(pts[1]), None
            elif op == 13 and ints:
                st["rot"] = g
            elif op == 22 and ints:
                st["tc"] = g
            elif op == 106 and ints:
                st["eff"] = g
            elif op == 39 and len(ints) >= 2:
                st["align"] = (ints[0], ints[1])
            elif op == 32 and ints:
                st["wr"] = g
            elif op == 129:
                if ints and ints[0] and len(pts) >= 4:
                    (x1, y1), (x2, y2) = self.pairs(pts[:4])
                    self.prims.append(("clip", (min(x1, x2), min(y1, y2), abs(x2 - x1), abs(y2 - y1))))
                else:
                    self.prims.append(("clip", None))
                self.counts["clip"] += 1
            elif op == 6:
                self.counts["polyline" + (" (bezier)" if ints else "")] += 1
                self.polyline(st, pts, ints)
            elif op == 9:
                self.counts["fill area" + (" (bezier)" if ints else "")] += 1
                self.fill_path(st, [self.bez_path(pts, ints) if ints else self.poly_path(pts)], close=True)
            elif op == 114 and len(pts) >= 4:
                self.counts["filled rectangle"] += 1
                self.fill_path(st, [self.rect_path(pts)], close=True, perimeter=False)
            elif op == 7:
                self.counts["polymarker"] += 1
                for x, y in self.pairs(pts):
                    self.prims.append(("path", [[("M", x - 20, y), ("L", x + 20, y)], [("M", x, y - 20), ("L", x, y + 20)]],
                                       self.line_style(st), None))
            elif op == 8 and len(pts) >= 2:
                self.counts["text"] += 1
                self.text(st, pts[0], pts[1], atari_str(ints), None, block if in_block else None)
            elif op == 11:
                self.gdp(st, sub, pts, ints, block if in_block else None)
            elif op == 5 and sub == 99 and ints:
                self.counts["write_meta %d" % g] += 1
                if g == 152:
                    block += 1
                    in_block = True
                elif g == 153:
                    in_block = False
            elif op == 5 and sub == 101 and len(ints) >= 5 and len(pts) >= 4:
                name = atari_str(ints[5:]).rstrip("\x00�")
                (x1, y1), (x2, y2) = self.pairs(pts[:4])
                self.bitimages.append((name, pts[:4]))
                self.counts["bit image"] += 1
                self.prims.append(("path", [[("M", x1, y1), ("L", x2, y1), ("L", x2, y2), ("L", x1, y2), ("Z",)]],
                                   {"stroke": "#808080", "sw": 0, "dash": "img", "fill": "none"}, None))
                self.prims.append(("text", dict(x=min(x1, x2), y=min(y1, y2), s="[image %s]" % name, pt=None, th=None,
                                                font=1, bold=False, italic=False, under=False, color="#808080",
                                                anchor="start", baseline="hanging", length=None, rot=0)))
            elif op == 5:
                self.counts["escape %d" % sub] += 1
        return self

    # geometry helpers
    def poly_path(self, pts):
        pp = self.pairs(pts)
        if not pp:
            return []
        return [("M",) + pp[0]] + [("L",) + q for q in pp[1:]]

    def bez_path(self, pts, ints):
        pp = self.pairs(pts)
        # one flag byte per vertex, packed low byte first: bit0 starts a cubic segment, bit1 starts a subpath
        flags = []
        for v in ints:
            v &= 0xFFFF
            flags += [v & 0xFF, v >> 8]
        path = []
        i = 0
        while i < len(pp):
            f = flags[i] if i < len(flags) else 0
            if i == 0 or f & 2:
                path.append(("M",) + pp[i])
            else:
                path.append(("L",) + pp[i])
            if f & 1 and i + 3 < len(pp):
                path.append(("C",) + pp[i + 1] + pp[i + 2] + pp[i + 3])
                i += 3
            else:
                i += 1
        return path

    def rect_path(self, pts):
        (x1, y1), (x2, y2) = self.pairs(pts[:4])
        return [("M", x1, y1), ("L", x2, y1), ("L", x2, y2), ("L", x1, y2), ("Z",)]

    def ellipse_path(self, cx, cy, rx, ry, a1=None, a2=None, pie=False):
        cy = self.Y(cy)
        ext = [("B", cx - rx, cy - ry), ("B", cx + rx, cy + ry)]
        if a1 is None or (a2 - a1) % 3600 == 0 and a1 != a2:
            return [("M", cx + rx, cy), ("A", rx, ry, 0, 1, 0, cx - rx, cy), ("A", rx, ry, 0, 1, 0, cx + rx, cy), ("Z",)] + ext
        x1, y1 = ellipse_point(cx, cy, rx, ry, a1)
        x2, y2 = ellipse_point(cx, cy, rx, ry, a2)
        large = 1 if (a2 - a1) % 3600 > 1800 else 0
        path = [("M", cx, cy), ("L", x1, y1)] if pie else [("M", x1, y1)]
        path.append(("A", rx, ry, 0, large, 0, x2, y2))
        if pie:
            path.append(("Z",))
        return path + ext

    def line_style(self, st):
        return {"stroke": VDI_COLORS[st["lc"] % 16], "sw": st["lw"], "dash": st["lt"],
                "cap": "round" if 2 in st["le"] else "butt", "fill": "none"}

    def fill_style(self, st):
        fi, fs, fc, wr = st["fi"], st["fs"], VDI_COLORS[st["fc"] % 16], st["wr"]
        transparent = wr in (2, 4)
        if fi == 0:
            return None if transparent else ("#FFFFFF", 1.0)
        if fi == 1:
            return (fc, 1.0)
        if fi == 2:
            dens = {1: 0.06, 2: 0.12, 3: 0.25, 4: 0.37, 5: 0.5, 6: 0.62, 7: 0.75, 8: 1.0}.get(fs, 0.5)
        elif fi == 3:
            dens = 0.3
        else:
            dens = 0.5
        if dens >= 1.0:
            return (fc, 1.0)
        if transparent:
            return (fc, dens)
        return (mix_white(fc, dens), 1.0)

    def fill_path(self, st, subpaths, close=True, perimeter=None):
        fill = self.fill_style(st)
        path = [p for sp in subpaths for p in sp]
        if not path:
            return
        if close and "Z" not in [seg[0] for seg in path[-3:]]:
            path = path + [("Z",)]
        per = st["perim"] if perimeter is None else perimeter
        style = {"stroke": VDI_COLORS[st["fc"] % 16] if per else "none", "sw": 0, "dash": 1, "cap": "butt",
                 "fill": fill[0] if fill else "none", "fop": fill[1] if fill else 1.0}
        if not fill and not per:
            return
        self.prims.append(("path", [path], style, None))

    def polyline(self, st, pts, ints):
        path = self.bez_path(pts, ints) if ints else self.poly_path(pts)
        if len(path) < 2:
            return
        heads = []
        pp = self.pairs(pts)
        if st["le"][0] == 1 and len(pp) >= 2:
            heads.append(arrow_dir(pp, 0))
        if st["le"][1] == 1 and len(pp) >= 2:
            heads.append(arrow_dir(pp, -1))
        self.prims.append(("path", [path], self.line_style(st), [h for h in heads if h]))

    def gdp(self, st, sub, pts, ints, block):
        self.counts[GDP_NAMES.get(sub, "gdp %d" % sub)] += 1
        if sub in (5, 6, 7) and len(pts) >= 4 and pts[2] == 0 and pts[3] == 0:
            return
        if sub == 1 and len(pts) >= 4:
            self.fill_path(st, [self.rect_path(pts)])
        elif sub in (2, 3) and len(pts) >= 8 and len(ints) >= 2:
            r = abs(pts[6])
            path = self.ellipse_path(pts[0], pts[1], r, r, ints[0], ints[1], pie=(sub == 3))
            if sub == 2:
                self.prims.append(("path", [path], self.line_style(st), None))
            else:
                self.fill_path(st, [path])
        elif sub == 4 and len(pts) >= 6:
            r = abs(pts[4])
            self.fill_path(st, [self.ellipse_path(pts[0], pts[1], r, r)])
        elif sub == 5 and len(pts) >= 4:
            self.fill_path(st, [self.ellipse_path(pts[0], pts[1], abs(pts[2]), abs(pts[3]))])
        elif sub in (6, 7) and len(pts) >= 4 and len(ints) >= 2:
            path = self.ellipse_path(pts[0], pts[1], abs(pts[2]), abs(pts[3]), ints[0], ints[1], pie=(sub == 7))
            if sub == 6:
                self.prims.append(("path", [path], self.line_style(st), None))
            else:
                self.fill_path(st, [path])
        elif sub in (8, 9) and len(pts) >= 4:
            (x1, y1), (x2, y2) = self.pairs(pts[:4])
            x1, x2 = min(x1, x2), max(x1, x2)
            y1, y2 = min(y1, y2), max(y1, y2)
            r = min((x2 - x1) / 2.0, (y2 - y1) / 2.0, (self.upm or 40) * 1.5)
            path = [("M", x1 + r, y1), ("L", x2 - r, y1), ("A", r, r, 0, 0, 1, x2, y1 + r), ("L", x2, y2 - r),
                    ("A", r, r, 0, 0, 1, x2 - r, y2), ("L", x1 + r, y2), ("A", r, r, 0, 0, 1, x1, y2 - r),
                    ("L", x1, y1 + r), ("A", r, r, 0, 0, 1, x1 + r, y1), ("Z",)]
            if sub == 8:
                self.prims.append(("path", [path], self.line_style(st), None))
            else:
                self.fill_path(st, [path])
        elif sub == 10 and len(pts) >= 4 and len(ints) >= 2:
            self.text(st, pts[0], pts[1], atari_str(ints[2:]), abs(pts[2]), block)

    def text(self, st, x, y, s, length, block):
        if st["pt"]:
            size_desc = "%dpt" % st["pt"]
        elif st["th"]:
            size_desc = "h%d" % st["th"]
        else:
            size_desc = "-"
        self.texts.append(dict(x=x, y=y, s=s, size=size_desc, font=st["font"], eff=st["eff"],
                               rot=st["rot"], block=block))
        ha, va = st["align"]
        self.prims.append(("text", dict(
            x=x, y=self.Y(y), s=s, pt=st["pt"], th=st["th"], font=st["font"],
            bold=bool(st["eff"] & 1), italic=bool(st["eff"] & 4), under=bool(st["eff"] & 8),
            color=VDI_COLORS[st["tc"] % 16] if not st["eff"] & 2 else "#808080",
            anchor={1: "middle", 2: "end"}.get(ha, "start"),
            baseline={1: "central", 2: "hanging", 3: "text-after-edge", 4: "ideographic",
                      5: "text-before-edge"}.get(va, None),
            length=length, rot=st["rot"])))


def mix_white(color, dens):
    r, g, b = int(color[1:3], 16), int(color[3:5], 16), int(color[5:7], 16)
    f = lambda c: int(round(255 - (255 - c) * dens))
    return "#%02X%02X%02X" % (f(r), f(g), f(b))


def arrow_dir(pp, idx):
    if idx == 0:
        tip = pp[0]
        others = pp[1:]
    else:
        tip = pp[-1]
        others = list(reversed(pp[:-1]))
    for q in others:
        dx, dy = tip[0] - q[0], tip[1] - q[1]
        d = math.hypot(dx, dy)
        if d > 0:
            return (tip[0], tip[1], dx / d, dy / d)
    return None


def fmt(v):
    if isinstance(v, int):
        return str(v)
    s = "%.2f" % v
    s = s.rstrip("0").rstrip(".")
    return "0" if s == "-0" else s


def path_d(path):
    out = []
    for seg in path:
        if seg[0] != "B":
            out.append(seg[0] + " ".join(fmt(v) for v in seg[1:]))
    return "".join(out)


def xml_esc(s):
    s = "".join(ch if (ch in "\t\n" or ord(ch) >= 0x20) else "�" for ch in s)
    return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace('"', "&quot;")


def path_points(path):
    for seg in path:
        c = seg[0]
        if c in "ML":
            yield seg[1], seg[2]
        elif c == "C":
            yield seg[1], seg[2]
            yield seg[3], seg[4]
            yield seg[5], seg[6]
        elif c == "A":
            yield seg[6], seg[7]
        elif c == "B":
            yield seg[1], seg[2]


def font_units(t, upm):
    if t["pt"]:
        return t["pt"] * upm * 25.4 / 72.0
    if t["th"]:
        return t["th"] / 0.72
    return 10 * upm * 25.4 / 72.0


def prim_bbox(pr, upm):
    xs, ys = [], []
    if pr[0] == "path":
        for path in pr[1]:
            for x, y in path_points(path):
                xs.append(x)
                ys.append(y)
    elif pr[0] == "text":
        t = pr[1]
        fu = font_units(t, upm or 40)
        xs += [t["x"], t["x"] + (t["length"] or fu * 0.6 * len(t["s"]))]
        ys += [t["y"] - fu * 0.8, t["y"] + fu * 0.2]
    if not xs:
        return None
    return min(xs), min(ys), max(xs), max(ys)


def compute_bbox(r):
    bb = None
    clip = None
    for pr in r.prims:
        if pr[0] == "clip":
            clip = pr[1]
            continue
        b = prim_bbox(pr, r.upm)
        if b is None:
            continue
        if clip:
            b = (max(b[0], clip[0]), max(b[1], clip[1]), min(b[2], clip[0] + clip[2]), min(b[3], clip[1] + clip[3]))
            if b[0] > b[2] or b[1] > b[3]:
                continue
        bb = b if bb is None else (min(bb[0], b[0]), min(bb[1], b[1]), max(bb[2], b[2]), max(bb[3], b[3]))
    return bb


def render_svg(r, title):
    bb = compute_bbox(r)
    if bb is None:
        bb = (0, 0, 100, 100)
    x0, y0, x1, y1 = bb
    w, h = max(x1 - x0, 1), max(y1 - y0, 1)
    upm = r.upm
    if not upm or not (5 <= w / upm <= 2000):
        upm = max(w, h) / 250.0
    # text needs extra room above the baseline
    fu_max = 0
    for pr in r.prims:
        if pr[0] == "text":
            fu_max = max(fu_max, font_units(pr[1], upm))
    m = max(w, h) * 0.02 + fu_max
    x0, y0, w, h = x0 - m, y0 - m, w + 2 * m, h + 2 * m
    minw = 0.2 * upm
    out = ['<?xml version="1.0" encoding="UTF-8"?>',
           '<svg xmlns="http://www.w3.org/2000/svg" version="1.1" width="%smm" height="%smm" viewBox="%s %s %s %s">'
           % (fmt(w / upm), fmt(h / upm), fmt(x0), fmt(y0), fmt(w), fmt(h)),
           "<title>%s</title>" % xml_esc(title),
           '<rect x="%s" y="%s" width="%s" height="%s" fill="#FFFFFF"/>' % (fmt(x0), fmt(y0), fmt(w), fmt(h))]
    dashes = {2: (3.0, 1.0), 3: (0.3, 0.8), 4: (2.0, 0.8, 0.3, 0.8), 5: (1.5, 1.0), 6: (2.0, 0.6, 0.3, 0.6, 0.3, 0.6),
              7: (1.0, 1.0), "img": (1.0, 1.0)}
    open_group = False
    clip_n = 0
    pending = None  # (style_key, attrs, [d...])

    def flush():
        nonlocal pending
        if pending:
            out.append('<path d="%s"%s/>' % ("".join(pending[2]), pending[1]))
            pending = None

    for pr in r.prims:
        kind = pr[0]
        if kind == "clip":
            flush()
            if open_group:
                out.append("</g>")
                open_group = False
            if pr[1]:
                clip_n += 1
                cx, cy, cw, ch = pr[1]
                out.append('<clipPath id="c%d"><rect x="%s" y="%s" width="%s" height="%s"/></clipPath>'
                           % (clip_n, fmt(cx), fmt(cy), fmt(cw), fmt(ch)))
                out.append('<g clip-path="url(#c%d)">' % clip_n)
                open_group = True
            continue
        if kind == "path":
            _, paths, s, heads = pr
            sw = max(s["sw"], minw)
            attrs = ' fill="%s"' % s["fill"]
            if s["fill"] != "none" and s.get("fop", 1.0) < 1.0:
                attrs += ' fill-opacity="%s"' % fmt(s["fop"])
            if s["fill"] != "none":
                attrs += ' fill-rule="evenodd"'
            if s["stroke"] != "none":
                attrs += ' stroke="%s" stroke-width="%s"' % (s["stroke"], fmt(float(sw)))
                if s.get("cap") == "round":
                    attrs += ' stroke-linecap="round" stroke-linejoin="round"'
                dp = dashes.get(s["dash"])
                if dp:
                    attrs += ' stroke-dasharray="%s"' % ",".join(fmt(v * upm) for v in dp)
            d = "".join(path_d(p) for p in paths)
            if heads:
                flush()
                out.append('<path d="%s"%s/>' % (d, attrs))
                al = max(6 * sw, 1.6 * upm)
                for tx, ty, ux, uy in heads:
                    bx, by = tx - ux * al, ty - uy * al
                    px, py = -uy * al * 0.35, ux * al * 0.35
                    out.append('<path d="M%s %sL%s %sL%s %sZ" fill="%s"/>'
                               % (fmt(tx), fmt(ty), fmt(bx + px), fmt(by + py), fmt(bx - px), fmt(by - py), s["stroke"]))
                continue
            if s["fill"] == "none":
                if pending and pending[0] == attrs:
                    pending[2].append(d)
                else:
                    flush()
                    pending = (attrs, attrs, [d])
            else:
                flush()
                out.append('<path d="%s"%s/>' % (d, attrs))
            continue
        if kind == "text":
            flush()
            t = pr[1]
            fu = font_units(t, upm)
            fam = {14: "'Times New Roman',Times,serif", 1: "'Courier New',monospace"}.get(t["font"], "Arial,Helvetica,sans-serif")
            a = ' x="%s" y="%s" font-family="%s" font-size="%s" fill="%s"' % (fmt(t["x"]), fmt(t["y"]), fam, fmt(float(fu)), t["color"])
            if t["bold"]:
                a += ' font-weight="bold"'
            if t["italic"]:
                a += ' font-style="italic"'
            if t["under"]:
                a += ' text-decoration="underline"'
            if t["anchor"] != "start":
                a += ' text-anchor="%s"' % t["anchor"]
            if t["baseline"]:
                a += ' dominant-baseline="%s"' % t["baseline"]
            if t["length"] and len(t["s"].strip()) > 0:
                a += ' textLength="%s" lengthAdjust="spacingAndGlyphs"' % fmt(t["length"])
            if t["rot"]:
                a += ' transform="rotate(%s %s %s)"' % (fmt(-t["rot"] / 10.0), fmt(t["x"]), fmt(t["y"]))
            out.append('<text xml:space="preserve"%s>%s</text>' % (a, xml_esc(t["s"])))
    flush()
    if open_group:
        out.append("</g>")
    out.append("</svg>")
    return "\n".join(out) + "\n", bb


def summarize(rel, hdr, r, notes, damage, nwords, dh, bb, nitems):
    L = []
    ver = hdr["version"]
    L.append("File: %s" % rel)
    L.append("Format: GEM Metafile version %d.%02d, %d-word header, %s coordinates (flag %d)%s"
             % (ver // 100, ver % 100, hdr["hlen"], {0: "NDC", 2: "RC"}.get(hdr["ndcrc"], "unknown"), hdr["ndcrc"],
                "; non-standard escape %d: coordinates stored as 64-bit floats" % DH_ESCAPE if dh else ""))
    e = hdr["ext"]
    L.append("Header extents: (%d,%d)-(%d,%d)" % tuple(e))
    L.append("Page size: %.1f x %.1f mm" % (hdr["page"][0] / 10.0, hdr["page"][1] / 10.0))
    if hdr["window"]:
        wn = hdr["window"]
        L.append("Coordinate window: lower-left (%d,%d), upper-right (%d,%d); rendered with y axis %s%s"
                 % (tuple(wn) + ("down" if r.ydown else "up",
                                 ", %.2f units/mm" % r.upm if r.upm else "")))
    if bb:
        L.append("Drawing bounding box (%s): (%s,%s)-(%s,%s)" % ("SVG coordinates" if not r.ydown else "file units",
                                                                 fmt(bb[0]), fmt(bb[1]), fmt(bb[2]), fmt(bb[3])))
    L.append("Items: %d (%d words)" % (nitems, nwords))
    main = ["polyline", "polyline (bezier)", "fill area", "fill area (bezier)", "filled rectangle", "polymarker",
            "text", "bar", "arc", "pie", "circle", "ellipse", "elliptical arc", "elliptical pie", "rounded box",
            "filled rounded box", "justified text", "bit image"]
    objs = ["%s %d" % (k, r.counts[k]) for k in main if r.counts.get(k)]
    L.append("Objects: " + (", ".join(objs) if objs else "none"))
    other = sorted((k, v) for k, v in r.counts.items() if k not in main)
    if other:
        L.append("Other records (escapes, application data): " + ", ".join("%s x%d" % kv for kv in other))
    for name, pts in r.bitimages:
        L.append("Bit image reference: %s at (%d,%d)-(%d,%d)" % ((name,) + tuple(pts)))
    for nt in notes:
        L.append("Warning: " + nt)
    if damage:
        L.append("Warning: damaged file; data blocks belonging to other drawings may appear in the text list and the render")
    if dh:
        L.append("Warning: float-coordinate variant is not documented; its render is unverified")
    for a, b, frag in damage:
        L.append("Warning: damaged data skipped, words %d-%d%s" % (a, b, ("; text fragments in skipped data: "
                                                                          + " | ".join('"%s"' % f for f in frag)) if frag else ""))
    L.append("Text strings: %d" % len(r.texts))
    L.append("")
    if r.texts:
        L.append("TEXT (drawing order; x y = file units of the text start point; blank line between text blocks)")
        prev = r.texts[0]["block"]
        for t in r.texts:
            if t["block"] != prev:
                L.append("")
            prev = t["block"]
            extra = []
            if t["rot"]:
                extra.append("rot %s" % fmt(t["rot"] / 10.0))
            fx = "font %d %s%s" % (t["font"], t["size"], " bold" if t["eff"] & 1 else "")
            if extra:
                fx += " " + " ".join(extra)
            L.append("%7d %7d  [%s]  %s" % (t["x"], t["y"], fx, t["s"]))
    else:
        L.append("No text objects in this file (any lettering is drawn as vector strokes or outlines).")
    return "\n".join(L).rstrip("\n") + "\n"


def transcribed_labels(rel):
    path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "labels", rel + ".txt")
    if not os.path.exists(path):
        return ""
    body = open(path, encoding="utf-8").read().strip("\n")
    return ("\nLABELS READ FROM THE RENDERED IMAGE (lettering here is vector graphics, not text data; "
            "transcribed visually in reading order, may contain reading errors)\n" + body + "\n")


def convert(src, outbase, rel):
    data = open(src, "rb").read()
    hdr, items, notes, damage, nwords, dh = parse(data)
    r = Renderer(hdr, items, dh).run()
    svg, bb = render_svg(r, rel)
    txt = summarize(rel, hdr, r, notes, damage, nwords, dh, compute_bbox(r), len(items)) + transcribed_labels(rel)
    os.makedirs(os.path.dirname(outbase) or ".", exist_ok=True)
    with open(outbase + ".svg", "w", encoding="utf-8", newline="\n") as f:
        f.write(svg)
    with open(outbase + ".txt", "w", encoding="utf-8", newline="\n") as f:
        f.write(txt)
    return notes, damage


def main(argv):
    if len(argv) == 4 and argv[0] == "--list":
        lst, srcroot, outroot = argv[1:]
        ok = fail = 0
        for rel in [l.strip() for l in open(lst) if l.strip()]:
            try:
                notes, damage = convert(os.path.join(srcroot, rel), os.path.join(outroot, rel), rel)
                ok += 1
                if notes or damage:
                    print("%s: %s" % (rel, "; ".join(notes + ["damaged words %d-%d" % (a, b) for a, b, _ in damage])))
            except Exception as ex:
                fail += 1
                print("FAIL %s: %s" % (rel, ex))
        print("converted %d, failed %d" % (ok, fail))
        return 1 if fail else 0
    if len(argv) == 2:
        convert(argv[0], argv[1], os.path.basename(argv[0]))
        return 0
    print(__doc__ or "usage: gem_decode.py FILE.GEM OUTBASE | --list LISTFILE SRCROOT OUTROOT")
    return 2


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
