#!/usr/bin/env python3
# ABOUTME: Converts HP-GL plotter files into a readable text summary and an SVG rendering.
# ABOUTME: Usage: hpgl2txt.py SRC_ROOT LIST_FILE OUT_ROOT (list lines are paths relative to SRC_ROOT).

import html
import math
import os
import re
import sys
from collections import Counter

ESC = '\x1b'
ETX = '\x03'
PLU_PER_MM = 40.0
PLU_PER_INCH = 1016.0

DEVICE_CONTROL = {
    '(': 'Plotter On', 'Y': 'Plotter On', ')': 'Plotter Off', 'Z': 'Plotter Off',
    '@': 'Set Plotter Configuration', 'A': 'Output Identification',
    'B': 'Output Buffer Space', 'E': 'Output Extended Error',
    'H': 'Set Handshake Mode 1', 'I': 'Set Handshake Mode 2',
    'J': 'Abort Device Control', 'K': 'Abort Graphics', 'L': 'Output Buffer Size',
    'M': 'Set Output Mode', 'N': 'Set Extended Output and Handshake Mode',
    'O': 'Output Extended Status', 'R': 'Reset Handshake',
    'S': 'Output Configurable Memory Size', 'T': 'Allocate Configurable Memory',
}
DEVICE_CONTROL_WITH_PARAMS = '@HIMNT'

MNEMONICS = {
    'AA': 'Arc Absolute', 'AR': 'Arc Relative', 'AF': 'Advance Full Page',
    'CA': 'Designate Alternate Character Set', 'CI': 'Circle', 'CP': 'Character Plot',
    'CS': 'Designate Standard Character Set', 'DF': 'Default', 'DI': 'Absolute Direction',
    'DR': 'Relative Direction', 'DT': 'Define Label Terminator', 'EA': 'Edge Rectangle Absolute',
    'EC': 'Enable Cutter', 'ER': 'Edge Rectangle Relative', 'EW': 'Edge Wedge',
    'FT': 'Fill Type', 'IN': 'Initialize', 'IP': 'Input P1 and P2', 'IW': 'Input Window',
    'LB': 'Label', 'LO': 'Label Origin', 'LT': 'Line Type', 'NR': 'Not Ready',
    'PA': 'Plot Absolute', 'PD': 'Pen Down', 'PE': 'Polyline Encoded', 'PG': 'Advance Page',
    'PM': 'Polygon Mode', 'PR': 'Plot Relative', 'PS': 'Plot Size', 'PT': 'Pen Thickness',
    'PU': 'Pen Up', 'PW': 'Pen Width', 'RA': 'Fill Rectangle Absolute', 'RO': 'Rotate',
    'RR': 'Fill Rectangle Relative', 'SA': 'Select Alternate Character Set', 'SC': 'Scale',
    'SI': 'Absolute Character Size', 'SL': 'Character Slant', 'SP': 'Select Pen',
    'SR': 'Relative Character Size', 'SS': 'Select Standard Character Set',
    'TL': 'Tick Length', 'VS': 'Velocity Select', 'WG': 'Fill Wedge', 'XT': 'X Tick',
    'YT': 'Y Tick',
}
RENDERED = {'AA', 'AR', 'CI', 'DF', 'DI', 'DR', 'DT', 'IN', 'IP', 'LB', 'PA', 'PD', 'PR',
            'PU', 'SC', 'SI', 'SP', 'SR'}
NO_GRAPHIC_EFFECT = {'VS', 'EC', 'PG', 'AF', 'NR', 'CS', 'CA', 'SS', 'SA'}

# HP 7475A defaults for A-size paper
DEFAULT_P1 = (250.0, 596.0)
DEFAULT_P2 = (10250.0, 7796.0)
DEFAULT_SI_CM = (0.187, 0.269)
DEFAULT_SR_PCT = (0.75, 1.5)

PEN_COLORS = {1: '#000000', 2: '#d00000', 3: '#008000', 4: '#0030d0', 5: '#008b8b',
              6: '#b000b0', 7: '#b8860b', 8: '#ff7f00'}

PARAM_RE = re.compile(r'[\s0-9+\-.,]*')
ESC_PARAM_RE = re.compile(r'[0-9;]*:?')
PCL_ESC_RE = re.compile(r'%-?[0-9]*[A-Za-z]')


def tokenize(s):
    """Yield (kind, offset, name, data) tuples: kind is 'esc', 'cmd' or 'junk'."""
    i, n, term = 0, len(s), ETX
    while i < n:
        c = s[i]
        if c == ESC:
            nxt = s[i + 1:i + 2]
            if nxt == '.' and i + 2 < n:
                letter = s[i + 2]
                j = i + 3
                params = ''
                if letter in DEVICE_CONTROL_WITH_PARAMS:
                    m = ESC_PARAM_RE.match(s, j)
                    params, j = m.group(0), m.end()
                yield ('esc', i, 'ESC.' + letter + params,
                       DEVICE_CONTROL.get(letter, 'unknown device-control instruction'))
                i = j
                continue
            m = PCL_ESC_RE.match(s, i + 1)
            if m:
                code = m.group(0)
                desc = {'%-12345X': 'Universal Exit Language', '%0B': 'Enter HP-GL/2 (PCL pen position)',
                        '%1B': 'Enter HP-GL/2 (HP-GL/2 pen position)', '%0A': 'Enter PCL mode',
                        '%1A': 'Enter PCL mode'}.get(code, 'PCL/PJL escape')
                yield ('esc', i, 'ESC' + code, desc)
                i = m.end()
                continue
            if nxt == 'E':
                yield ('esc', i, 'ESC E', 'PCL printer reset')
                i += 2
                continue
            yield ('esc', i, 'ESC', 'unrecognised escape')
            i += 1
            continue
        if c.isalpha() and i + 1 < n and s[i + 1].isalpha():
            mn = (c + s[i + 1]).upper()
            j = i + 2
            if mn == 'LB':
                k = s.find(term, j)
                if k < 0:
                    yield ('cmd', i, mn, s[j:])
                    i = n
                else:
                    yield ('cmd', i, mn, s[j:k])
                    i = k + 1
                continue
            if mn == 'DT':
                if j < n and s[j] not in ';\x00\n\x1b':
                    term = s[j]
                    j += 1
                    m = re.compile(r',[01]').match(s, j)
                    if m:
                        j = m.end()
                else:
                    term = ETX
                if j < n and s[j] == ';':
                    j += 1
                yield ('cmd', i, mn, term)
                i = j
                continue
            m = PARAM_RE.match(s, j)
            raw = m.group(0)
            j = m.end()
            if j < n and s[j] == ';':
                j += 1
            args = []
            for part in re.split(r'[\s,]+', raw.strip()):
                if part:
                    try:
                        args.append(float(part))
                    except ValueError:
                        pass
            if mn in ('IN', 'DF'):
                term = ETX
            yield ('cmd', i, mn, args)
            i = j
            continue
        if c in ' \t\r\n;':
            i += 1
            continue
        yield ('junk', i, c, None)
        i += 1


def fmt(v):
    v = round(v, 3)
    return str(int(v)) if v == int(v) else ('%.3f' % v).rstrip('0').rstrip('.')


def cmd_text(name, data):
    if name == 'LB':
        return 'LB' + escape_label(data)
    if name == 'DT':
        return 'DT' + escape_label(data)
    return name + ','.join(fmt(a) for a in data)


def escape_label(t):
    out = []
    for ch in t:
        o = ord(ch)
        if ch == '\r':
            out.append('\\r')
        elif ch == '\n':
            out.append('\\n')
        elif o < 32 or o == 127:
            out.append('\\x%02x' % o)
        else:
            out.append(ch)
    return ''.join(out)


class Plotter:
    def __init__(self):
        self.strokes = []      # dicts: pen, page, points
        self.labels = []
        self.commands = Counter()
        self.events = []       # (offset, text, meaning) for non-motion commands
        self.pen_selects = Counter()
        self.velocity = []
        self.page = 1
        self.pages_used = set()
        self.moves_ext = None
        self.drawn_ext = None
        self.scale_log = []
        self.ip_log = []
        self.pos = (0.0, 0.0)
        self.pen = 0
        self.reset(full=True)

    def reset(self, full):
        self.down = False
        self.relative = False
        self.cur = None
        self.sc = None
        if full:
            self.p1, self.p2 = DEFAULT_P1, DEFAULT_P2
        self.char_mode = ('SI', DEFAULT_SI_CM)
        self.direction = ('DI', (1.0, 0.0))

    # coordinate transforms
    def xform(self):
        if self.sc is None:
            return (1.0, 0.0, 1.0, 0.0)
        a = self.sc
        p1x, p1y = self.p1
        p2x, p2y = self.p2
        if len(a) >= 5 and int(a[4]) == 2:
            xmin, xf, ymin, yf = a[:4]
            return (xf, p1x - xf * xmin, yf, p1y - yf * ymin)
        xmin, xmax, ymin, ymax = a[:4]
        if xmax == xmin or ymax == ymin:
            return (1.0, 0.0, 1.0, 0.0)
        ax = (p2x - p1x) / (xmax - xmin)
        ay = (p2y - p1y) / (ymax - ymin)
        if len(a) >= 5 and int(a[4]) == 1:
            left = a[5] if len(a) > 5 else 50.0
            bottom = a[6] if len(a) > 6 else 50.0
            f = min(abs(ax), abs(ay))
            fx, fy = math.copysign(f, ax), math.copysign(f, ay)
            spare_x = (p2x - p1x) - fx * (xmax - xmin)
            spare_y = (p2y - p1y) - fy * (ymax - ymin)
            return (fx, p1x + spare_x * left / 100 - fx * xmin,
                    fy, p1y + spare_y * bottom / 100 - fy * ymin)
        return (ax, p1x - ax * xmin, ay, p1y - ay * ymin)

    def to_plu(self, ux, uy):
        ax, bx, ay, by = self.xform()
        return (ax * ux + bx, ay * uy + by)

    def to_user(self, x, y):
        ax, bx, ay, by = self.xform()
        return ((x - bx) / ax, (y - by) / ay)

    def char_size(self):
        mode, (w, h) = self.char_mode
        if mode == 'SI':
            return (w * 400.0, h * 400.0)
        return (w / 100 * (self.p2[0] - self.p1[0]), h / 100 * (self.p2[1] - self.p1[1]))

    def unit_direction(self):
        mode, (run, rise) = self.direction
        if mode == 'DR':
            run *= (self.p2[0] - self.p1[0]) / 100
            rise *= (self.p2[1] - self.p1[1]) / 100
        d = math.hypot(run, rise)
        return (1.0, 0.0) if d == 0 else (run / d, rise / d)

    # drawing primitives
    @staticmethod
    def grow(ext, x, y):
        if ext is None:
            return [x, x, y, y]
        ext[0], ext[1] = min(ext[0], x), max(ext[1], x)
        ext[2], ext[3] = min(ext[2], y), max(ext[3], y)
        return ext

    def end_stroke(self):
        self.cur = None

    def start_stroke(self):
        if self.pen == 0:
            return
        self.cur = {'pen': self.pen, 'page': self.page, 'points': [self.pos]}
        self.strokes.append(self.cur)
        self.pages_used.add(self.page)
        self.drawn_ext = self.grow(self.drawn_ext, *self.pos)

    def move_to(self, x, y):
        if self.down and self.pen != 0:
            if self.cur is None:
                self.start_stroke()
            self.cur['points'].append((x, y))
            self.drawn_ext = self.grow(self.drawn_ext, x, y)
        self.pos = (x, y)
        self.moves_ext = self.grow(self.moves_ext, x, y)

    def pen_state(self, down):
        if down and not self.down:
            self.down = True
            self.start_stroke()
        elif not down:
            self.down = False
            self.end_stroke()

    def arc(self, cx, cy, angle, chord):
        r = math.hypot(self.pos[0] - cx, self.pos[1] - cy)
        a0 = math.atan2(self.pos[1] - cy, self.pos[0] - cx)
        chord = abs(chord) or 5.0
        steps = max(1, int(math.ceil(abs(angle) / chord)))
        for k in range(1, steps + 1):
            a = a0 + math.radians(angle) * k / steps
            self.move_to(cx + r * math.cos(a), cy + r * math.sin(a))

    def run(self, s):
        junk = Counter()
        for kind, off, name, data in tokenize(s):
            if kind == 'junk':
                junk[name] += 1
                continue
            if kind == 'esc':
                self.commands[name] += 1
                self.events.append((off, name, data))
                continue
            self.commands[name] += 1
            self.execute(off, name, data)
        self.end_stroke()
        return junk

    def note(self, off, name, data, meaning):
        self.events.append((off, cmd_text(name, data), meaning))

    def execute(self, off, name, a):
        if name in ('PA', 'PR', 'PU', 'PD'):
            if name == 'PU':
                self.pen_state(False)
            elif name == 'PD':
                self.pen_state(True)
            if name == 'PR':
                self.relative = True
            elif name == 'PA':
                self.relative = False
            rel = self.relative
            ax, _, ay, _ = self.xform()
            for k in range(0, len(a) - 1, 2):
                if rel:
                    self.move_to(self.pos[0] + a[k] * ax, self.pos[1] + a[k + 1] * ay)
                else:
                    self.move_to(*self.to_plu(a[k], a[k + 1]))
            return
        if name == 'SP':
            self.end_stroke()
            self.pen = int(a[0]) if a else 0
            self.pen_selects[self.pen] += 1
            if self.down:
                self.start_stroke()
            meaning = 'select pen %d' % self.pen if self.pen else 'return pen to carousel (no pen)'
            self.note(off, name, a, meaning)
            return
        if name in ('IN', 'DF'):
            self.end_stroke()
            if name == 'IN':
                self.pos = (0.0, 0.0)
            self.reset(full=(name == 'IN'))
            self.note(off, name, a, 'initialize plotter (defaults, scaling off, pen up)'
                      if name == 'IN' else 'set default values')
            return
        if name == 'IP':
            if len(a) >= 4:
                self.p1, self.p2 = (a[0], a[1]), (a[2], a[3])
            elif len(a) >= 2:
                dx, dy = self.p2[0] - self.p1[0], self.p2[1] - self.p1[1]
                self.p1, self.p2 = (a[0], a[1]), (a[0] + dx, a[1] + dy)
            else:
                self.p1, self.p2 = DEFAULT_P1, DEFAULT_P2
            self.ip_log.append((off, cmd_text(name, a), self.p1, self.p2))
            self.note(off, name, a, 'P1=(%s,%s) P2=(%s,%s)' % tuple(map(fmt, self.p1 + self.p2)))
            return
        if name == 'SC':
            self.sc = list(a) if len(a) >= 4 else None
            if self.sc is None:
                meaning = 'scaling off: coordinates are plotter units'
            else:
                ax, bx, ay, by = self.xform()
                meaning = 'user units: x_plu = %s*x + %s, y_plu = %s*y + %s' % tuple(
                    map(fmt, (ax, bx, ay, by)))
            self.scale_log.append((off, cmd_text(name, a), meaning))
            self.note(off, name, a, meaning)
            return
        if name == 'SI':
            self.char_mode = ('SI', (a[0], a[1]) if len(a) >= 2 else DEFAULT_SI_CM)
            self.note(off, name, a, 'character size %s x %s cm' % tuple(map(fmt, self.char_mode[1])))
            return
        if name == 'SR':
            self.char_mode = ('SR', (a[0], a[1]) if len(a) >= 2 else DEFAULT_SR_PCT)
            self.note(off, name, a, 'character size %s%% x %s%% of P1-P2' % tuple(map(fmt, self.char_mode[1])))
            return
        if name in ('DI', 'DR'):
            self.direction = (name, (a[0], a[1]) if len(a) >= 2 else (1.0, 0.0))
            ux, uy = self.unit_direction()
            self.note(off, name, a, 'label direction %s deg' % fmt(math.degrees(math.atan2(uy, ux))))
            return
        if name == 'DT':
            self.note(off, name, a, 'label terminator %r' % a)
            return
        if name == 'LB':
            self.label(off, a)
            return
        if name == 'CI':
            if a:
                ax, _, _, _ = self.xform()
                r = abs(a[0] * ax)
                chord = a[1] if len(a) > 1 else 5.0
                cx, cy = self.pos
                was_down, saved = self.down, self.cur
                self.end_stroke()
                self.down = False
                self.move_to(cx + r, cy)
                self.down = True
                self.start_stroke()
                self.arc(cx, cy, 360.0, chord)
                self.end_stroke()
                self.down = False
                self.move_to(cx, cy)
                self.down = was_down
                if was_down:
                    self.start_stroke()
            return
        if name in ('AA', 'AR'):
            if len(a) >= 3:
                if name == 'AA':
                    cx, cy = self.to_plu(a[0], a[1])
                else:
                    ax, _, ay, _ = self.xform()
                    cx, cy = self.pos[0] + a[0] * ax, self.pos[1] + a[1] * ay
                self.arc(cx, cy, a[2], a[3] if len(a) > 3 else 5.0)
            return
        if name == 'VS':
            self.velocity.append(a[0] if a else None)
            self.note(off, name, a, 'pen velocity %s cm/s' % fmt(a[0]) if a else 'default pen velocity')
            return
        if name in ('PG', 'AF'):
            self.end_stroke()
            self.page += 1
            self.note(off, name, a, 'advance page')
            return
        if name == 'EC':
            on = (not a) or int(a[0]) != 0
            self.note(off, name, a, 'enable cutter' if on else 'disable cutter')
            return
        self.note(off, name, a, MNEMONICS.get(name, 'unknown command') +
                  ('' if name in NO_GRAPHIC_EFFECT else ' (not rendered)'))

    def label(self, off, text):
        w, h = self.char_size()
        ux, uy = self.unit_direction()
        start = self.pos
        line_start = self.pos
        runs = []
        run_pos, run_text = self.pos, ''
        for ch in text:
            if ch in '\r\n\b':
                if run_text:
                    runs.append((run_pos, run_text))
                if ch == '\r':
                    self.pos = line_start
                elif ch == '\n':
                    line_start = (line_start[0] + uy * 2 * h, line_start[1] - ux * 2 * h)
                    self.pos = (self.pos[0] + uy * 2 * h, self.pos[1] - ux * 2 * h)
                else:
                    self.pos = (self.pos[0] - ux * 1.5 * w, self.pos[1] - uy * 1.5 * w)
                run_pos, run_text = self.pos, ''
                continue
            if ord(ch) < 32:
                continue
            run_text += ch
            self.pos = (self.pos[0] + ux * 1.5 * w, self.pos[1] + uy * 1.5 * w)
        if run_text:
            runs.append((run_pos, run_text))
        pen = self.pen
        self.labels.append({'offset': off, 'pen': pen, 'pos': start, 'text': text, 'runs': runs,
                            'size': (w, h), 'angle': math.degrees(math.atan2(uy, ux)),
                            'user': self.to_user(*start) if self.sc else None,
                            'page': self.page})
        for (px, py), t in runs:
            ex = px + ux * 1.5 * w * len(t)
            ey = py + uy * 1.5 * w * len(t)
            for x, y in ((px, py), (ex, ey), (px - uy * h, py + ux * h), (ex - uy * h, ey + ux * h)):
                self.drawn_ext = self.grow(self.drawn_ext, x, y)
        self.pages_used.add(self.page)
        self.note(off, 'LB', text, 'label at (%s, %s)' % (fmt(start[0]), fmt(start[1])))


def stroke_length(points):
    return sum(math.hypot(points[k][0] - points[k - 1][0], points[k][1] - points[k - 1][1])
               for k in range(1, len(points)))


def ext_text(ext):
    x0, x1, y0, y1 = ext
    w, h = x1 - x0, y1 - y0
    return ('X %s .. %s, Y %s .. %s plu\n    size %s x %s plu = %.1f x %.1f mm = %.2f x %.2f in'
            % (fmt(x0), fmt(x1), fmt(y0), fmt(y1), fmt(w), fmt(h),
               w / PLU_PER_MM, h / PLU_PER_MM, w / PLU_PER_INCH, h / PLU_PER_INCH))


def write_txt(path, rel, data, pl, junk):
    L = []
    L.append('HP-GL plotter file: %s' % rel)
    L.append('Size: %d bytes, %d line break(s)' % (len(data), data.count(b'\n')))
    L.append('Units: plotter units (plu), 40 plu = 1 mm, 1016 plu = 1 inch; Y axis points up')
    L.append('')

    L.append('Device-control escapes')
    escs = [e for e in pl.events if e[1].startswith('ESC')]
    if escs:
        for off, text, meaning in escs:
            L.append('  byte %-6d %-12s %s' % (off, text, meaning))
    else:
        L.append('  none')
    L.append('')

    L.append('Scaling')
    if pl.ip_log:
        for off, text, p1, p2 in pl.ip_log:
            L.append('  byte %-6d %-24s P1=(%s,%s) P2=(%s,%s)' % ((off, text) + tuple(map(fmt, p1 + p2))))
    else:
        L.append('  IP: not used (plotter default P1/P2)')
    if pl.scale_log:
        for off, text, meaning in pl.scale_log:
            L.append('  byte %-6d %-24s %s' % (off, text, meaning))
    else:
        L.append('  SC: not used (coordinates are plotter units)')
    L.append('')

    L.append('Pens')
    per_pen = {}
    for st in pl.strokes:
        d = per_pen.setdefault(st['pen'], [0, 0, 0.0])
        d[0] += 1
        d[1] += len(st['points'])
        d[2] += stroke_length(st['points'])
    for pen in sorted(set(pl.pen_selects) | set(per_pen)):
        sel = pl.pen_selects.get(pen, 0)
        if pen == 0:
            L.append('  pen 0: selected %dx (SP/SP0 returns the pen, nothing drawn)' % sel)
            continue
        n, v, length = per_pen.get(pen, [0, 0, 0.0])
        nl = sum(1 for lb in pl.labels if lb['pen'] == pen)
        L.append('  pen %d (%s in SVG): selected %dx, %d polylines, %d vertices, '
                 'drawn length %.0f mm, %d labels'
                 % (pen, PEN_COLORS.get(pen, '#606060'), sel, n, v, length / PLU_PER_MM, nl))
    if not pl.pen_selects and not per_pen:
        L.append('  none selected')
    if pl.velocity:
        L.append('  velocity: ' + ', '.join('VS%s' % fmt(v) if v is not None else 'VS (default)'
                                            for v in pl.velocity) + ' (cm/s)')
    L.append('')

    L.append('Extents')
    L.append('  drawn (pen down, labels): ' + (ext_text(pl.drawn_ext) if pl.drawn_ext else 'nothing drawn'))
    L.append('  all positions (incl. pen-up moves): ' + (ext_text(pl.moves_ext) if pl.moves_ext else 'none'))
    L.append('  pages with drawing: %s' % (', '.join(map(str, sorted(pl.pages_used))) or 'none'))
    L.append('')

    L.append('Command counts')
    for name, cnt in sorted(pl.commands.items(), key=lambda kv: (-kv[1], kv[0])):
        if name.startswith('ESC'):
            continue
        status = ('rendered' if name in RENDERED else
                  'no graphic effect' if name in NO_GRAPHIC_EFFECT else 'NOT rendered')
        L.append('  %-3s %6d  %-34s %s' % (name, cnt, MNEMONICS.get(name, 'unknown'), status))
    unsupported = sorted(n for n in pl.commands
                         if not n.startswith('ESC') and n not in RENDERED and n not in NO_GRAPHIC_EFFECT)
    L.append('  unsupported: ' + (', '.join(unsupported) if unsupported else 'none'))
    if junk:
        L.append('  unparsed bytes: ' + ', '.join('%r x%d' % kv for kv in sorted(junk.items())))
    L.append('')

    L.append('Command sequence (excluding PA/PR/PU/PD motion)')
    for off, text, meaning in pl.events[:300]:
        L.append('  byte %-6d %-24s %s' % (off, text if len(text) <= 24 else text[:21] + '...', meaning))
    if len(pl.events) > 300:
        L.append('  ... %d more' % (len(pl.events) - 300))
    L.append('')

    L.append('Labels (LB)')
    if pl.labels:
        for k, lb in enumerate(pl.labels, 1):
            x, y = lb['pos']
            user = (' user (%s, %s)' % tuple(map(fmt, lb['user']))) if lb['user'] else ''
            L.append('  %3d. pen %d at (%s, %s) plu%s, char %.2f x %.2f mm, %s deg: "%s"'
                     % (k, lb['pen'], fmt(x), fmt(y), user, lb['size'][0] / PLU_PER_MM,
                        lb['size'][1] / PLU_PER_MM, fmt(lb['angle']), escape_label(lb['text'])))
    else:
        L.append('  none; any lettering in the drawing is stroked as vector outlines')
    L.append('')

    with open(path, 'w', encoding='utf-8', newline='\n') as f:
        f.write('\n'.join(L))


def write_svg(path, rel, pl):
    ext = pl.drawn_ext or [0.0, 1.0, 0.0, 1.0]
    x0, x1, y0, y1 = ext
    w, h = max(x1 - x0, 1.0), max(y1 - y0, 1.0)
    m = round(max(w, h) * 0.02)
    vw, vh = w + 2 * m, h + 2 * m

    def X(x):
        return fmt(x - x0 + m)

    def Y(y):
        return fmt(y1 - y + m)

    out = ['<?xml version="1.0" encoding="UTF-8"?>',
           '<svg xmlns="http://www.w3.org/2000/svg" width="%smm" height="%smm" viewBox="0 0 %s %s">'
           % (fmt(vw / PLU_PER_MM), fmt(vh / PLU_PER_MM), fmt(vw), fmt(vh)),
           '<title>%s</title>' % html.escape(rel),
           '<rect x="0" y="0" width="%s" height="%s" fill="#ffffff"/>' % (fmt(vw), fmt(vh))]
    by_pen = {}
    for st in pl.strokes:
        by_pen.setdefault(st['pen'], []).append(st['points'])
    for pen in sorted(by_pen):
        out.append('<g id="pen%d" fill="none" stroke="%s" stroke-width="12" '
                   'stroke-linecap="round" stroke-linejoin="round">'
                   % (pen, PEN_COLORS.get(pen, '#606060')))
        for pts in by_pen[pen]:
            d = 'M%s %s' % (X(pts[0][0]), Y(pts[0][1]))
            if len(pts) == 1:
                d += 'l0 0'
            else:
                d += 'L' + ' '.join('%s %s' % (X(px), Y(py)) for px, py in pts[1:])
            out.append('<path d="%s"/>' % d)
        out.append('</g>')
    if pl.labels:
        out.append('<g id="labels" font-family="monospace" xml:space="preserve">')
        for lb in pl.labels:
            cw, ch = lb['size']
            for (px, py), t in lb['runs']:
                sx, sy = X(px), Y(py)
                rot = '' if abs(lb['angle']) < 1e-9 else ' rotate(%s)' % fmt(-lb['angle'])
                out.append('<text x="0" y="0" transform="translate(%s %s)%s" font-size="%s" '
                           'textLength="%s" fill="%s">%s</text>'
                           % (sx, sy, rot, fmt(ch / 0.72), fmt(1.5 * cw * len(t) - 0.5 * cw),
                              PEN_COLORS.get(lb['pen'], '#606060'), html.escape(t)))
        out.append('</g>')
    out.append('</svg>')
    with open(path, 'w', encoding='utf-8', newline='\n') as f:
        f.write('\n'.join(out) + '\n')


def convert(src_root, rel, out_root):
    with open(os.path.join(src_root, rel), 'rb') as f:
        data = f.read()
    pl = Plotter()
    junk = pl.run(data.decode('latin-1'))
    base = os.path.join(out_root, rel)
    os.makedirs(os.path.dirname(base), exist_ok=True)
    write_txt(base + '.txt', rel, data, pl, junk)
    write_svg(base + '.svg', rel, pl)
    return pl


def main(argv):
    if len(argv) != 4:
        sys.stderr.write('usage: %s SRC_ROOT LIST_FILE OUT_ROOT\n' % argv[0])
        return 2
    src_root, list_file, out_root = argv[1:]
    with open(list_file, encoding='utf-8') as f:
        rels = [ln.strip() for ln in f if ln.strip()]
    for rel in rels:
        pl = convert(src_root, rel, out_root)
        print('%s: %d polylines, %d labels' % (rel, len(pl.strokes), len(pl.labels)))
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv))
