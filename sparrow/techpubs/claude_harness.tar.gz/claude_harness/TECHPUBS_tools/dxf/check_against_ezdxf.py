# ABOUTME: Cross-checks dxf2txtsvg.py against ezdxf (entity counts, text strings), verifies the SVGs parse
# ABOUTME: as XML and optionally rasterizes them to PNG with cairosvg; needs a venv with ezdxf and cairosvg.

import argparse
import collections
import os
import sys
import xml.etree.ElementTree as ET

from ezdxf import recover

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import dxf2txtsvg  # noqa: E402


def ez_counts(layout):
    c = collections.Counter()
    texts = collections.Counter()
    for e in layout:
        c[e.dxftype()] += 1
        if e.dxftype() == 'TEXT':
            texts[e.dxf.text] += 1
    return c, texts


def my_counts(ents):
    c = collections.Counter()
    texts = collections.Counter()
    for o in ents:
        c[o.type] += 1
        if o.type == 'TEXT':
            texts[o.s(1, '')] += 1
    return c, texts


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--src-root', required=True)
    ap.add_argument('--out-root', required=True)
    ap.add_argument('--list', required=True)
    ap.add_argument('--png-dir')
    args = ap.parse_args()
    rels = [ln.strip() for ln in open(args.list, encoding='utf-8') if ln.strip()]
    bad = 0
    for rel in rels:
        src = os.path.join(args.src_root, rel)
        problems = []
        doc, _ = recover.readfile(src)
        with open(src, 'rb') as fh:
            mine = dxf2txtsvg.parse(fh.read())
        ec, et = ez_counts(doc.modelspace())
        mc, mt = my_counts(mine.entities)
        if ec != mc:
            problems.append('model space counts differ: ezdxf %s mine %s' % (dict(ec), dict(mc)))
        if et != mt:
            problems.append('model space TEXT strings differ: %s' % ((et - mt) + (mt - et)))
        ebc = collections.Counter()
        ebt = collections.Counter()
        for blk in doc.blocks:
            if blk.name.upper() in ('*MODEL_SPACE', '*PAPER_SPACE', '$MODEL_SPACE', '$PAPER_SPACE'):
                continue
            c, t = ez_counts(blk)
            ebc.update(c)
            ebt.update(t)
        mbc = collections.Counter()
        mbt = collections.Counter()
        for ents in mine.blocks.values():
            c, t = my_counts(ents)
            mbc.update(c)
            mbt.update(t)
        if ebc != mbc:
            problems.append('block counts differ: ezdxf %s mine %s' % (dict(ebc), dict(mbc)))
        if ebt != mbt:
            problems.append('block TEXT strings differ')
        svg = os.path.join(args.out_root, rel + '.svg')
        try:
            ET.parse(svg)
        except ET.ParseError as ex:
            problems.append('SVG not well-formed: %s' % ex)
        if args.png_dir:
            import cairosvg
            os.makedirs(args.png_dir, exist_ok=True)
            cairosvg.svg2png(url=svg, write_to=os.path.join(args.png_dir, os.path.basename(rel) + '.png'),
                             output_width=1400)
        print(('OK   ' if not problems else 'DIFF ') + rel)
        for p in problems:
            print('     ' + p)
        bad += bool(problems)
    print('%d/%d files match' % (len(rels) - bad, len(rels)))


if __name__ == '__main__':
    main()
