# ABOUTME: Converts old ASCII DXF drawings (AutoCAD 2.5/R10, DynaCADD exports) into a text summary
# ABOUTME: listing all text content, plus an SVG render with blocks expanded; tolerant hand-written parser.

import argparse
import collections
import datetime
import html
import math
import os
import re
import sys
import traceback

ATARI_HIGH = [
    0x00C7, 0x00FC, 0x00E9, 0x00E2, 0x00E4, 0x00E0, 0x00E5, 0x00E7, 0x00EA, 0x00EB, 0x00E8, 0x00EF, 0x00EE, 0x00EC, 0x00C4, 0x00C5,
    0x00C9, 0x00E6, 0x00C6, 0x00F4, 0x00F6, 0x00F2, 0x00FB, 0x00F9, 0x00FF, 0x00D6, 0x00DC, 0x00A2, 0x00A3, 0x00A5, 0x00DF, 0x0192,
    0x00E1, 0x00ED, 0x00F3, 0x00FA, 0x00F1, 0x00D1, 0x00AA, 0x00BA, 0x00BF, 0x2310, 0x00AC, 0x00BD, 0x00BC, 0x00A1, 0x00AB, 0x00BB,
    0x00E3, 0x00F5, 0x00D8, 0x00F8, 0x0153, 0x0152, 0x00C0, 0x00C3, 0x00D5, 0x00A8, 0x00B4, 0x2020, 0x00B6, 0x00A9, 0x00AE, 0x2122,
    0x0133, 0x0132, 0x05D0, 0x05D1, 0x05D2, 0x05D3, 0x05D4, 0x05D5, 0x05D6, 0x05D7, 0x05D8, 0x05D9, 0x05DB, 0x05DC, 0x05DE, 0x05E0,
    0x05E1, 0x05E2, 0x05E4, 0x05E6, 0x05E7, 0x05E8, 0x05E9, 0x05EA, 0x05DF, 0x05DA, 0x05DD, 0x05E3, 0x05E5, 0x00A7, 0x2227, 0x221E,
    0x03B1, 0x03B2, 0x0393, 0x03C0, 0x03A3, 0x03C3, 0x00B5, 0x03C4, 0x03A6, 0x0398, 0x03A9, 0x03B4, 0x222E, 0x03C6, 0x2208, 0x2229,
    0x2261, 0x00B1, 0x2265, 0x2264, 0x2320, 0x2321, 0x00F7, 0x2248, 0x00B0, 0x2219, 0x00B7, 0x221A, 0x207F, 0x00B2, 0x00B3, 0x00AF,
]
ATARI_TABLE = [chr(i) for i in range(128)] + [chr(c) for c in ATARI_HIGH]

KNOWN_OBJECTS = {
    'SECTION', 'ENDSEC', 'TABLE', 'ENDTAB', 'EOF', 'LTYPE', 'LAYER', 'STYLE', 'VIEW', 'VPORT', 'UCS', 'DWGMGR',
    'APPID', 'DIMSTYLE', 'BLOCK', 'ENDBLK', 'LINE', 'POINT', 'CIRCLE', 'ARC', 'TRACE', 'SOLID', 'TEXT', 'SHAPE',
    'INSERT', 'ATTDEF', 'ATTRIB', 'POLYLINE', 'VERTEX', 'SEQEND', '3DLINE', '3DFACE', 'DIMENSION', 'VIEWPORT',
}

ACAD_VERSIONS = {'AC1002': 'AutoCAD 2.5', 'AC1003': 'AutoCAD 2.6', 'AC1004': 'R9', 'AC1006': 'R10',
                 'AC1009': 'R11/R12', 'AC1012': 'R13', 'AC1014': 'R14'}


def decode_atari(b):
    return ''.join(ATARI_TABLE[c] for c in b)


class Obj:
    __slots__ = ('type', 'raw_type', 'tags', 'd', 'line', 'children')

    def __init__(self, typ, raw, line):
        self.type = typ
        self.raw_type = raw
        self.tags = []
        self.d = {}
        self.line = line
        self.children = []

    def add(self, code, val):
        self.tags.append((code, val))
        if code not in self.d:
            self.d[code] = val

    def s(self, code, default=None):
        v = self.d.get(code)
        return default if v is None else v

    def f(self, code, default=0.0):
        v = self.d.get(code)
        if v is None:
            return default
        try:
            return float(v.strip())
        except ValueError:
            return default

    def i(self, code, default=0):
        v = self.d.get(code)
        if v is None:
            return default
        try:
            return int(float(v.strip()))
        except ValueError:
            return default


class Doc:
    def __init__(self):
        self.header = collections.OrderedDict()
        self.tables = collections.OrderedDict()
        self.table_entries = collections.defaultdict(list)
        self.blocks = collections.OrderedDict()
        self.block_objs = {}
        self.entities = []
        self.sections = []
        self.warnings = []
        self.padded_codes = 0
        self.unpadded_codes = 0
        self.crlf = False
        self.ctrl_z = False
        self.size = 0
        self.unknown = collections.Counter()
        self.repaired = []

    def warn(self, msg):
        self.warnings.append(msg)

    def hvar(self, name, code=None, default=None):
        tags = self.header.get(name)
        if not tags:
            return default
        if code is None:
            return tags[0][1].strip()
        for c, v in tags:
            if c == code:
                return v.strip()
        return default

    def hfloat(self, name, code, default=None):
        v = self.hvar(name, code)
        try:
            return float(v)
        except (TypeError, ValueError):
            return default


def repair_name(raw):
    name = raw.strip()
    if name in KNOWN_OBJECTS:
        return name
    clean = re.sub(r'[^A-Z0-9]', '', name.upper())
    if clean in KNOWN_OBJECTS:
        return clean
    if len(clean) >= 3:
        cands = [k for k in KNOWN_OBJECTS if k.startswith(clean) and len(k) - len(clean) <= 1]
        if len(cands) == 1:
            return cands[0]
        cands = [k for k in KNOWN_OBJECTS
                 if len(k) == len(name) and sum(a != b for a, b in zip(k, name.upper())) == 1]
        if len(cands) == 1:
            return cands[0]
    return name


def tokenize(data, doc):
    doc.size = len(data)
    doc.crlf = b'\r\n' in data[:2000]
    stripped = data.rstrip(b'\x00\x1a\r\n \t')
    doc.ctrl_z = b'\x1a' in data[-4:]
    lines = stripped.split(b'\n')
    toks = []
    i = 0
    n = len(lines)
    while i < n:
        raw = lines[i].rstrip(b'\r')
        s = raw.strip()
        if not s:
            i += 1
            continue
        try:
            code = int(s)
        except ValueError:
            doc.warn('line %d: expected a group code, found %r; line skipped' % (i + 1, s[:24].decode('latin1')))
            i += 1
            continue
        if raw[:1] == b' ':
            doc.padded_codes += 1
        else:
            doc.unpadded_codes += 1
        if i + 1 >= n:
            doc.warn('file ends after group code %d' % code)
            break
        toks.append((code, decode_atari(lines[i + 1].rstrip(b'\r')), i + 1))
        i += 2
    return toks


def parse(data):
    doc = Doc()
    toks = tokenize(data, doc)
    objs = []
    cur = None
    for code, val, ln in toks:
        if code == 0:
            name = repair_name(val)
            if name != val.strip():
                doc.repaired.append((ln + 1, val, name))
            cur = Obj(name, val, ln + 1)
            objs.append(cur)
        elif cur is None:
            doc.warn('line %d: group %d before first object' % (ln, code))
        else:
            cur.add(code, val)

    sec = None
    table = None
    block = None
    open_parent = None
    for o in objs:
        t = o.type
        if t == 'SECTION':
            sec = (o.s(2) or '').strip()
            doc.sections.append(sec)
            open_parent = None
            if sec == 'HEADER':
                var = None
                for c, v in o.tags:
                    if c == 2 and var is None:
                        continue
                    if c == 9:
                        var = v.strip()
                        doc.header[var] = []
                    elif var is not None:
                        doc.header[var].append((c, v))
            continue
        if t == 'ENDSEC':
            if open_parent is not None:
                doc.warn('line %d: %s without SEQEND' % (open_parent.line, open_parent.type))
            sec = None
            table = None
            block = None
            open_parent = None
            continue
        if t == 'EOF':
            break
        if sec == 'TABLES':
            if t == 'TABLE':
                table = (o.s(2) or '').strip()
                doc.tables[table] = o
            elif t == 'ENDTAB':
                table = None
            elif table:
                doc.table_entries[table].append(o)
            continue
        if sec not in ('BLOCKS', 'ENTITIES'):
            continue
        if sec == 'BLOCKS' and t == 'BLOCK':
            block = (o.s(2) or '').strip()
            if block in doc.blocks:
                doc.warn('line %d: duplicate block %s' % (o.line, block))
            doc.blocks[block] = []
            doc.block_objs[block] = o
            open_parent = None
            continue
        if sec == 'BLOCKS' and t == 'ENDBLK':
            block = None
            open_parent = None
            continue
        target = doc.blocks[block] if (sec == 'BLOCKS' and block is not None) else doc.entities
        if sec == 'BLOCKS' and block is None:
            doc.warn('line %d: %s outside BLOCK/ENDBLK' % (o.line, t))
        if t in ('VERTEX', 'ATTRIB') and open_parent is not None:
            open_parent.children.append(o)
            continue
        if t == 'SEQEND':
            if open_parent is None:
                doc.warn('line %d: SEQEND without POLYLINE/INSERT' % o.line)
            open_parent = None
            continue
        if t == 'VERTEX':
            doc.warn('line %d: VERTEX outside POLYLINE ignored' % o.line)
            continue
        if open_parent is not None:
            doc.warn('line %d: %s not terminated by SEQEND' % (open_parent.line, open_parent.type))
            open_parent = None
        target.append(o)
        if t == 'POLYLINE' or (t == 'INSERT' and o.i(66) == 1):
            open_parent = o
        if t not in KNOWN_OBJECTS:
            doc.unknown[t] += 1
    return doc


# ---------------------------------------------------------------- geometry

class M2:
    __slots__ = ('a', 'b', 'c', 'd', 'e', 'f')

    def __init__(self, a=1.0, b=0.0, c=0.0, d=1.0, e=0.0, f=0.0):
        self.a, self.b, self.c, self.d, self.e, self.f = a, b, c, d, e, f

    def __mul__(self, o):
        return M2(self.a * o.a + self.c * o.b, self.b * o.a + self.d * o.b,
                  self.a * o.c + self.c * o.d, self.b * o.c + self.d * o.d,
                  self.a * o.e + self.c * o.f + self.e, self.b * o.e + self.d * o.f + self.f)

    def ap(self, x, y):
        return (self.a * x + self.c * y + self.e, self.b * x + self.d * y + self.f)

    def vec(self, x, y):
        return (self.a * x + self.c * y, self.b * x + self.d * y)

    def det(self):
        return self.a * self.d - self.b * self.c

    def scale(self):
        return math.sqrt(abs(self.det()))

    def similar(self):
        n1 = self.a * self.a + self.b * self.b
        n2 = self.c * self.c + self.d * self.d
        dot = self.a * self.c + self.b * self.d
        ref = max(n1, n2, 1e-30)
        return abs(n1 - n2) <= 1e-6 * ref and abs(dot) <= 1e-6 * ref


def translate(x, y):
    return M2(e=x, f=y)


def rotate(deg):
    r = math.radians(deg)
    return M2(math.cos(r), math.sin(r), -math.sin(r), math.cos(r))


def scalem(sx, sy):
    return M2(sx, 0.0, 0.0, sy)


IDENT = M2()


def bulge_arc(p1, p2, b):
    dx, dy = p2[0] - p1[0], p2[1] - p1[1]
    chord = math.hypot(dx, dy)
    if chord < 1e-12:
        return None
    theta = 4.0 * math.atan(b)
    r = chord / (2.0 * math.sin(abs(theta) / 2.0))
    mx, my = (p1[0] + p2[0]) / 2.0, (p1[1] + p2[1]) / 2.0
    h = r * math.cos(theta / 2.0)
    nx, ny = -dy / chord, dx / chord
    sign = 1.0 if b > 0 else -1.0
    cx, cy = mx + sign * nx * h, my + sign * ny * h
    return cx, cy, abs(r), theta


def arc_points(cx, cy, r, a0, sweep, segs=None):
    if segs is None:
        segs = max(4, int(abs(sweep) / 6.0) + 1)
    out = []
    for k in range(segs + 1):
        a = math.radians(a0 + sweep * k / segs)
        out.append((cx + r * math.cos(a), cy + r * math.sin(a)))
    return out


# ---------------------------------------------------------------- colors

def aci_rgb(i):
    base = {1: (255, 0, 0), 2: (255, 255, 0), 3: (0, 255, 0), 4: (0, 255, 255), 5: (0, 0, 255),
            6: (255, 0, 255), 7: (0, 0, 0), 8: (128, 128, 128), 9: (192, 192, 192)}
    if i in base:
        return base[i]
    if 250 <= i <= 255:
        g = [51, 91, 132, 173, 214, 255][i - 250]
        return (g, g, g)
    if 10 <= i <= 249:
        hue = (i // 10 - 1) * 15.0
        row = i % 10
        val = [1.0, 1.0, 0.65, 0.65, 0.5, 0.5, 0.3, 0.3, 0.15, 0.15][row]
        sat = 1.0 if row % 2 == 0 else 0.5
        hh = hue / 60.0
        x = 1 - abs(hh % 2 - 1)
        r, g, b = [(1, x, 0), (x, 1, 0), (0, 1, x), (0, x, 1), (x, 0, 1), (1, 0, x)][int(hh) % 6]
        r, g, b = [(1 - sat + sat * ch) * val for ch in (r, g, b)]
        return (int(r * 255), int(g * 255), int(b * 255))
    return (0, 0, 0)


def svg_color(i):
    r, g, b = aci_rgb(i)
    lum = (0.2126 * r + 0.7152 * g + 0.0722 * b) / 255.0
    if lum > 0.45:
        k = 0.45 / lum
        r, g, b = int(r * k), int(g * k), int(b * k)
    return '#%02x%02x%02x' % (r, g, b)


# ---------------------------------------------------------------- text codes

def expand_text(s):
    underline = False

    def rep(m):
        nonlocal underline
        code = m.group(1)
        low = code.lower()
        if low == 'd':
            return '°'
        if low == 'p':
            return '±'
        if low == 'c':
            return '⌀'
        if low == '%':
            return '%'
        if low in ('u', 'o'):
            if low == 'u':
                underline = True
            return ''
        if code.isdigit():
            n = int(code)
            return ATARI_TABLE[n] if 32 <= n < 256 else ''
        return m.group(0)

    out = re.sub(r'%%(\d{1,3}|[dDpPcCuUoO%])', rep, s)
    out = ''.join(ch if (ch >= ' ' or ch == '\t') else '�' for ch in out)
    return out, underline


# ---------------------------------------------------------------- scene building

class Style:
    __slots__ = ('layer', 'color', 'ltype', 'width')

    def __init__(self, layer, color, ltype, width=0.0):
        self.layer, self.color, self.ltype, self.width = layer, color, ltype, width


class Scene:
    def __init__(self, doc):
        self.doc = doc
        self.layers = {}
        for e in doc.table_entries.get('LAYER', []):
            name = (e.s(2) or '').strip()
            self.layers[name] = e
        self.ltypes = {}
        for e in doc.table_entries.get('LTYPE', []):
            self.ltypes[(e.s(2) or '').strip().upper()] = [float(v) for c, v in e.tags if c == 49 and _isnum(v)]
        self.fillmode = int(doc.hfloat('$FILLMODE', 70, 1) or 0) != 0
        self.ltscale = doc.hfloat('$LTSCALE', 40, 1.0) or 1.0
        self.prims = []
        self.texts = []
        self.bbox = [math.inf, math.inf, -math.inf, -math.inf]
        self.stats = collections.Counter()
        self.insert_counts = collections.Counter()
        self.insert_samples = collections.defaultdict(list)
        self.max_depth_hit = False
        self.missing_blocks = collections.Counter()
        self.pad = 0.0

    def layer_color(self, name):
        e = self.layers.get(name)
        return abs(e.i(62, 7)) if e is not None else 7

    def layer_visible(self, name):
        e = self.layers.get(name)
        if e is None:
            return True
        return e.i(62, 7) >= 0 and not (e.i(70) & 1)

    def layer_ltype(self, name):
        e = self.layers.get(name)
        return (e.s(6) or 'CONTINUOUS').strip().upper() if e is not None else 'CONTINUOUS'

    def grow(self, x, y):
        b = self.bbox
        if x < b[0]:
            b[0] = x
        if y < b[1]:
            b[1] = y
        if x > b[2]:
            b[2] = x
        if y > b[3]:
            b[3] = y

    def grow_arc(self, cx, cy, r, a0, sweep):
        pts = [a0, a0 + sweep]
        k = math.ceil(a0 / 90.0) * 90.0
        while k < a0 + sweep:
            pts.append(k)
            k += 90.0
        for a in pts:
            ra = math.radians(a)
            self.grow(cx + r * math.cos(ra), cy + r * math.sin(ra))

    def build(self):
        self.walk(self.doc.entities, IDENT, None, 0, True, '')

    def resolve(self, o, inh):
        layer = (o.s(8) or '0').strip()
        if inh is not None and layer == '0':
            layer = inh.layer
        color = o.i(62, 256)
        if color == 0:
            color = inh.color if inh is not None else 7
        elif color == 256 or color < 0:
            color = self.layer_color(layer)
        lt = (o.s(6) or 'BYLAYER').strip().upper()
        if lt == 'BYBLOCK':
            lt = inh.ltype if inh is not None else 'CONTINUOUS'
        elif lt == 'BYLAYER':
            lt = self.layer_ltype(layer)
        return Style(layer, color, lt)

    def walk(self, ents, m, inh, depth, visible, path):
        for o in ents:
            st = self.resolve(o, inh)
            vis = visible and self.layer_visible(st.layer)
            try:
                self.entity(o, m, st, depth, vis, path)
            except (ValueError, ZeroDivisionError, OverflowError) as ex:
                self.doc.warn('line %d: %s not rendered (%s)' % (o.line, o.type, ex))

    def add(self, kind, st, vis, data):
        if vis:
            self.prims.append((kind, st, data))
        else:
            self.stats['hidden'] += 1

    def entity(self, o, m, st, depth, vis, path):
        t = o.type
        if abs(o.f(38)) > 0 or abs(o.f(39)) > 0:
            self.stats['elev_thick'] += 1
        if t in ('LINE', '3DLINE'):
            p1 = m.ap(o.f(10), o.f(20))
            p2 = m.ap(o.f(11), o.f(21))
            if math.hypot(p2[0] - p1[0], p2[1] - p1[1]) < 1e-12:
                self.add('dot', st, vis, p1)
            else:
                self.add('path', st, vis, [('M', p1), ('L', p2)])
            if vis:
                self.grow(*p1)
                self.grow(*p2)
        elif t == 'POINT':
            p = m.ap(o.f(10), o.f(20))
            self.add('dot', st, vis, p)
            if vis:
                self.grow(*p)
        elif t == 'CIRCLE':
            self.circle(m, o.f(10), o.f(20), o.f(40), st, vis)
        elif t == 'ARC':
            a0 = o.f(50)
            a1 = o.f(51)
            sweep = (a1 - a0) % 360.0
            if sweep < 1e-9:
                self.circle(m, o.f(10), o.f(20), o.f(40), st, vis)
            else:
                self.arc(m, o.f(10), o.f(20), o.f(40), a0, sweep, st, vis)
        elif t in ('SOLID', 'TRACE', '3DFACE'):
            pts = [m.ap(o.f(10 + k), o.f(20 + k)) for k in range(4)]
            if t == '3DFACE':
                ring = pts
            else:
                ring = [pts[0], pts[1], pts[3], pts[2]]
            if (t != '3DFACE') and self.fillmode:
                self.add('fill', st, vis, ring)
            else:
                self.add('path', st, vis, [('M', ring[0])] + [('L', p) for p in ring[1:]] + [('Z', None)])
            if vis:
                for p in ring:
                    self.grow(*p)
        elif t == 'POLYLINE':
            self.polyline(o, m, st, vis)
        elif t in ('TEXT', 'ATTRIB', 'ATTDEF'):
            if t == 'ATTDEF' and depth > 0:
                return
            if t == 'ATTRIB' and (o.i(70) & 1):
                vis = False
            self.text(o, m, st, vis, path)
        elif t == 'INSERT':
            self.insert(o, m, st, depth, vis, path)
        elif t == 'DIMENSION':
            name = (o.s(2) or '').strip()
            if name in self.doc.blocks and depth < 16:
                self.walk(self.doc.blocks[name], m, st, depth + 1, vis, (path + '/' if path else '') + name)
            self.stats['dimension'] += 1
        else:
            self.stats['unsupported:' + t] += 1

    def circle(self, m, cx, cy, r, st, vis):
        if m.similar():
            c = m.ap(cx, cy)
            rr = r * m.scale()
            self.add('circle', st, vis, (c[0], c[1], rr))
            if vis:
                self.grow(c[0] - rr, c[1] - rr)
                self.grow(c[0] + rr, c[1] + rr)
        else:
            pts = [m.ap(*p) for p in arc_points(cx, cy, r, 0.0, 360.0, 72)]
            self.add('path', st, vis, [('M', pts[0])] + [('L', p) for p in pts[1:]] + [('Z', None)])
            if vis:
                for p in pts:
                    self.grow(*p)

    def arc(self, m, cx, cy, r, a0, sweep, st, vis):
        if m.similar():
            s = m.scale()
            c = m.ap(cx, cy)
            p0 = m.ap(cx + r * math.cos(math.radians(a0)), cy + r * math.sin(math.radians(a0)))
            p1 = m.ap(cx + r * math.cos(math.radians(a0 + sweep)), cy + r * math.sin(math.radians(a0 + sweep)))
            if m.det() < 0:
                p0, p1 = p1, p0
            wa0 = math.degrees(math.atan2(p0[1] - c[1], p0[0] - c[0]))
            self.add('arc', st, vis, (c[0], c[1], r * s, wa0, sweep, p0, p1))
            if vis:
                self.grow_arc(c[0], c[1], r * s, wa0, sweep)
        else:
            pts = [m.ap(*p) for p in arc_points(cx, cy, r, a0, sweep)]
            self.add('path', st, vis, [('M', pts[0])] + [('L', p) for p in pts[1:]])
            if vis:
                for p in pts:
                    self.grow(*p)

    def polyline(self, o, m, st, vis):
        flags = o.i(70)
        if flags & (16 | 64):
            self.stats['mesh_polyline'] += 1
        verts = o.children
        if any(v.i(70) & 8 for v in verts):
            verts = [v for v in verts if not (v.i(70) & 16)]
        if not verts:
            self.stats['empty_polyline'] += 1
            return
        dw0 = o.f(40)
        dw1 = o.f(41)
        vs = []
        for v in verts:
            vs.append(((v.f(10), v.f(20)), v.f(42), v.f(40, dw0), v.f(41, dw1)))
        closed = bool(flags & 1)
        pts = [p for p, _, _, _ in vs]
        if all(math.hypot(p[0] - pts[0][0], p[1] - pts[0][1]) < 1e-9 for p in pts):
            wp = m.ap(*pts[0])
            self.add('dot', st, vis, wp)
            self.stats['degenerate_polyline'] += 1
            if vis:
                self.grow(*wp)
            return
        nseg = len(vs) if closed else len(vs) - 1
        widths = set()
        for k in range(nseg):
            widths.add(vs[k][2])
            widths.add(vs[k][3])
        tapered = len(widths) > 1
        similar = m.similar()
        s = m.scale()
        if tapered:
            for k in range(nseg):
                (p1, b, w0, w1) = vs[k]
                p2 = vs[(k + 1) % len(vs)][0]
                if abs(b) > 1e-12:
                    arc = bulge_arc(p1, p2, b)
                    if arc is None:
                        continue
                    cx, cy, r, theta = arc
                    a0 = math.degrees(math.atan2(p1[1] - cy, p1[0] - cx))
                    local = arc_points(cx, cy, r, a0, math.degrees(theta))
                else:
                    local = [p1, p2]
                n = len(local) - 1
                for j in range(n):
                    q1, q2 = local[j], local[j + 1]
                    wa = w0 + (w1 - w0) * j / n
                    wb = w0 + (w1 - w0) * (j + 1) / n
                    dx, dy = q2[0] - q1[0], q2[1] - q1[1]
                    ln = math.hypot(dx, dy)
                    if ln < 1e-12:
                        continue
                    nx, ny = -dy / ln, dx / ln
                    quad = [m.ap(q1[0] + nx * wa / 2, q1[1] + ny * wa / 2), m.ap(q2[0] + nx * wb / 2, q2[1] + ny * wb / 2),
                            m.ap(q2[0] - nx * wb / 2, q2[1] - ny * wb / 2), m.ap(q1[0] - nx * wa / 2, q1[1] - ny * wa / 2)]
                    if max(wa, wb) > 0:
                        if self.fillmode:
                            self.add('fill', st, vis, quad)
                        else:
                            self.add('path', st, vis, [('M', quad[0])] + [('L', p) for p in quad[1:]] + [('Z', None)])
                    else:
                        self.add('path', st, vis, [('M', m.ap(*q1)), ('L', m.ap(*q2))])
                    if vis:
                        for p in quad:
                            self.grow(*p)
            return
        width = widths.pop() if widths else 0.0
        cmds = [('M', m.ap(*pts[0]))]
        if vis:
            self.grow(*cmds[0][1])
        for k in range(nseg):
            p1, b, _, _ = vs[k]
            p2 = vs[(k + 1) % len(vs)][0]
            wp2 = m.ap(*p2)
            if abs(b) > 1e-12:
                arc = bulge_arc(p1, p2, b)
                if arc is None:
                    continue
                cx, cy, r, theta = arc
                sweep_deg = math.degrees(theta)
                a0 = math.degrees(math.atan2(p1[1] - cy, p1[0] - cx))
                if similar:
                    ccw = (theta > 0) == (m.det() > 0)
                    cmds.append(('A', (r * s, abs(theta) > math.pi, ccw, wp2)))
                    if vis:
                        wc = m.ap(cx, cy)
                        wp1 = m.ap(*p1)
                        start = wp1 if ccw else wp2
                        wa0 = math.degrees(math.atan2(start[1] - wc[1], start[0] - wc[0]))
                        self.grow_arc(wc[0], wc[1], r * s, wa0, abs(sweep_deg))
                else:
                    for q in arc_points(cx, cy, r, a0, sweep_deg)[1:]:
                        wq = m.ap(*q)
                        cmds.append(('L', wq))
                        if vis:
                            self.grow(*wq)
            else:
                cmds.append(('L', wp2))
            if vis:
                self.grow(*wp2)
        if closed:
            cmds.append(('Z', None))
        pst = Style(st.layer, st.color, st.ltype, width * s)
        if width > 0 and vis:
            self.stats['wide_polyline'] += 1
            self.pad = max(self.pad, width * s / 2.0)
        self.add('path', pst, vis, cmds)

    def text(self, o, m, st, vis, path):
        raw = o.s(1, '')
        plain, underline = expand_text(raw)
        h = o.f(40)
        rot = o.f(50)
        wf = o.f(41, 1.0) or 1.0
        obl = o.f(51)
        hj = o.i(72)
        vj = o.i(73)
        gen = o.i(71)
        p10 = (o.f(10), o.f(20))
        p11 = (o.f(11, p10[0]), o.f(21, p10[1])) if 11 in o.d else p10
        fitlen = None
        if hj in (3, 5) and 11 in o.d:
            dx, dy = p11[0] - p10[0], p11[1] - p10[1]
            if math.hypot(dx, dy) > 1e-12:
                rot = math.degrees(math.atan2(dy, dx))
                fitlen = math.hypot(dx, dy)
            anchor_pt, anchor = p10, 'start'
        elif hj in (1, 2, 4) or vj:
            anchor_pt = p11 if 11 in o.d else p10
            anchor = {1: 'middle', 2: 'end', 4: 'middle'}.get(hj, 'start')
        else:
            anchor_pt, anchor = p10, 'start'
        valign = 'baseline'
        if hj == 4:
            valign = 'middle'
        elif vj == 1:
            valign = 'bottom'
        elif vj == 2:
            valign = 'middle'
        elif vj == 3:
            valign = 'top'
        wp = m.ap(*anchor_pt)
        ux, uy = m.vec(math.cos(math.radians(rot)), math.sin(math.radians(rot)))
        vx, vy = m.vec(-math.sin(math.radians(rot)), math.cos(math.radians(rot)))
        wrot = math.degrees(math.atan2(uy, ux))
        lu = math.hypot(ux, uy)
        lv = math.hypot(vx, vy)
        wh = h * lv
        wwf = wf * (lu / lv if lv > 0 else 1.0)
        if fitlen is not None:
            fitlen *= lu
        just = {0: 'left', 1: 'center', 2: 'right', 3: 'aligned', 4: 'middle', 5: 'fit'}.get(hj, str(hj))
        if vj:
            just += '/' + {1: 'bottom', 2: 'middle', 3: 'top'}.get(vj, str(vj))
        rec = dict(x=wp[0], y=wp[1], h=wh, rot=wrot % 360.0, wf=wwf, text=plain, raw=raw, layer=st.layer,
                   style=(o.s(7) or 'STANDARD').strip(), just=just, anchor=anchor, valign=valign,
                   src=path, kind=o.type, tag=(o.s(2) or '').strip(), visible=vis, underline=underline,
                   fitlen=fitlen, obl=obl, gen=gen, color=st.color)
        self.texts.append(rec)
        if plain.strip():
            est = text_width(plain, wh, wwf) if fitlen is None else fitlen
            self.add('text', st, vis, rec)
            if vis:
                frac = {'start': 0.0, 'middle': 0.5, 'end': 1.0}[anchor]
                voff = {'baseline': 0.0, 'bottom': 0.0, 'middle': -0.5, 'top': -1.0}[valign]
                c, sn = math.cos(math.radians(wrot)), math.sin(math.radians(wrot))
                for du, dv in ((-frac * est, voff * wh), ((1 - frac) * est, voff * wh),
                               (-frac * est, (voff + 1) * wh), ((1 - frac) * est, (voff + 1) * wh)):
                    self.grow(wp[0] + du * c - dv * sn, wp[1] + du * sn + dv * c)
        else:
            self.stats['blank_text'] += 1

    def insert(self, o, m, st, depth, vis, path):
        name = (o.s(2) or '').strip()
        self.insert_counts[name] += 1
        if len(self.insert_samples[name]) < 6:
            self.insert_samples[name].append(o)
        if name not in self.doc.blocks:
            self.missing_blocks[name] += 1
            return
        if depth >= 16:
            self.max_depth_hit = True
            return
        base = self.doc.block_objs[name]
        bx, by = base.f(10), base.f(20)
        sx = o.f(41, 1.0) or 1.0
        sy = o.f(42, 1.0) or 1.0
        rot = o.f(50)
        cols = max(1, o.i(70, 1))
        rows = max(1, o.i(71, 1))
        dc = o.f(44)
        dr = o.f(45)
        newpath = (path + '/' if path else '') + name
        for r in range(rows):
            for c in range(cols):
                mm = (m * translate(o.f(10), o.f(20)) * rotate(rot) * translate(c * dc, r * dr)
                      * scalem(sx, sy) * translate(-bx, -by))
                self.walk(self.doc.blocks[name], mm, st, depth + 1, vis, newpath)
        for a in o.children:
            ast = self.resolve(a, None)
            self.text(a, m, ast, vis and self.layer_visible(ast.layer), path)


def text_width(s, h, wf):
    return len(s) * 0.85 * h * wf


def _isnum(v):
    try:
        float(v.strip())
        return True
    except ValueError:
        return False


# ---------------------------------------------------------------- SVG output

FONT = "Helvetica, Arial, 'Liberation Sans', 'DejaVu Sans', sans-serif"


def write_svg(scene, path, title, target=2400.0, margin=24.0):
    minx, miny, maxx, maxy = scene.bbox
    if not math.isfinite(minx):
        minx, miny, maxx, maxy = 0.0, 0.0, 1.0, 1.0
    minx, miny, maxx, maxy = minx - scene.pad, miny - scene.pad, maxx + scene.pad, maxy + scene.pad
    w = maxx - minx
    h = maxy - miny
    span = max(w, h)
    if span <= 0:
        span = 1.0
    S = target / span
    W = w * S + 2 * margin
    H = h * S + 2 * margin

    def X(x):
        return (x - minx) * S + margin

    def Y(y):
        return (maxy - y) * S + margin

    def fmt(v):
        return ('%.2f' % v).rstrip('0').rstrip('.')

    def pt(p):
        return fmt(X(p[0])) + ' ' + fmt(Y(p[1]))

    def dash(lt):
        pat = scene.ltypes.get(lt)
        if not pat:
            return None
        vals = [abs(v) * scene.ltscale * S for v in pat]
        total = sum(vals)
        if total <= 0:
            return None
        if total < 8.0:
            vals = [v * 8.0 / total for v in vals]
        vals = [max(v, 1.0) for v in vals]
        if pat[0] < 0:
            vals = [0.0] + vals
        if len(vals) % 2:
            vals = vals + vals
        return ','.join(fmt(v) for v in vals)

    buckets = collections.OrderedDict()
    order = {'fill': 0, 'path': 1, 'arc': 1, 'circle': 1, 'dot': 2, 'text': 3}
    for kind, st, data in scene.prims:
        sw = st.width * S if kind == 'path' and st.width > 0 else 0.0
        key = (order[kind], st.layer, st.color, st.ltype if kind in ('path', 'arc', 'circle') else '', round(sw, 2))
        buckets.setdefault(key, []).append((kind, data))

    out = []
    out.append('<?xml version="1.0" encoding="UTF-8"?>')
    out.append('<svg xmlns="http://www.w3.org/2000/svg" width="%s" height="%s" viewBox="0 0 %s %s">'
               % (fmt(W), fmt(H), fmt(W), fmt(H)))
    out.append('<title>%s</title>' % html.escape(title))
    out.append('<rect x="0" y="0" width="%s" height="%s" fill="#ffffff"/>' % (fmt(W), fmt(H)))
    for key in sorted(buckets, key=lambda k: k[0]):
        ordk, layer, color, lt, sw = key
        col = svg_color(color)
        items = buckets[key]
        lid = html.escape(layer, quote=True)
        if ordk == 0:
            out.append('<g data-layer="%s" fill="%s" stroke="%s" stroke-width="0.5">' % (lid, col, col))
            for _, ring in items:
                out.append('<polygon points="%s"/>' % ' '.join(pt(p).replace(' ', ',') for p in ring))
            out.append('</g>')
        elif ordk == 1:
            da = dash(lt)
            attrs = 'fill="none" stroke="%s" stroke-width="%s" stroke-linecap="round" stroke-linejoin="round"' % (
                col, fmt(max(sw, 1.0)))
            if sw > 0:
                attrs = attrs.replace('stroke-linecap="round" stroke-linejoin="round"',
                                      'stroke-linecap="butt" stroke-linejoin="miter"')
            if da:
                attrs += ' stroke-dasharray="%s"' % da
            out.append('<g data-layer="%s" %s>' % (lid, attrs))
            d = []
            for kind, data in items:
                if kind == 'circle':
                    cx, cy, r = data
                    out.append('<circle cx="%s" cy="%s" r="%s"/>' % (fmt(X(cx)), fmt(Y(cy)), fmt(r * S)))
                elif kind == 'arc':
                    cx, cy, r, a0, sweep, p0, p1 = data
                    if sweep >= 359.999:
                        out.append('<circle cx="%s" cy="%s" r="%s"/>' % (fmt(X(cx)), fmt(Y(cy)), fmt(r * S)))
                        continue
                    d.append('M%sA%s %s 0 %d 0 %s' % (pt(p0), fmt(r * S), fmt(r * S), 1 if sweep > 180 else 0, pt(p1)))
                else:
                    parts = []
                    for c, a in data:
                        if c == 'M':
                            parts.append('M' + pt(a))
                        elif c == 'L':
                            parts.append('L' + pt(a))
                        elif c == 'A':
                            r, large, ccw, p = a
                            parts.append('A%s %s 0 %d %d %s' % (fmt(r * S), fmt(r * S), 1 if large else 0,
                                                                0 if ccw else 1, pt(p)))
                        elif c == 'Z':
                            parts.append('Z')
                    d.append(''.join(parts))
                if len(d) >= 400:
                    out.append('<path d="%s"/>' % ''.join(d))
                    d = []
            if d:
                out.append('<path d="%s"/>' % ''.join(d))
            out.append('</g>')
        elif ordk == 2:
            out.append('<g data-layer="%s" fill="%s" stroke="none">' % (lid, col))
            rr = max(1.5, 0.003 * target)
            for _, p in items:
                out.append('<circle cx="%s" cy="%s" r="%s"/>' % (fmt(X(p[0])), fmt(Y(p[1])), fmt(rr)))
            out.append('</g>')
        else:
            out.append('<g data-layer="%s" fill="%s" stroke="none" font-family="%s" xml:space="preserve">'
                       % (lid, col, FONT))
            for _, t in items:
                fs = t['h'] * S * 1.38
                if fs <= 0:
                    fs = 1.0
                tr = 'translate(%s %s)' % (fmt(X(t['x'])), fmt(Y(t['y'])))
                if abs(t['rot']) > 1e-6 and abs(t['rot'] - 360.0) > 1e-6:
                    tr += ' rotate(%s)' % fmt(-t['rot'])
                sxv = t['wf']
                syv = 1.0
                if t['gen'] & 2:
                    sxv = -sxv
                if t['gen'] & 4:
                    syv = -1.0
                if abs(sxv - 1.0) > 1e-3 or syv != 1.0:
                    tr += ' scale(%s %s)' % (('%.3f' % sxv), fmt(syv))
                if abs(t['obl']) > 1e-6:
                    tr += ' skewX(%s)' % fmt(-t['obl'])
                y0 = {'baseline': 0.0, 'bottom': 0.0, 'middle': 0.5, 'top': 1.0}[t['valign']] * t['h'] * S
                extra = ''
                if t['fitlen'] is not None:
                    extra = ' textLength="%s" lengthAdjust="spacingAndGlyphs"' % fmt(t['fitlen'] * S / max(abs(sxv), 1e-6))
                if t['underline']:
                    extra += ' text-decoration="underline"'
                if t['anchor'] != 'start':
                    extra += ' text-anchor="%s"' % t['anchor']
                out.append('<text transform="%s" y="%s" font-size="%s"%s>%s</text>'
                           % (tr, fmt(y0), fmt(fs), extra, html.escape(t['text'], quote=False)))
            out.append('</g>')
    out.append('</svg>')
    with open(path, 'w', encoding='utf-8', newline='\n') as fh:
        fh.write('\n'.join(out) + '\n')
    return W, H


# ---------------------------------------------------------------- TXT output

def julian_to_str(jd):
    try:
        jd = float(jd)
    except (TypeError, ValueError):
        return None
    if jd < 2400000:
        return None
    dt = datetime.datetime(1970, 1, 1) + datetime.timedelta(days=jd - 2440587.5)
    return dt.strftime('%Y-%m-%d %H:%M')


def classify(doc):
    hdr = list(doc.header.keys())
    padded = doc.padded_codes > doc.unpadded_codes
    ver = doc.hvar('$ACADVER')
    ltdesc = [(e.s(3) or '') for e in doc.table_entries.get('LTYPE', [])]
    layers = [(e.s(2) or '').strip() for e in doc.table_entries.get('LAYER', [])]
    fonts = sorted({(e.s(3) or '').strip() for e in doc.table_entries.get('STYLE', [])})
    codes = 'group codes right-aligned in 3 columns' if padded else 'group codes left-aligned (no padding)'
    if ver:
        return ('%s; full AutoCAD header with $ACADVER=%s (%s), %d header variables, tables %s'
                % (codes, ver, ACAD_VERSIONS.get(ver, 'unknown release'), len(hdr), '/'.join(doc.tables.keys())))
    if set(hdr) == {'$EXTMAX', '$EXTMIN', '$LIMMAX', '$LIMMIN'}:
        return ('%s; minimal 4-variable header ($EXTMAX,$EXTMIN,$LIMMAX,$LIMMIN), no $ACADVER; '
                'layers %s (plotter-pen export)' % (codes, ','.join(layers[:3]) + (',...' if len(layers) > 3 else '')))
    if any(d.startswith('DynaCADD') for d in ltdesc):
        return ('%s; DynaCADD export (linetypes described "DynaCADD Style - n"), %d header variables in '
                'alphabetical order starting %s, no $ACADVER' % (codes, len(hdr), hdr[0] if hdr else '-'))
    return ('%s; short %d-variable header starting %s, no $ACADVER; layers %s; style font %s'
            % (codes, len(hdr), hdr[0] if hdr else '-',
               ','.join(layers[:3]) + (',...' if len(layers) > 3 else ''), ','.join(fonts) or '-'))


def nfmt(v, dec):
    s = '%.*f' % (dec, v)
    if '.' in s:
        s = s.rstrip('0').rstrip('.')
    if s == '-0':
        s = '0'
    return s


def count_entities(ents):
    c = collections.Counter()
    nv = 0
    for o in ents:
        c[o.type] += 1
        if o.type == 'POLYLINE':
            nv += len(o.children)
        if o.type == 'INSERT' and o.children:
            c['ATTRIB'] += len(o.children)
    return c, nv


def fmt_counts(c, nv=0):
    parts = []
    for k, v in sorted(c.items(), key=lambda kv: (-kv[1], kv[0])):
        if k == 'POLYLINE' and nv:
            parts.append('%s %d (%d vertices)' % (k, v, nv))
        else:
            parts.append('%s %d' % (k, v))
    return ', '.join(parts) if parts else 'none'


def reading_rows(texts):
    groups = collections.defaultdict(list)
    for t in texts:
        a = int(round(t['rot'])) % 360
        groups[a].append(t)
    result = []
    for ang in sorted(groups, key=lambda a: (a != 0, -len(groups[a]), a)):
        items = groups[ang]
        c, s = math.cos(math.radians(ang)), math.sin(math.radians(ang))
        prepared = []
        for t in items:
            u = t['x'] * c + t['y'] * s
            v = -t['x'] * s + t['y'] * c
            w = t['fitlen'] if t['fitlen'] is not None else text_width(t['text'].strip(), t['h'], t['wf'])
            frac = {'start': 0.0, 'middle': 0.5, 'end': 1.0}[t['anchor']]
            voff = {'baseline': 0.0, 'bottom': 0.0, 'middle': -0.5, 'top': -1.0}[t['valign']]
            prepared.append((v + voff * t['h'], u - frac * w, u - frac * w + w, t))
        prepared.sort(key=lambda p: (-p[0], p[1]))
        rows = []
        for p in prepared:
            if rows:
                rv, rh, row = rows[-1]
                tol = 0.5 * max(min(rh, p[3]['h']), 1e-9)
                if abs(rv - p[0]) <= tol:
                    row.append(p)
                    continue
            rows.append([p[0], p[3]['h'], [p]])
        lines = []
        for rv, rh, row in rows:
            row.sort(key=lambda p: p[1])
            txt = ''
            prev_end = None
            for v, ul, ur, t in row:
                piece = t['text'].strip()
                if prev_end is None:
                    txt = piece
                elif ul - prev_end > 2.0 * max(t['h'], rh):
                    txt += '  |  ' + piece
                else:
                    txt += ' ' + piece
                prev_end = ur if prev_end is None else max(prev_end, ur)
            lines.append(txt)
        result.append((ang, len(items), lines, [p[3] for r in rows for p in r[2]]))
    return result


def write_txt(doc, scene, relpath, path, svgname):
    L = []
    b = scene.bbox
    have_bbox = math.isfinite(b[0])
    span = max(b[2] - b[0], b[3] - b[1]) if have_bbox else 1.0
    dec = 2 if span > 200 else (3 if span > 20 else 4)

    def P(x, y):
        return '(%s, %s)' % (nfmt(x, dec), nfmt(y, dec))

    L.append('DXF drawing: %s' % relpath)
    L.append('Render: %s' % svgname)
    L.append('')
    L.append('== Summary ==')
    L.append('File:        %d bytes, %s line ends%s' % (doc.size, 'CR/LF' if doc.crlf else 'LF',
                                                     ', ends with ^Z (0x1A)' if doc.ctrl_z else ''))
    L.append('Dialect:     %s' % classify(doc))
    L.append('Sections:    %s' % ', '.join(doc.sections))
    menu = doc.hvar('$MENU')
    tc = julian_to_str(doc.hvar('$TDCREATE'))
    tu = julian_to_str(doc.hvar('$TDUPDATE'))
    if menu is not None:
        L.append('Menu:        $MENU=%s' % (menu or '(empty)'))
    if tc or tu:
        L.append('Dates:       created %s, last saved %s ($TDCREATE/$TDUPDATE)' % (tc or '-', tu or '-'))
    emin = (doc.hfloat('$EXTMIN', 10), doc.hfloat('$EXTMIN', 20))
    emax = (doc.hfloat('$EXTMAX', 10), doc.hfloat('$EXTMAX', 20))
    if None not in emin and None not in emax:
        L.append('Extents:     header %s - %s' % (P(*emin), P(*emax)))
    if have_bbox:
        L.append('             rendered %s - %s, size %s x %s' % (P(b[0], b[1]), P(b[2], b[3]),
                                                                nfmt(b[2] - b[0], dec), nfmt(b[3] - b[1], dec)))
    lmin = (doc.hfloat('$LIMMIN', 10), doc.hfloat('$LIMMIN', 20))
    lmax = (doc.hfloat('$LIMMAX', 10), doc.hfloat('$LIMMAX', 20))
    if None not in lmin and None not in lmax:
        L.append('Limits:      %s - %s' % (P(*lmin), P(*lmax)))
    lunits = doc.hvar('$LUNITS')
    units = 'not stored in this DXF version'
    if lunits is not None:
        units += '; $LUNITS=%s (%s)' % (lunits, {'1': 'scientific', '2': 'decimal', '3': 'engineering',
                                                 '4': 'architectural', '5': 'fractional'}.get(lunits, '?'))
    if have_bbox and None not in lmin and None not in lmax:
        lspan = max(lmax[0] - lmin[0], lmax[1] - lmin[1])
        if lspan > 0 and 0.2 <= span / lspan <= 1.5:
            if lspan <= 60:
                units += '; limits and extents suggest inches'
            elif lspan >= 150:
                units += '; limits and extents suggest millimetres'
    alltext = ' '.join(t['text'].upper() for t in scene.texts)
    if 'MILLIMETER' in alltext or 'MILLIMETRE' in alltext:
        units += '; a label says millimetres'
    L.append('Units:       %s' % units)
    extras = []
    for var, code in (('$LTSCALE', 40), ('$TEXTSIZE', 40), ('$DIMSCALE', 40), ('$FILLMODE', 70)):
        v = doc.hvar(var, code)
        if v is not None:
            extras.append('%s=%s' % (var, v))
    if extras:
        L.append('Header:      %d variables; %s' % (len(doc.header), ', '.join(extras)))

    styles = doc.table_entries.get('STYLE', [])
    if styles:
        L.append('Text styles: %s' % ', '.join('%s (font %s)' % ((e.s(2) or '').strip(), (e.s(3) or '').strip() or '-')
                                               for e in styles))
    lts = doc.table_entries.get('LTYPE', [])
    if lts:
        L.append('Linetypes:   %s' % ', '.join((e.s(2) or '').strip() for e in lts))

    used_layers = collections.Counter()

    def count_layers(ents):
        for o in ents:
            used_layers[(o.s(8) or '0').strip()] += 1
    count_layers(doc.entities)
    for ents in doc.blocks.values():
        count_layers(ents)
    layer_rows = []
    seen = set()
    for e in doc.table_entries.get('LAYER', []):
        name = (e.s(2) or '').strip()
        seen.add(name)
        col = e.i(62, 7)
        state = []
        if col < 0:
            state.append('off')
        if e.i(70) & 1:
            state.append('frozen')
        layer_rows.append((name, str(abs(col)), (e.s(6) or '').strip(), ','.join(state) or 'on', used_layers.get(name, 0)))
    for name, n in sorted(used_layers.items()):
        if name not in seen:
            layer_rows.append((name, '7', '-', 'not in table', n))
    used_rows = [r for r in layer_rows if r[4]]
    L.append('Layers:      %d in table, %d used' % (len(doc.table_entries.get('LAYER', [])), len(used_rows)))
    if used_rows:
        wname = max(8, max(len(r[0]) for r in used_rows))
        L.append('  %-*s  %5s  %-12s  %-12s  %s' % (wname, 'name', 'color', 'linetype', 'state', 'objects'))
        for r in used_rows:
            L.append('  %-*s  %5s  %-12s  %-12s  %d' % (wname, r[0], r[1], r[2], r[3], r[4]))
    unused = [r[0] for r in layer_rows if not r[4]]
    if unused:
        L.append('  unused: %s' % ', '.join(unused))

    mc, mnv = count_entities(doc.entities)
    L.append('Entities:    model space: %s' % fmt_counts(mc, mnv))
    if doc.blocks:
        tot = collections.Counter()
        tnv = 0
        for ents in doc.blocks.values():
            c, nv = count_entities(ents)
            tot.update(c)
            tnv += nv
        L.append('             in block definitions: %s' % fmt_counts(tot, tnv))
    L.append('Blocks:      %d defined' % len(doc.blocks))
    for name, ents in doc.blocks.items():
        bo = doc.block_objs[name]
        c, nv = count_entities(ents)
        n = scene.insert_counts.get(name, 0)
        L.append('  %s: base %s, %s; inserted %d time%s' % (name, P(bo.f(10), bo.f(20)), fmt_counts(c, nv) or 'empty',
                                                            n, '' if n == 1 else 's'))
        for io in scene.insert_samples.get(name, [])[:3]:
            L.append('      at %s scale %s,%s rotation %s layer %s' % (
                P(io.f(10), io.f(20)), nfmt(io.f(41, 1.0), 5), nfmt(io.f(42, 1.0), 5), nfmt(io.f(50), 3),
                (io.s(8) or '0').strip()))
    for name, n in scene.missing_blocks.items():
        L.append('  %s: INSERTed %d times but not defined' % (name, n))

    notes = []
    for ln, raw, name in doc.repaired:
        notes.append('line %d: corrupted entity name %r read as %s' % (ln, raw, name))
    st = scene.stats
    if st['degenerate_polyline']:
        notes.append('%d zero-length polylines (all vertices identical, e.g. pin dots) drawn as dots'
                     % st['degenerate_polyline'])
    if st['hidden']:
        notes.append('%d objects on layers that are off/frozen are not drawn' % st['hidden'])
    if st['elev_thick']:
        notes.append('%d entities carry elevation/thickness (3D); drawn as plan view' % st['elev_thick'])
    if st['wide_polyline']:
        notes.append('%d polylines with constant width drawn as thick strokes' % st['wide_polyline'])
    if st['blank_text']:
        notes.append('%d TEXT entities are empty or blank' % st['blank_text'])
    if st['mesh_polyline']:
        notes.append('%d mesh polylines drawn as plain vertex chains' % st['mesh_polyline'])
    ntext = sum(1 for t in scene.texts if t['text'].strip())
    nvert = mnv + sum(count_entities(ents)[1] for ents in doc.blocks.values())
    if nvert > 20000 and ntext < 20:
        notes.append('%d polyline vertices but only %d TEXT entities: lettering visible in the SVG is '
                     'probably drawn as outlines and is not listed here' % (nvert, ntext))
    if not scene.fillmode:
        notes.append('$FILLMODE=0: solids drawn as outlines')
    for k, v in st.items():
        if k.startswith('unsupported:'):
            notes.append('%d %s entities not rendered (unsupported)' % (v, k.split(':', 1)[1]))
    if doc.unknown:
        notes.append('unknown object types: %s' % fmt_counts(doc.unknown))
    if scene.max_depth_hit:
        notes.append('block nesting deeper than 16 levels was cut off')
    for w in doc.warnings[:20]:
        notes.append(w)
    if len(doc.warnings) > 20:
        notes.append('... %d more parser warnings' % (len(doc.warnings) - 20))
    if notes:
        L.append('Notes:')
        for n in notes:
            L.append('  - ' + n)

    texts = [t for t in scene.texts if t['text'].strip()]
    inserted = set(scene.insert_counts)
    unused_blocks = [n for n in doc.blocks if n not in inserted]
    block_texts = []
    for name in unused_blocks:
        sub = Scene(doc)
        sub.walk(doc.blocks[name], IDENT, None, 0, True, name)
        block_texts.extend(t for t in sub.texts if t['text'].strip())

    L.append('')
    L.append('== Text in reading order (%d text items) ==' % len(texts))
    if not texts:
        L.append('(no text in drawing)')
    else:
        L.append('Rows from top to bottom per text direction; "|" separates items far apart on the same row.')
    rows = reading_rows(texts) if texts else []
    for ang, n, lines, _ in rows:
        L.append('')
        L.append('-- direction %d deg (%d items) --' % (ang, n))
        for ln in lines:
            L.append('  ' + ln)

    def table(title, items_by_group):
        allitems = [t for g in items_by_group for t in g]
        if not allitems:
            return
        L.append('')
        L.append(title)
        show_src = any(t['src'] for t in allitems)
        show_hidden = any(not t['visible'] for t in allitems)
        wl = max(5, max(len(t['layer']) for t in allitems))
        ws = max(5, max(len(t['style']) for t in allitems))
        wsrc = max(5, max(len(t['src']) for t in allitems)) if show_src else 0
        cols = [nfmt(t['x'], dec) for t in allitems] + [nfmt(t['y'], dec) for t in allitems]
        wn = max(6, max(len(c) for c in cols))
        head = '%*s  %*s  %8s  %5s  %-8s  %-*s  %-*s' % (wn, 'X', wn, 'Y', 'HEIGHT', 'ROT', 'JUST', wl, 'LAYER', ws, 'STYLE')
        if show_src:
            head += '  %-*s' % (wsrc, 'BLOCK')
        head += '  TEXT'
        L.append(head)
        for g in items_by_group:
            for t in g:
                line = '%*s  %*s  %8s  %5s  %-8s  %-*s  %-*s' % (
                    wn, nfmt(t['x'], dec), wn, nfmt(t['y'], dec), nfmt(t['h'], 4), nfmt(t['rot'], 1),
                    t['just'], wl, t['layer'], ws, t['style'])
                if show_src:
                    line += '  %-*s' % (wsrc, t['src'] or '-')
                label = t['text']
                if t['kind'] in ('ATTRIB', 'ATTDEF'):
                    label = '%s %s=%s' % (t['kind'], t['tag'], label)
                if show_hidden and not t['visible']:
                    label += '   [not shown: layer off/frozen]'
                L.append(line + '  ' + label)

    if texts:
        table('== Text entities with coordinates (same order; X/Y is the alignment point used) ==',
              [g[3] for g in rows])
    if block_texts:
        L.append('')
        L.append('== Text in block definitions that are never inserted (%d items, block coordinates) =='
                 % len(block_texts))
        brows = reading_rows(block_texts)
        for ang, n, lines, _ in brows:
            L.append('')
            L.append('-- direction %d deg (%d items) --' % (ang, n))
            for ln in lines:
                L.append('  ' + ln)
        table('-- with coordinates --', [g[3] for g in brows])

    with open(path, 'w', encoding='utf-8', newline='\n') as fh:
        fh.write('\n'.join(ln.rstrip() for ln in L) + '\n')


# ---------------------------------------------------------------- driver

def convert(src, relpath, out_txt, out_svg):
    with open(src, 'rb') as fh:
        data = fh.read()
    doc = parse(data)
    scene = Scene(doc)
    scene.build()
    os.makedirs(os.path.dirname(out_txt), exist_ok=True)
    write_svg(scene, out_svg, relpath)
    write_txt(doc, scene, relpath, out_txt, os.path.basename(out_svg))
    return doc, scene


def main():
    ap = argparse.ArgumentParser(description='DXF to text summary + SVG')
    ap.add_argument('--src-root', required=True)
    ap.add_argument('--out-root', required=True)
    ap.add_argument('--list', help='file with relative paths, one per line')
    ap.add_argument('files', nargs='*', help='relative paths under --src-root')
    args = ap.parse_args()
    rels = list(args.files)
    if args.list:
        with open(args.list, encoding='utf-8') as fh:
            rels += [ln.strip() for ln in fh if ln.strip()]
    ok = 0
    failed = []
    for rel in rels:
        src = os.path.join(args.src_root, rel)
        out_txt = os.path.join(args.out_root, rel + '.txt')
        out_svg = os.path.join(args.out_root, rel + '.svg')
        try:
            doc, scene = convert(src, rel, out_txt, out_svg)
            ok += 1
            print('OK   %s  prims=%d texts=%d warnings=%d' % (rel, len(scene.prims), len(scene.texts), len(doc.warnings)))
        except Exception as ex:
            failed.append((rel, ex))
            print('FAIL %s: %s' % (rel, ex))
            traceback.print_exc()
    print('converted %d/%d' % (ok, len(rels)))
    return 1 if failed else 0


if __name__ == '__main__':
    sys.exit(main())
