#!/usr/bin/env python3
# ABOUTME: Converts WordPerfect 4.1 (Atari ST) / 4.2 documents into plain UTF-8 text.
# ABOUTME: Keeps WordPerfect's line breaks and approximates tabs, indents, centering and flush right with spaces.

import argparse
import os
import sys

# Total length (gates included) of multi-byte function groups 0xC0..0xFE, -1 = variable.
# Source: WordPerfect Corp. "WordPerfect File Information, Version 4.2"; 0xEB is
# documented as 32 bytes but real files differ, so it is scanned.
GROUP_SIZE = [
    6, 4, 3, 5, 5, 6, 4, 6, 8, 42, 3, 6, 4, 3, 4, 3,         # C0-CF
    6, -1, -1, 4, 4, 4, 6, -1, 4, 4, 4, 4, -1, 24, 4, -1,    # D0-DF
    4, 3, -1, 150, 6, 23, 11, 3, 3, -1, -1, -1, 4, -1, 44, 18,  # E0-EF
    6, 106, -1, 100, 4, -1, 5, -1, -1, -1, -1, -1, -1, -1, -1,  # F0-FE
]

DEFAULT_TABS = frozenset(range(0, 160, 5))

# Extended characters seen only as pairs around headings and duplicated on both
# sides of page breaks (WP 5.x attribute on/off relics); not printable text.
DROPPED_EXTENDED = {0xC3, 0xC4}


class CorruptData(Exception):
    def __init__(self, offset, reason):
        super().__init__("offset 0x%x: %s" % (offset, reason))
        self.offset = offset


def tab_table(bits):
    stops = set()
    for n, byte in enumerate(bits):
        for b in range(8):
            if byte & (0x80 >> b):
                stops.add(n * 8 + b)
    return frozenset(stops)


def group_end(data, i):
    """Index of the closing gate of the group starting at data[i]."""
    code = data[i]
    size = GROUP_SIZE[code - 0xC0]
    if size > 0:
        j = i + size - 1
        if j >= len(data) or data[j] != code:
            raise CorruptData(i, "group 0x%02X not closed at expected length %d" % (code, size))
        return j
    if code in (0xD1, 0xD2, 0xE2, 0xF2):
        # these carry text that may contain other function groups
        j = i + 1
        while j < len(data):
            b = data[j]
            if b == code:
                return j
            if 0xC0 <= b <= 0xFE and GROUP_SIZE[b - 0xC0] > 0:
                k = j + GROUP_SIZE[b - 0xC0] - 1
                if k < len(data) and data[k] == b:
                    j = k
            j += 1
        raise CorruptData(i, "unterminated group 0x%02X" % code)
    j = data.find(bytes([code]), i + 1)
    if j < 0:
        raise CorruptData(i, "unterminated group 0x%02X" % code)
    return j


class Renderer:
    def __init__(self, left=10, right=74, tabs=DEFAULT_TABS, strict=True, source=False):
        self.source = source
        self.lm = left
        self.rm = right
        self.tmar = left
        self.tabs = tabs
        self.strict = strict
        self.lines = []
        self.base = left
        self.line = []
        self.footnote_number = None

    # ---- line and column handling ----
    def col(self):
        return self.base + len(self.line)

    def emit(self, text):
        self.line.extend(text)

    def pad_to(self, target, fill=" "):
        cur = self.col()
        if target > cur:
            self.line.extend(fill * (target - cur))
        elif target < cur:
            # margin release: pull back only over leading/trailing blanks
            while self.col() > target and self.line and self.line[-1] == " ":
                self.line.pop()
            if self.col() > target and not self.line:
                self.base = max(0, target)

    def end_line(self, hard):
        self.lines.append("".join(self.line).rstrip())
        self.line = []
        if hard:
            self.tmar = self.lm
        self.base = self.lm
        if self.tmar > self.lm:
            self.line.extend(" " * (self.tmar - self.lm))

    def next_tab(self):
        if self.source:
            self.emit("\t")
            return
        cur = self.col()
        stops = [t for t in self.tabs if t > cur]
        if stops:
            self.pad_to(min(stops))
        else:
            self.emit(" ")

    def text(self):
        if self.line:
            self.lines.append("".join(self.line).rstrip())
            self.line = []
        lines = self.lines
        while lines and not lines[-1]:
            lines.pop()
        return "\n".join(lines) + ("\n" if lines else "")

    # ---- parsing ----
    def feed(self, data, start=0, end=None):
        if end is None:
            end = len(data)
        i = start
        while i < end:
            b = data[i]
            if b >= 0xC0:
                if b == 0xFF:
                    if self.strict:
                        raise CorruptData(i, "stray 0xFF")
                    i += 1
                    continue
                j = group_end(data, i)
                if j >= end:
                    raise CorruptData(i, "group 0x%02X runs past end" % b)
                self.group(data, i, j)
                i = j + 1
                continue
            if b >= 0x80:
                self.single(b)
            elif b >= 0x20:
                if b != 0x7F:
                    self.emit(chr(b))
            elif b == 0x09:
                self.next_tab()
            elif b in (0x0A, 0x0C):
                self.end_line(hard=True)
            elif b in (0x0B, 0x0D):
                if self.source:
                    self.emit(" ")
                else:
                    self.end_line(hard=False)
            elif self.strict:
                raise CorruptData(i, "control byte 0x%02X" % b)
            i += 1

    def single(self, b):
        if b == 0x8C or b in (0xAF, 0xB0):
            self.end_line(hard=True)
        elif b == 0xA0:
            self.emit(" ")
        elif b == 0xA9:
            self.emit("-")
        elif b in (0xAA, 0xAB, 0xAD, 0xAE):
            self.emit("-")
            self.end_line(hard=False)
        elif b == 0x89:
            self.emit(" ")
        elif b == 0x8D and self.footnote_number is not None:
            self.emit(str(self.footnote_number))

    def group(self, data, i, j):
        code = data[i]
        p = data[i + 1:j]
        if code == 0xC0:                        # margin reset
            at_start = not "".join(self.line).strip()
            self.lm, self.rm = p[2], p[3]
            self.tmar = self.lm
            if at_start:
                self.line = []
                self.base = self.lm
        elif code == 0xC2:                      # left margin release
            self.pad_to(self.col() - p[0])
        elif code == 0xC3:                      # center: type, center col, start col
            self.pad_to(p[2])
        elif code == 0xC4:                      # align / flush right: char, align col, start col
            self.pad_to(p[2], "." if p[0] & 0x80 else " ")
        elif code == 0xC9:                      # tab set (4.1 and older)
            self.tabs = tab_table(p[20:40])
        elif code == 0xF1:                      # tab set (4.2)
            self.tabs = tab_table(p[52:84])
        elif code == 0xCC:                      # temporary margin (indent)
            self.tmar = p[1]
            self.pad_to(self.tmar)
        elif code == 0xE0:                      # left/right indent
            self.tmar = self.tmar + p[1]
            self.pad_to(self.tmar)
        elif code == 0xDE:                      # end of temporary margin
            self.tmar = self.lm
        elif code == 0xE1:                      # extended character (IBM PC set)
            if p[0] not in DROPPED_EXTENDED:
                self.emit(bytes([p[0]]).decode("cp437"))
        elif code == 0xEB:                      # date function, expanded at print time
            self.emit("[date]")
        elif code == 0xD1:
            self.header_footer(data, i, j)
        elif code in (0xD2, 0xE2):
            self.footnote(data, i, j)
        elif code == 0xF2:
            self.comment(data, i, j)

    def subdocument(self, data, start, end, left, right):
        sub = Renderer(left, right, self.tabs, self.strict, self.source)
        sub.feed(data, start, end)
        return sub

    def block(self, title, body):
        if "".join(self.line).strip():
            self.end_line(hard=False)
        self.line = []
        self.lines.append("[%s]" % title)
        self.lines.extend(body.rstrip("\n").split("\n") if body.strip() else [])
        self.lines.append("[end %s]" % title.split(",")[0].split(" ")[0].lower())
        self.base = self.lm
        if self.tmar > self.lm:
            self.line.extend(" " * (self.tmar - self.lm))

    def header_footer(self, data, i, j):
        # <D1><old def><old half lines><FF><FF><lmar><rmar> text <FF><half lines><def><D1>
        if j - i < 8 or data[i + 3] != 0xFF or data[j - 3] != 0xFF:
            return
        definition = data[j - 1]
        kind = ("Header A", "Header B", "Footer A", "Footer B")[definition & 3]
        occ = definition >> 2
        where = {0: "discontinued", 1: "every page", 2: "odd pages", 4: "even pages"}.get(occ, "pages 0x%x" % occ)
        text_start = i + 7
        text_end = j - 3
        if data[i + 4] != 0xFF:
            text_start = i + 6
        left, right = data[text_start - 2], data[text_start - 1]
        sub = self.subdocument(data, text_start, text_end, left, right)
        body = sub.text().lstrip("\n")
        if occ == 0 and not body.strip():
            return
        self.block("%s, %s" % (kind, where), body)

    def footnote(self, data, i, j):
        code = data[i]
        ff = data.find(b"\xff", i + 1, j)
        if ff < 0 or ff + 3 > j:
            return
        definition = data[i + 1] if code == 0xE2 else 0
        if code == 0xE2:
            number = (data[i + 2] << 7) | data[i + 3]
            kind = "Endnote" if definition & 2 else "Footnote"
        else:
            number = data[i + 1]
            kind = "Footnote"
        left, right = data[ff + 1], data[ff + 2]
        sub = Renderer(left, right, self.tabs, self.strict, self.source)
        sub.footnote_number = number if not definition & 1 else None
        sub.feed(data, ff + 3, j)
        body = " ".join(line.strip() for line in sub.text().split("\n") if line.strip())
        self.emit("[%s %s: %s]" % (kind, number, body))

    def comment(self, data, i, j):
        # <F2><def><old ufcur><# lines><0> text <F2>
        if j - i < 5:
            return
        sub = self.subdocument(data, i + 5, j, self.lm, self.rm)
        body = sub.text()
        if body.strip():
            self.block("Document summary" if data[i + 1] & 1 else "Comment", body)


def convert(data, truncate=None, source=False):
    """Returns (text, error); error is set when decoding stopped at corrupt data."""
    if truncate is not None:
        data = data[:truncate]
    r = Renderer(source=source)
    try:
        r.feed(data)
    except CorruptData as e:
        return r.text(), e
    return r.text(), None


def main():
    ap = argparse.ArgumentParser(description="Convert WordPerfect 4.x documents to plain text.")
    ap.add_argument("input", nargs="?")
    ap.add_argument("-o", "--output")
    ap.add_argument("--truncate", type=lambda s: int(s, 0),
                    help="decode only the first N bytes (for files with a known corrupt tail)")
    ap.add_argument("--source", action="store_true",
                    help="program listing: keep tab characters and join lines WordPerfect wrapped")
    ap.add_argument("--batch", nargs=3, metavar=("LIST", "SRCROOT", "DSTROOT"),
                    help="convert every file in LIST (paths relative to SRCROOT)")
    args = ap.parse_args()

    if args.batch:
        lst, src, dst = args.batch
        failures = 0
        for rel in open(lst).read().split("\n"):
            rel = rel.strip()
            if not rel:
                continue
            data = open(os.path.join(src, rel), "rb").read()
            limit = TRUNCATE.get(rel)
            text, err = convert(data, limit, rel in SOURCE_LISTINGS)
            if limit is not None:
                text += "\n[remainder of the original file is corrupt and was not decoded]\n"
            out = os.path.join(dst, rel + ".txt")
            os.makedirs(os.path.dirname(out), exist_ok=True)
            with open(out, "w", encoding="utf-8", newline="\n") as f:
                f.write(text)
            status = "ok" if err is None else "STOPPED: %s" % err
            if err is not None:
                failures += 1
            print("%-40s %6d lines  %s" % (rel, text.count("\n"), status))
        sys.exit(1 if failures else 0)

    if not args.input:
        ap.error("input file or --batch required")
    text, err = convert(open(args.input, "rb").read(), args.truncate, args.source)
    if args.output:
        with open(args.output, "w", encoding="utf-8", newline="\n") as f:
            f.write(text)
    else:
        sys.stdout.write(text)
    if err is not None:
        print("warning: %s" % err, file=sys.stderr)
        sys.exit(1)


# The zip entry of FALCON.WP2 is missing a compressed sector; bytes after
# "2.7<tab>Real Time Clo" (offset 0x4A1) are unzip garbage.
TRUNCATE = {"WP/FALCON/FALCON.WP2.DAMAGED": 0x4A1}

# Assembler sources loaded into WordPerfect: columns line up only with 8-column
# tabs and long lines were wrapped at the margin (compare MENU.S / RAM.S).
SOURCE_LISTINGS = {"WP/SPARROW/DIAGS/MENU.WP", "WP/SPARROW/DIAGS/RAM.WP"}

if __name__ == "__main__":
    main()
