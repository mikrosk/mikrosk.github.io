# ABOUTME: Converts GST 1st Word Plus (Atari ST, WP mode) documents into plain UTF-8 text.
# ABOUTME: Drops rulers and style codes, removes justification padding, keeps headers, footers and page breaks.
import argparse
import os
import sys

ROOT = '/home/mikro/atari/microbox'

ESC = 0x1B          # style change, next byte = 0x80 | bold 1, light 2, italic 4, underline 8, super 16, sub 32
COND_BREAK = 0x0B   # conditional page break, next byte encodes the protected line count
HARD_BREAK = 0x0C
FORMAT = 0x1F       # at line start: layout record; inside header/footer records: field separator
VAR_SPACE = 0x1E    # word space typed with the space bar; at line end it marks a soft (word-wrap) return
INDENT = 0x1D       # indent space, followed by stretch spaces up to the tab stop
STRETCH = 0x1C      # filler: part of an indent after 0x1D, justification padding after 0x1E

ATARI_HIGH = (
    'ÇüéâäàåçêëèïîìÄÅ'
    'ÉæÆôöòûùÿÖÜ¢£¥ßƒ'
    'áíóúñÑªº¿⌐¬½¼¡«»'
    'ãõØøœŒÀÃÕ¨´†¶©®™'
    'ĳĲאבגדהוזחטיכלמנ'
    'סעפצקרשתןךםףץ§∧∞'
    'αβΓπΣσµτΦΘΩδ∮φ∈∩'
    '≡±≥≤⌠⌡÷≈°∙·√ⁿ²³¯'
)


def char(b, unknown):
    if 0x20 <= b < 0x7F:
        return chr(b)
    if b >= 0x80:
        return ATARI_HIGH[b - 0x80]
    unknown[b] = unknown.get(b, 0) + 1
    return ''


def decode_bytes(data, unknown):
    return ''.join(char(b, unknown) for b in data)


def text_line(line, unknown):
    """Returns (text, soft_return) for one body line."""
    out = []
    filler_kind = None      # what the current run of stretch spaces belongs to
    last_code = None        # last byte that is not a style or conditional break code
    i = 0
    while i < len(line):
        b = line[i]
        if b in (ESC, COND_BREAK):
            i += 2
            continue
        last_code = b
        if b == VAR_SPACE:
            out.append(' ')
            filler_kind = 'pad'
        elif b == INDENT:
            out.append(' ')
            filler_kind = 'indent'
        elif b == STRETCH:
            if filler_kind == 'indent':
                out.append(' ')
        elif b == HARD_BREAK:
            out.append('\f')
            filler_kind = None
        else:
            out.append(char(b, unknown))
            filler_kind = None
        i += 1
    soft = last_code in (VAR_SPACE, STRETCH) and filler_kind == 'pad'
    return ''.join(out).rstrip(' '), soft


def header_note(kind, fields, unknown):
    names = ('left', 'centre', 'right')
    parts = ['%s=%s' % (n, decode_bytes(f, unknown).strip())
             for n, f in zip(names, fields) if decode_bytes(f, unknown).strip()]
    return '[%s: %s]' % (kind, ' | '.join(parts)) if parts else None


def convert(data, unwrap=False):
    unknown = {}
    records = []
    lines = data.split(b'\n')
    if lines and lines[-1] == b'':
        lines.pop()
    out = []
    joining = False
    for raw in lines:
        line = raw[:-1] if raw.endswith(b'\r') else raw
        if line[:1] == bytes([FORMAT]):
            kind = line[1:2]
            if kind in (b'1', b'2'):
                note = header_note('Header' if kind == b'1' else 'Footer', line[2:].split(bytes([FORMAT])), unknown)
                if note:
                    out.append(note)
            elif kind not in (b'0', b'9', b'F'):
                records.append(kind)
                out.append('[1st Word Plus record %r: %s]' % (kind.decode('latin-1'), decode_bytes(line[2:], {})))
            joining = False
            continue
        text, soft = text_line(line, unknown)
        if joining and out:
            out[-1] = out[-1] + ' ' + text.lstrip(' ')
        else:
            out.append(text)
        joining = unwrap and soft
    while out and out[-1] == '':
        out.pop()
    return '\n'.join(out) + '\n', unknown, records


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--unwrap', action='store_true', help='join word-wrapped lines into one line per paragraph')
    ap.add_argument('--list', help='file list relative to --src; writes <dst>/<path>.txt')
    ap.add_argument('--src', default=os.path.join(ROOT, 'TECHPUBS'))
    ap.add_argument('--dst', default=os.path.join(ROOT, 'TECHPUBS_txt'))
    ap.add_argument('files', nargs='*', help='single documents, converted to stdout')
    args = ap.parse_args()

    jobs = [(f, None) for f in args.files]
    if args.list:
        for rel in open(args.list).read().split('\n'):
            if rel.strip():
                jobs.append((os.path.join(args.src, rel), os.path.join(args.dst, rel + '.txt')))
    for src, dst in jobs:
        text, unknown, records = convert(open(src, 'rb').read(), args.unwrap)
        if unknown:
            print('%s: dropped control bytes %s' % (src, {hex(k): v for k, v in sorted(unknown.items())}), file=sys.stderr)
        if records:
            print('%s: unhandled format records %s' % (src, records), file=sys.stderr)
        if dst is None:
            sys.stdout.write(text)
            continue
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        with open(dst, 'w', encoding='utf-8', newline='\n') as f:
            f.write(text)


if __name__ == '__main__':
    main()
