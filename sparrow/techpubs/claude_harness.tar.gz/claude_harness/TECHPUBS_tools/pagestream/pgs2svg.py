#!/usr/bin/env python3
# ABOUTME: Renders pages of Soft-Logik PageStream 2.x (Atari ST) documents to SVG: vector drawing objects
# ABOUTME: plus text frames laid out approximately, one SVG per page that carries drawing objects.
import math
import os
import struct
import sys
from xml.sax.saxutils import escape

import pgs2txt as core
from pgs2txt import u16, s16, u32, s32

UNITS_PER_PT = 100      # document coordinates are 1/7200 inch
MIN_STROKE = 20
DEFAULT_TAB = 3600

# Dash masks of the line styles (index = object byte 26), from PGS2.PRG.
LINE_STYLES = [0x0000, 0xFFFF, 0xFFF0, 0xC0C0, 0xFF18, 0xFF00, 0xF8C8, 0xAAAA, 0x8888]

TYPE_NAMES = {0: 'group', 4: 'text column', 8: 'text block', 12: 'bitmap', 16: 'path', 20: 'polyline',
              24: 'box', 28: 'box', 32: 'line', 36: 'line', 40: 'ellipse/arc', 44: 'ellipse/arc',
              48: 'imported graphic'}

SANS_FONTS = {0x02030E71}
MONO_TAGS = ('program example', 'code', 'type keys')


def load_patterns():
    """16x16 fill pattern bitmaps (32 bytes each) from PGS2.PRG, if the program is available."""
    prg = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..', 'TECHPUBS', 'TEMP', 'PGS2.PRG')
    try:
        with open(prg, 'rb') as fh:
            d = fh.read()
    except OSError:
        return None
    base = 0x1C + 0x4D4D2
    return [d[base + 32 * i:base + 32 * (i + 1)] for i in range(40)]


PATTERNS = load_patterns()


def fmt(v):
    if isinstance(v, int):
        return str(v)
    s = '%.1f' % v
    return s[:-2] if s.endswith('.0') else s


def colour(idx):
    # Documents in this set define no colours of their own: index 0 is white, every other index black.
    return '#fff' if idx == 0 else '#000'


class Svg:
    def __init__(self):
        self.defs = {}
        self.undecoded = {}

    def pattern_id(self, pat, col):
        key = 'p%d%s' % (pat, 'w' if col == '#fff' else 'b')
        if key not in self.defs:
            bits = PATTERNS[pat] if PATTERNS and pat < len(PATTERNS) else b'\xff' * 32
            cell = 25
            rects = []
            for row in range(16):
                word = (bits[2 * row] << 8) | bits[2 * row + 1]
                for c in range(16):
                    if word & (0x8000 >> c):
                        rects.append('<rect x="%d" y="%d" width="%d" height="%d"/>' % (c * cell, row * cell, cell, cell))
            self.defs[key] = ('<pattern id="%s" patternUnits="userSpaceOnUse" width="%d" height="%d">'
                              '<g fill="%s">%s</g></pattern>' % (key, 16 * cell, 16 * cell, col, ''.join(rects)))
        return 'url(#%s)' % key


def paint_attrs(svg, rec, stroke=True, fill=True, ends=False):
    """SVG presentation attributes for object record bytes 24-31."""
    width = u16(rec, 24)
    ls, lc, fp, fc = rec[26], rec[27], rec[28], rec[29]
    attrs = []
    if fill and fp:
        col = colour(fc)
        if fp & 0x80:
            pct = min(fp & 0x7F, 100)
            attrs.append('fill="%s" fill-opacity="%s"' % (col, fmt(pct / 100.0)))
        elif fp == 9:
            attrs.append('fill="%s"' % col)
        elif 2 <= fp <= 8 and PATTERNS:
            cover = sum(bin(b).count('1') for b in PATTERNS[fp]) / 256.0
            attrs.append('fill="%s" fill-opacity="%s"' % (col, fmt(round(cover, 2))))
        elif fp >= 10:
            attrs.append('fill="%s"' % svg.pattern_id(fp, col))
        else:
            attrs.append('fill="none"')
    else:
        attrs.append('fill="none"')
    if stroke and ls:
        w = max(width, MIN_STROKE)
        attrs.append('stroke="%s" stroke-width="%s"' % (colour(lc), fmt(w)))
        mask = LINE_STYLES[ls] if ls < len(LINE_STYLES) else 0xFFFF
        if mask not in (0, 0xFFFF):
            attrs.append('stroke-dasharray="%s"' % dash_array(mask, max(width, 50)))
        cap = 'round' if ends and (rec[30] == 2 or rec[31] == 2) else 'butt'
        attrs.append('stroke-linecap="%s" stroke-linejoin="round"' % cap)
    else:
        attrs.append('stroke="none"')
    return ' '.join(attrs)


def dash_array(mask, unit):
    bits = [(mask >> (15 - i)) & 1 for i in range(16)]
    while bits[0] == 0:
        bits = bits[1:] + bits[:1]
    runs = []
    cur, n = bits[0], 0
    for b in bits:
        if b == cur:
            n += 1
        else:
            runs.append(n)
            cur, n = b, 1
    runs.append(n)
    if len(runs) % 2:
        runs.append(0)
    return ','.join(fmt(r * unit) for r in runs)


def transform_attr(rec):
    """Rotation/flip about the box centre: x' = dx*cos(B) + dy*sin(A), y' = dy*cos(A) - dx*sin(B)."""
    a, b = u16(rec, 20), u16(rec, 22)
    if a == 0 and b == 0:
        return ''
    x1, y1, x2, y2 = struct.unpack_from('>iiii', rec, 2)
    cx = x1 + ((x2 - x1) >> 1)
    cy = y1 + ((y2 - y1) >> 1)
    ra, rb = math.radians(a / 100.0), math.radians(b / 100.0)
    m = [math.cos(rb), -math.sin(rb), math.sin(ra), math.cos(ra)]
    m = [0.0 if abs(v) < 1e-9 else v for v in m]
    e = cx - m[0] * cx - m[2] * cy
    f = cy - m[1] * cx - m[3] * cy
    return ' transform="matrix(%s)"' % ','.join('%.6g' % v for v in m + [e, f])


def arc_point(cx, cy, rx, ry, ang):
    r = math.radians(ang / 100.0)
    return cx + rx * math.cos(r), cy - ry * math.sin(r)


def arc_sweep(start, end, ccw):
    """Sweep in 1/100 degree as PGS2.PRG computes it: 16-bit difference, 36000 added on borrow."""
    diff = end - start if ccw else start - end
    return diff + 36000 if diff < 0 else diff


def arc_path(cx, cy, rx, ry, start, end, ccw, move):
    """SVG path segments for an elliptical arc; angles in 1/100 degree, y axis pointing down."""
    sweep = arc_sweep(start, end, ccw)
    x0, y0 = arc_point(cx, cy, rx, ry, start)
    parts = ['%s%s %s' % ('M' if move else 'L', fmt(x0), fmt(y0))]
    if sweep == 0 or rx == 0 or ry == 0:
        return parts
    steps = int(math.ceil(sweep / 9000.0))
    for i in range(1, steps + 1):
        ang = start + (sweep * i / float(steps)) * (1 if ccw else -1)
        x, y = arc_point(cx, cy, rx, ry, ang)
        parts.append('A%s %s 0 0 %d %s %s' % (fmt(rx), fmt(ry), 0 if ccw else 1, fmt(x), fmt(y)))
    return parts


def arrow_heads(rec, pts_start, pts_end):
    """Filled triangles for line ends set to the arrow style (value 1)."""
    width = max(u16(rec, 24), MIN_STROKE)
    length = max(3 * width, 400) * 1.5
    half = length / 3.0
    out = []
    for style, (tip, prev) in ((rec[30], pts_start), (rec[31], pts_end)):
        if style != 1 or tip is None or prev is None:
            continue
        dx, dy = tip[0] - prev[0], tip[1] - prev[1]
        dist = math.hypot(dx, dy)
        if dist == 0:
            continue
        ux, uy = dx / dist, dy / dist
        bx, by = tip[0] - ux * length, tip[1] - uy * length
        pts = [tip, (bx - uy * half, by + ux * half), (bx + uy * half, by - ux * half)]
        out.append('<path d="M%s Z" fill="%s" stroke="none"/>' % (
            ' L'.join('%s %s' % (fmt(x), fmt(y)) for x, y in pts), colour(rec[27])))
    return out


def render_path_blob(svg, ob):
    """Type 16: scaled command list (newpath/close/end/moveto/lineto/curveto/arc)."""
    rec, d = ob.rec, ob.data
    if d is None or len(d) < 18:
        return []
    x0, y0 = s32(rec, 2), s32(rec, 6)
    xs, ys = u16(d, 12), u16(d, 14)
    count = u16(d, 16)
    k = 18
    out = []
    path = []
    first = last = before_last = None
    subpath_start = None

    def pt():
        nonlocal k
        px, py = s32(d, k), s32(d, k + 4)
        k += 8
        return px * xs / 100.0 + x0, py * ys / 100.0 + y0

    def rel():
        nonlocal k
        px, py = s32(d, k), s32(d, k + 4)
        k += 8
        return px * xs / 100.0, py * ys / 100.0

    try:
        for _ in range(count):
            cmd = u16(d, k)
            k += 2
            if cmd == 0:
                path = []
            elif cmd == 4:
                path.append('Z')
                if subpath_start is not None:
                    before_last, last = last, subpath_start
            elif cmd in (8, 12):
                if path:
                    filled = cmd == 8 and rec[28]
                    attrs = paint_attrs(svg, rec, fill=bool(filled), ends=not rec[28])
                    out.append('<path d="%s" %s/>' % (' '.join(path), attrs))
                    if not rec[28] and rec[26] and 'Z' not in path:
                        out.extend(arrow_heads(rec, (first[0], first[1]) if first else (None, None),
                                               (last, before_last)))
                path = []
            elif cmd == 16:
                p = pt()
                path.append('M%s %s' % (fmt(p[0]), fmt(p[1])))
                first = (p, None)
                subpath_start = p
                before_last, last = last, p
            elif cmd == 20:
                p = pt()
                path.append('L%s %s' % (fmt(p[0]), fmt(p[1])))
                if first is not None and first[1] is None:
                    first = (first[0], p)
                before_last, last = last, p
            elif cmd == 24:
                c1, c2, p = pt(), pt(), pt()
                path.append('C%s %s %s %s %s %s' % (fmt(c1[0]), fmt(c1[1]), fmt(c2[0]), fmt(c2[1]),
                                                    fmt(p[0]), fmt(p[1])))
                if first is not None and first[1] is None:
                    first = (first[0], c1)
                before_last, last = c2, p
            elif cmd in (28, 32):
                c = pt()
                r = rel()
                a0, a1 = u16(d, k), u16(d, k + 2)
                k += 4
                path.extend(arc_path(c[0], c[1], abs(r[0]), abs(r[1]), a0, a1, cmd == 28, not path))
                last = arc_point(c[0], c[1], abs(r[0]), abs(r[1]), a1)
            else:
                svg.undecoded['path command %d' % cmd] = svg.undecoded.get('path command %d' % cmd, 0) + 1
                break
    except struct.error:
        svg.undecoded['truncated path data'] = svg.undecoded.get('truncated path data', 0) + 1
    if path:
        out.append('<path d="%s" %s/>' % (' '.join(path), paint_attrs(svg, rec, fill=False, ends=True)))
    return out


def render_polyline(svg, ob):
    rec, d = ob.rec, ob.data
    if not rec[26] or d is None or len(d) < 18:
        return []
    x0, y0 = s32(rec, 2), s32(rec, 6)
    xs, ys = u16(d, 12), u16(d, 14)
    n = u16(d, 16)
    pts = []
    for i in range(n):
        o = 18 + 8 * i
        if o + 8 > len(d):
            break
        pts.append((s32(d, o) * xs / 100.0 + x0, s32(d, o + 4) * ys / 100.0 + y0))
    if len(pts) < 2:
        return []
    out = ['<polyline points="%s" %s/>' % (' '.join('%s,%s' % (fmt(x), fmt(y)) for x, y in pts),
                                           paint_attrs(svg, rec, fill=False, ends=True))]
    out.extend(arrow_heads(rec, (pts[0], pts[1]), (pts[-1], pts[-2])))
    return out


def render_box(svg, ob):
    rec = ob.rec
    x1, y1, x2, y2 = struct.unpack_from('>iiii', rec, 2)
    rx = min(abs(x2 - x1) >> 1, u16(rec, 32))
    ry = min(abs(y2 - y1) >> 1, u16(rec, 34))
    attrs = paint_attrs(svg, rec)
    x, y, w, h = min(x1, x2), min(y1, y2), abs(x2 - x1), abs(y2 - y1)
    if rx or ry:
        return ['<rect x="%d" y="%d" width="%d" height="%d" rx="%d" ry="%d" %s/>' % (x, y, w, h, rx, ry, attrs)]
    return ['<rect x="%d" y="%d" width="%d" height="%d" %s/>' % (x, y, w, h, attrs)]


def render_line(svg, ob):
    rec = ob.rec
    if not rec[26]:
        return []
    x1, y1, x2, y2 = struct.unpack_from('>iiii', rec, 2)
    out = ['<line x1="%d" y1="%d" x2="%d" y2="%d" %s/>' % (x1, y1, x2, y2,
                                                            paint_attrs(svg, rec, fill=False, ends=True))]
    out.extend(arrow_heads(rec, ((x1, y1), (x2, y2)), ((x2, y2), (x1, y1))))
    return out


def render_ellipse(svg, ob):
    rec = ob.rec
    x1, y1, x2, y2 = struct.unpack_from('>iiii', rec, 2)
    cx, cy = min(x1, x2) + abs(x2 - x1) / 2.0, min(y1, y2) + abs(y2 - y1) / 2.0
    rx, ry = abs(x2 - x1) / 2.0, abs(y2 - y1) / 2.0
    a0, a1 = u16(rec, 32), u16(rec, 34)
    out = []
    sweep = arc_sweep(a0, a1, True)
    if sweep >= 36000:
        return ['<ellipse cx="%s" cy="%s" rx="%s" ry="%s" %s/>' % (fmt(cx), fmt(cy), fmt(rx), fmt(ry),
                                                                paint_attrs(svg, rec))]
    if sweep == 0:
        return []
    if rec[28]:
        d = ['M%s %s' % (fmt(cx), fmt(cy))] + arc_path(cx, cy, rx, ry, a0, a1, True, False) + ['Z']
        out.append('<path d="%s" %s/>' % (' '.join(d), paint_attrs(svg, rec, stroke=False)))
    if rec[26]:
        d = arc_path(cx, cy, rx, ry, a0, a1, True, True)
        out.append('<path d="%s" %s/>' % (' '.join(d), paint_attrs(svg, rec, fill=False, ends=True)))
    return out


# ---------------------------------------------------------------------------------------------
# Text frames


class Style:
    __slots__ = ('font', 'style', 'width', 'size', 'track', 'lead', 'indent1', 'left', 'right', 'align',
                 'dingbat', 'mono')

    def copy(self):
        s = Style()
        for k in self.__slots__:
            setattr(s, k, getattr(self, k))
        return s


def style_from(rec, off):
    """Character/paragraph attributes stored as font(L) style(L) width(L) size(L) 0x22..0x25(W) indents(WW)."""
    s = Style()
    s.font = u32(rec, off)
    s.style = u32(rec, off + 4)
    s.width = s32(rec, off + 8)
    s.size = s32(rec, off + 12)
    s.track = s16(rec, off + 16)
    s.lead = u16(rec, off + 18)
    s.indent1 = s16(rec, off + 22)
    s.left = u16(rec, off + 24)
    s.right = u16(rec, off + 26)
    s.align = rec[off + 29] & 7
    s.dingbat = False
    s.mono = False
    return s


def decode_styled(doc, text, frame):
    """Returns (tokens, bounds). Tokens: (offset, kind, value, style); kind is 'c', 'tab', 'para', 'page'."""
    st = style_from(frame, 58)
    base_font = st.font
    before_tag = None
    tokens = []
    bounds = set()
    k = 0
    n = len(text)
    while k < n:
        bounds.add(k)
        b = text[k]
        if b == 0 and k + 1 < n:
            c = text[k + 1]
            arg = text[k + 2:k + 2 + (core.ARGLEN[c] if c < len(core.ARGLEN) else 0)]
            st = st.copy()
            if c == core.CMD_PARA:
                tokens.append((k, 'para', None, st))
            elif c == core.CMD_TAB:
                tokens.append((k, 'tab', None, st))
            elif c == core.CMD_PAGENUM:
                tokens.append((k, 'page', None, st))
            elif c == core.CMD_TAG and arg:
                t = arg[0]
                if 0 < t <= len(doc.tags):
                    if before_tag is None:
                        before_tag = st
                    tag = doc.tags[t - 1]
                    st = style_from(tag_record(doc, t - 1), 32)
                    st.dingbat = core.DINGBAT in tag['name'].lower()
                    st.mono = any(m in tag['name'].lower() for m in MONO_TAGS)
                elif before_tag is not None:
                    # Clearing the tag returns to the attributes that were active before it.
                    st = before_tag.copy()
                    before_tag = None
            elif c == core.CMD_FONT and len(arg) == 4:
                base_font = st.font = u32(arg, 0)
                st.dingbat = False
            elif c == 0x21 and len(arg) == 4:
                st.style = u32(arg, 0)
            elif c == 0x40 and len(arg) == 8:
                st.width, st.size = s32(arg, 0), s32(arg, 4)
            elif c == 0x22:
                st.track = s16(arg, 0)
            elif c == 0x23:
                st.lead = u16(arg, 0)
            elif c == 0x25:
                st.indent1 = s16(arg, 0)
            elif c == 0x41 and len(arg) == 4:
                st.left, st.right = u16(arg, 0), u16(arg, 2)
            elif c == 0x11 and arg:
                st.align = arg[0] & 7
            k += 2 + len(arg)
        else:
            if b >= 0x20:
                ch = core.map_char(b, core.DINGBAT if st.dingbat else st.font)
                if ch:
                    tokens.append((k, 'c', ch, st))
            k += 1
    bounds.add(n)
    return tokens, bounds


def tag_record(doc, i):
    return doc.raw[core.HEADER_SIZE + i * core.TAG_SIZE:core.HEADER_SIZE + (i + 1) * core.TAG_SIZE]


def line_height(st):
    size = st.size if st.size > 0 else 1200
    if st.lead & 0x8000:
        rel = st.lead & 0x7FFF
        if rel & 0x4000:
            rel -= 0x8000
        return max(size + rel, 1)
    return st.lead if st.lead else size


# Advance widths (1/1000 em) of the standard Times-Roman and Helvetica fonts for ASCII 32-126; the SVG
# names metric-compatible families so the estimated positions match the rendered glyphs.
TIMES_WIDTHS = [250, 333, 408, 500, 500, 833, 778, 333, 333, 333, 500, 564, 250, 333, 250, 278,
                500, 500, 500, 500, 500, 500, 500, 500, 500, 500, 278, 278, 564, 564, 564, 444,
                921, 722, 667, 667, 722, 611, 556, 722, 722, 333, 389, 722, 611, 889, 722, 722,
                556, 722, 667, 556, 611, 722, 722, 944, 722, 722, 611, 333, 278, 333, 469, 500,
                333, 444, 500, 444, 500, 444, 333, 500, 500, 278, 278, 500, 278, 778, 500, 500,
                500, 500, 333, 389, 278, 500, 500, 722, 500, 500, 444, 480, 200, 480, 541]
HELVETICA_WIDTHS = [278, 278, 355, 556, 556, 889, 667, 222, 333, 333, 389, 584, 278, 333, 278, 278,
                    556, 556, 556, 556, 556, 556, 556, 556, 556, 556, 278, 278, 584, 584, 584, 556,
                    1015, 667, 667, 722, 722, 667, 611, 778, 722, 278, 500, 667, 556, 833, 722, 778,
                    667, 778, 722, 667, 611, 722, 667, 944, 667, 667, 611, 278, 278, 278, 469, 556,
                    222, 556, 556, 500, 556, 556, 278, 556, 556, 222, 222, 500, 222, 833, 556, 556,
                    556, 556, 333, 500, 278, 556, 500, 722, 500, 500, 500, 334, 260, 334, 584]


def char_advance(ch, st, factor):
    size = st.size if st.size > 0 else 1200
    width = st.width if size * 0.2 <= st.width <= size * 5 else size
    family = font_family(st)
    code = ord(ch) if len(ch) == 1 else 0
    if family.endswith('monospace'):
        em = 600
    elif 32 <= code < 127:
        em = (HELVETICA_WIDTHS if family.endswith('sans-serif') else TIMES_WIDTHS)[code - 32]
    else:
        em = 556 if family.endswith('sans-serif') else 500
    if st.style & 1:
        em *= 1.05
    return (em * factor / 1000.0 + st.track / 10000.0) * width


def tab_stops(frame):
    stops = []
    for o in range(94, 178, 4):
        v = s32(frame, o)
        if v <= 0 or (stops and v <= stops[-1]) or v > 400000:
            break
        stops.append(v)
    return stops


def place_line(y, lh, left, right, obstacles, limit):
    """Moves a line below runaround obstacles when the widest free gap beside them is too narrow."""
    for _ in range(64):
        blocked = [o for o in obstacles if o[1] < y + lh and o[3] > y and o[2] > left and o[0] < right]
        if not blocked:
            return y, left, right
        free = []
        pos = left
        for x1, _, x2, _ in sorted(blocked):
            if x1 > pos:
                free.append((pos, x1))
            pos = max(pos, x2)
        if pos < right:
            free.append((pos, right))
        best = max(free, key=lambda seg: seg[1] - seg[0]) if free else None
        if best and best[1] - best[0] >= max(0.25 * (right - left), 1800):
            return y, best[0], best[1]
        y = min(o[3] for o in blocked)
        if y > limit:
            break
    return y, left, right


def layout_frame(ob, tokens, page_label, factor, wrap, obstacles):
    """Breaks the frame's tokens into lines of (chars with x, baseline, left, right, last line of paragraph)."""
    fw = abs(ob.right - ob.left)
    stops = tab_stops(ob.frame)
    paras = []
    para = []
    for tok in tokens:
        if tok[1] == 'para':
            paras.append((para, tok[3]))
            para = []
        elif tok[1] == 'page':
            para.extend((tok[0], 'c', ch, tok[3]) for ch in page_label)
        else:
            para.append(tok)
    if para:
        paras.append((para, para[-1][3]))
    lines = []
    y = ob.top
    for items, pst in paras:
        fst = items[0][3] if items else pst
        i = 0
        first = True
        while True:
            lh = line_height(items[i][3] if i < len(items) else fst)
            left = fst.left + (max(fst.indent1, 0) if first else max(-fst.indent1, 0))
            right = fw - fst.right
            if wrap and obstacles:
                y, al, ar = place_line(y, lh, ob.left + left, ob.left + right, obstacles, ob.bottom)
                left, right = al - ob.left, ar - ob.left
            x = left
            cur = []
            last_space = None
            tabbed = False
            j = i
            while j < len(items):
                off, kind, val, st = items[j]
                if kind == 'tab':
                    nxt = [t for t in stops if t > x + 1]
                    x = nxt[0] if nxt else (int(x / DEFAULT_TAB) + 1) * DEFAULT_TAB
                    last_space = None
                    tabbed = True
                    j += 1
                    continue
                adv = char_advance(val, st, factor)
                if wrap and cur and val != ' ' and x + adv > right:
                    if last_space is not None:
                        cur = cur[:last_space[0]]
                        j = last_space[1] + 1
                    break
                cur.append((x, 'tab' if tabbed else 'c', val, st))
                tabbed = False
                if val == ' ':
                    last_space = (len(cur) - 1, j)
                x += adv
                j += 1
            if cur:
                lh = max(line_height(t[3]) for t in cur)
            done = j >= len(items)
            lines.append((cur, y + lh * 21.0 / 26.0, left, right, done, factor))
            y += lh
            i = j
            first = False
            if done:
                break
    return lines, y - ob.top


def font_family(st):
    if st.mono or st.font in (0x0100020F, 0x01002C60):
        return "'Courier New', 'Liberation Mono', monospace"
    if st.font in SANS_FONTS:
        return "Arial, Helvetica, 'Liberation Sans', sans-serif"
    return "'Times New Roman', Times, 'Liberation Serif', serif"


def render_text_lines(ob, placed):
    out = []
    for cur, baseline, left, right_edge, last, factor in placed:
        chars = list(cur)
        while chars and chars[-1][2] == ' ':
            chars.pop()
        if not chars:
            continue
        st0 = chars[0][3]
        end = chars[-1][0] + char_advance(chars[-1][2], chars[-1][3], factor)
        xs = [c[0] for c in chars]
        if st0.align == 1:
            xs = [x + (right_edge - end) / 2.0 for x in xs]
        elif st0.align == 2:
            xs = [x + right_edge - end for x in xs]
        elif st0.align >= 3 and not last and not any(c[1] == 'tab' for c in chars):
            spaces = sum(1 for c in chars if c[2] == ' ')
            if spaces and right_edge > end:
                extra, add, adj = (right_edge - end) / float(spaces), 0.0, []
                for c, x in zip(chars, xs):
                    adj.append(x + add)
                    if c[2] == ' ':
                        add += extra
                xs = adj
        # Every glyph gets its estimated position, so substitute fonts cannot push text out of place.
        spans = []
        for c, x in zip(chars, xs):
            if spans and same_style(spans[-1][2], c[3]):
                spans[-1][0].append(ob.left + x)
                spans[-1][1].append(c[2])
            else:
                spans.append([[ob.left + x], [c[2]], c[3]])
        parts = []
        for xl, chs, st in spans:
            attrs = ['font-size="%d"' % (st.size if st.size > 0 else 1200), 'font-family="%s"' % font_family(st)]
            if st.style & 1:
                attrs.append('font-weight="bold"')
            if st.style & 2:
                attrs.append('font-style="italic"')
            if st.style & 0x200:
                attrs.append('text-decoration="underline"')
            content = escape(''.join(chs))
            ratio = width_ratio(st)
            if abs(ratio - 1) > 0.05:
                # Set width differing from the point size: horizontal scale around the run's start.
                x0 = xl[0]
                out.append('<text transform="translate(%s %s) scale(%.3g 1)" x="%s" xml:space="preserve" %s>%s</text>' % (
                    fmt(x0), fmt(baseline), ratio, ' '.join(fmt((x - x0) / ratio) for x in xl), ' '.join(attrs), content))
            else:
                parts.append('<tspan x="%s" %s>%s</tspan>' % (' '.join(fmt(x) for x in xl), ' '.join(attrs), content))
        if parts:
            out.append('<text y="%s" xml:space="preserve">%s</text>' % (fmt(baseline), ''.join(parts)))
    return out


def width_ratio(st):
    size = st.size if st.size > 0 else 1200
    if size * 0.2 <= st.width <= size * 5:
        return st.width / float(size)
    return 1.0


def same_style(a, b):
    return (a.font == b.font and a.style == b.style and a.size == b.size and a.mono == b.mono)


def render_text_frame(svg, ob, tokens, page_label, obstacles):
    out = []
    rec = ob.rec
    if rec[26] or rec[28]:
        out.append('<rect x="%d" y="%d" width="%d" height="%d" %s/>' % (
            ob.left, ob.top, ob.right - ob.left, ob.bottom - ob.top, paint_attrs(svg, rec)))
    if not tokens:
        return out
    wrap = ob.type == 4
    height = ob.bottom - ob.top
    placed = None
    mine = [o[:4] for o in obstacles if o[4] != ob.index and not (
        o[0] <= ob.left and o[1] <= ob.top and o[2] >= ob.right and o[3] >= ob.bottom)]
    for factor in (1.0, 0.93, 0.86):
        placed, used = layout_frame(ob, tokens, page_label, factor, wrap, mine)
        if not wrap or used <= height * 1.02:
            break
    out.extend(render_text_lines(ob, placed))
    return out


# ---------------------------------------------------------------------------------------------
# Pages


def master_for(doc, page):
    if page <= 0:
        return None
    bit = (doc.raw[0x4C + (page >> 3)] >> (page & 7)) & 1 if (page >> 3) < 32 else 0
    if not bit:
        return None
    if doc.facing and (page + doc.page_offset) % 2 == 0:
        return -1
    return 0


def frame_tokens(doc):
    """Maps frame object index -> its slice of styled tokens, following linked text flows."""
    result = {}
    for chain in core.text_chains(doc):
        head = chain[0]
        text = head.text or b''
        tokens, bounds = decode_styled(doc, text, head.frame)
        for idx, ob, st, en, nxt in core.frame_ranges(chain, bounds, len(text)):
            result[ob.index] = [t for t in tokens if st <= t[0] < en]
    return result


def runaround_obstacles(doc, page):
    """Bounding boxes (plus standoff) of objects on the page whose text runaround is switched on."""
    covered = set()
    groups = []
    for ob in doc.objs:
        if ob.page == page and ob.type == core.OBJ_GROUP and ob.rec[19] & 7:
            groups.append(ob)
    stack = list(groups)
    while stack:
        g = stack.pop()
        for idx in group_members(g):
            if 0 <= idx < len(doc.objs) and idx not in covered:
                covered.add(idx)
                if doc.objs[idx].type == core.OBJ_GROUP:
                    stack.append(doc.objs[idx])
    boxes = []
    for ob in doc.objs:
        if ob.page != page or not ob.rec[19] & 7 or ob.index in covered:
            continue
        sx, sy = s16(ob.rec, 36), s16(ob.rec, 38)
        boxes.append((ob.left - sx, ob.top - sy, ob.right + sx, ob.bottom + sy, ob.index))
    return boxes


def group_members(ob):
    d = ob.data or b''
    out = []
    for k in range(4, len(d) - 1, 2):
        v = s16(d, k)
        if v < 0:
            break
        out.append(v)
    return out


def render_page(doc, page, tokens_by_frame, stats):
    """Renders all objects visible on page (master objects included for body pages)."""
    svg = Svg()
    master = master_for(doc, page)
    label = core.page_label_for(doc, page)
    obstacles = {page: runaround_obstacles(doc, page)}
    if master is not None:
        obstacles[master] = runaround_obstacles(doc, master)
    body = []
    for ob in doc.objs:
        if ob.page != page and not (master is not None and ob.page == master):
            continue
        t = ob.type
        try:
            if t == core.OBJ_GROUP:
                continue
            elif t in core.TEXT_TYPES:
                parts = render_text_frame(svg, ob, tokens_by_frame.get(ob.index, []), label, obstacles[ob.page])
            elif t == 16:
                parts = render_path_blob(svg, ob)
            elif t == 20:
                parts = render_polyline(svg, ob)
            elif t in (24, 28):
                parts = render_box(svg, ob)
            elif t in (32, 36):
                parts = render_line(svg, ob)
            elif t in (40, 44):
                parts = render_ellipse(svg, ob)
            else:
                key = 'object type %d (%s)' % (t, TYPE_NAMES.get(t, 'unknown'))
                svg.undecoded[key] = svg.undecoded.get(key, 0) + 1
                continue
        except (struct.error, IndexError, ValueError):
            key = 'malformed object type %d' % t
            svg.undecoded[key] = svg.undecoded.get(key, 0) + 1
            continue
        stats[t] = stats.get(t, 0) + 1
        if parts:
            tr = transform_attr(ob.rec)
            if tr or len(parts) > 1:
                body.append('<g%s>%s</g>' % (tr, ''.join(parts)))
            else:
                body.append(parts[0])
    w, h = doc.width, doc.height
    head = ('<?xml version="1.0" encoding="UTF-8"?>\n'
            '<svg xmlns="http://www.w3.org/2000/svg" width="%spt" height="%spt" viewBox="0 0 %d %d">\n'
            '<rect x="0" y="0" width="%d" height="%d" fill="#fff"/>\n' % (
                fmt(w / float(UNITS_PER_PT)), fmt(h / float(UNITS_PER_PT)), w, h, w, h))
    defs = '<defs>%s</defs>\n' % ''.join(svg.defs.values()) if svg.defs else ''
    return head + defs + '\n'.join(body) + '\n</svg>\n', svg.undecoded


def drawing_pages(doc):
    pages = {}
    for ob in doc.objs:
        if ob.frame is None and ob.type != core.OBJ_GROUP:
            pages[ob.page] = pages.get(ob.page, 0) + 1
    return pages


def convert_file(path, rel, dst_root, stats, undecoded):
    with open(path, 'rb') as fh:
        data = fh.read()
    if data[:4] != core.MAGIC:
        return []
    doc = core.Document(data)
    doc.raw = data
    tokens = frame_tokens(doc)
    written = []
    name = os.path.basename(rel)
    for page in sorted(drawing_pages(doc)):
        svg_text, und = render_page(doc, page, tokens, stats)
        for k, v in und.items():
            undecoded[k] = undecoded.get(k, 0) + v
        dst = os.path.join(dst_root, os.path.dirname(rel), core.svg_name(doc, name, page))
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        with open(dst, 'w', encoding='utf-8', newline='\n') as fh:
            fh.write(svg_text)
        written.append(dst)
    return written


def main(argv):
    if len(argv) != 4:
        print('usage: pgs2svg.py SRC_ROOT LIST DST_ROOT', file=sys.stderr)
        return 2
    src_root, list_file, dst_root = argv[1], argv[2], argv[3]
    with open(list_file, encoding='utf-8') as fh:
        names = [ln.strip() for ln in fh if ln.strip()]
    stats, undecoded, total, failed = {}, {}, 0, []
    for rel in names:
        try:
            total += len(convert_file(os.path.join(src_root, rel), rel, dst_root, stats, undecoded))
        except (OSError, ValueError, struct.error, IndexError) as ex:
            failed.append((rel, str(ex)))
    print('svg files written: %d' % total)
    print('objects rendered by type: %s' % ', '.join('%d %s=%d' % (t, TYPE_NAMES.get(t, '?'), n)
                                                     for t, n in sorted(stats.items())))
    print('undecoded: %s' % (undecoded or 'none'))
    for rel, err in failed:
        print('FAILED %s: %s' % (rel, err))
    return 1 if failed else 0


if __name__ == '__main__':
    sys.exit(main(sys.argv))
