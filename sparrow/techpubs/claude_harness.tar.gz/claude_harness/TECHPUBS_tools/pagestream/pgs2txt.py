#!/usr/bin/env python3
# ABOUTME: Extracts plain text from Soft-Logik PageStream 2.x (Atari ST) documents (magic 07231992)
# ABOUTME: and dumps PageStream style sheets (TAGS records or IFF FORM/DTAG) as readable tag lists.
import os
import struct
import sys

MAGIC = b'\x07\x23\x19\x92'
HEADER_SIZE = 0x270
TAG_SIZE = 68
FONT_ENTRY_SIZE = 38
OBJ_SIZE = 40
FRAME_SIZE = 178
BITMAP_HDR = 310

# Argument length of each text command (00 <cmd> <args>), from the length table in PGS2.PRG.
ARGLEN = [0] * 16 + [1] * 6 + [2] + [1] * 9 + [4, 4] + [2] * 14 + [3] * 16 + [8] + [4] * 15

CMD_PARA = 0x01
CMD_TAB = 0x06
CMD_PAGENUM = 0x07
CMD_TAG = 0x10
CMD_FONT = 0x20

OBJ_GROUP = 0
TEXT_TYPES = (4, 8)
OBJ_BITMAP = 12
OBJ_BLOB = (16, 20)
OBJ_LINKED = 48
OBJ_SIMPLE = (24, 28, 32, 36, 40, 44)

# Font ID used by tags named Symbol/Copyright; text in it follows the Adobe Symbol encoding.
SYMBOL_FONT_ID = 0x0100182A
DINGBAT = 'dingbat'

# Zapf Dingbats glyphs commonly used as list bullets.
DINGBAT_CHARS = {'l': '●', 'm': '❍', 'n': '■', 'o': '❏', 'p': '❐', 'q': '❑', 'r': '❒', 's': '▲',
                 't': '▼', 'u': '◆', 'v': '❖', '3': '✓', '4': '✔', '7': '✗', '8': '✘', 'H': '★'}

# PageStream internal character set 0x80-0xFF; names come from the glyph-name table in PGS2.PRG,
# codes without a name there use the program's own Atari approximation table.
PGS_HIGH = (
    '√³≈≡‹›≤≥«»×÷±¬¦⁄'
    '¼½¾¹²³π∞‰µΔ°ºÐÞØ'
    '¤¥¢£ƒ§\'‚„“”·•–—…'
    'ﬁﬂP‡†¶™©®¿¡ßªðþø'
    'ÀÁÂÃÄÅÆÇÈÉÊËÌÍÎÏ'
    'ŁÑÒÓÔÕÖŒŠÙÚÛÜÝŸŽ'
    'àáâãäåæçèéêëìíîï'
    'łñòóôõöœšùúûüýÿž'
)
assert len(PGS_HIGH) == 128

SYMBOL_LOW = (
    ' !∀#∃%&∋()∗+,−./0123456789:;<=>?'
    '≅ΑΒΧΔΕΦΓΗΙϑΚΛΜΝΟΠΘΡΣΤΥςΩΞΨΖ[∴]⊥_'
    '‾αβχδεφγηιϕκλμνοπθρστυϖωξψζ{|}∼'
)
SYMBOL_HIGH = {
    0xA1: 'ϒ', 0xA2: '′', 0xA3: '≤', 0xA4: '⁄', 0xA5: '∞', 0xA6: 'ƒ', 0xA7: '♣', 0xA8: '♦',
    0xA9: '♥', 0xAA: '♠', 0xAB: '↔', 0xAC: '←', 0xAD: '↑', 0xAE: '→', 0xAF: '↓', 0xB0: '°',
    0xB1: '±', 0xB2: '″', 0xB3: '≥', 0xB4: '×', 0xB5: '∝', 0xB6: '∂', 0xB7: '•', 0xB8: '÷',
    0xB9: '≠', 0xBA: '≡', 0xBB: '≈', 0xBC: '…', 0xBD: '|', 0xBE: '—', 0xBF: '↵', 0xC0: 'ℵ',
    0xC1: 'ℑ', 0xC2: 'ℜ', 0xC3: '℘', 0xC4: '⊗', 0xC5: '⊕', 0xC6: '∅', 0xC7: '∩', 0xC8: '∪',
    0xC9: '⊃', 0xCA: '⊇', 0xCB: '⊄', 0xCC: '⊂', 0xCD: '⊆', 0xCE: '∈', 0xCF: '∉', 0xD0: '∠',
    0xD1: '∇', 0xD2: '®', 0xD3: '©', 0xD4: '™', 0xD5: '∏', 0xD6: '√', 0xD7: '⋅', 0xD8: '¬',
    0xD9: '∧', 0xDA: '∨', 0xDB: '⇔', 0xDC: '⇐', 0xDD: '⇑', 0xDE: '⇒', 0xDF: '⇓', 0xE0: '◊',
    0xE1: '〈', 0xE2: '®', 0xE3: '©', 0xE4: '™', 0xE5: '∑', 0xF1: '〉', 0xF2: '∫',
}

STYLE_BITS = [(0, 'bold'), (1, 'italic'), (2, 'shadow'), (3, 'outline'), (4, 'K'), (5, 'light'),
              (6, 'reverse'), (7, 'M'), (8, 'X'), (9, 'underline'), (10, 'U10'), (11, 'U11'),
              (12, 'double strike'), (13, 'strikethrough')]


def u16(d, o):
    return struct.unpack_from('>H', d, o)[0]


def s16(d, o):
    return struct.unpack_from('>h', d, o)[0]


def u32(d, o):
    return struct.unpack_from('>I', d, o)[0]


def s32(d, o):
    return struct.unpack_from('>i', d, o)[0]


def bitmap_size(d, o):
    return u16(d, o + 286) * u16(d, o + 288) * u16(d, o + 284) + u16(d, o + 290) * 8 + BITMAP_HDR


class Obj:
    def __init__(self, index, rec):
        self.index = index
        self.page = s16(rec, 0)
        x1, y1, x2, y2 = struct.unpack_from('>iiii', rec, 2)
        self.left, self.right = min(x1, x2), max(x1, x2)
        self.top, self.bottom = min(y1, y2), max(y1, y2)
        self.type = rec[18]
        self.rec = rec
        self.frame = None
        self.text = None
        self.data = None


class Document:
    def __init__(self, data):
        if data[:4] != MAGIC:
            raise ValueError('not a PageStream 2 document')
        d = data
        self.version = u16(d, 4)
        self.width = u32(d, 8)
        self.height = u32(d, 12)
        nobj = u16(d, 0x18)
        self.page_offset = s16(d, 0x1A)
        self.flags = d[0x1C]
        ntags = u16(d, 0x26C)
        nfonts = u16(d, 0x26E)
        o = HEADER_SIZE
        self.tags = [parse_tag_record(d[o + i * TAG_SIZE:o + (i + 1) * TAG_SIZE]) for i in range(ntags)]
        o += ntags * TAG_SIZE + nfonts * FONT_ENTRY_SIZE
        self.objs = [Obj(i, d[o + i * OBJ_SIZE:o + (i + 1) * OBJ_SIZE]) for i in range(nobj)]
        o += nobj * OBJ_SIZE
        self.bitmaps = 0
        for ob in self.objs:
            t = ob.type
            if t == OBJ_GROUP:
                ob.data = d[o:o + 4 + u32(d, o)]
                o += 4 + u32(d, o)
            elif t in TEXT_TYPES:
                ob.frame = d[o:o + FRAME_SIZE]
                o += FRAME_SIZE
                if s16(ob.frame, 14) < 0:
                    n = u32(d, o)
                    ob.text = d[o + 4:o + 4 + n]
                    o += 4 + n
            elif t == OBJ_BITMAP:
                self.bitmaps += 1
                o += bitmap_size(d, o)
            elif t in OBJ_BLOB:
                ob.data = d[o:o + u32(d, o)]
                o += u32(d, o)
            elif t == OBJ_LINKED:
                hdr = d[o:o + 22 + u32(d, o + 18)]
                o += len(hdr)
                if u32(hdr, 10):
                    o += bitmap_size(d, o)
                if u32(hdr, 14):
                    o += u32(d, o)
            elif t in OBJ_SIMPLE:
                pass
            else:
                raise ValueError('unknown object type %d (object %d)' % (t, ob.index))
            if o > len(d):
                raise ValueError('object %d runs past end of file' % ob.index)
        self.end = o
        self.facing = bool(self.flags & 0x08)

    def next_frame(self, ob):
        return s16(ob.frame, 12)


def parse_tag_record(r):
    return {
        'flags': u32(r, 0),
        'name': r[4:32].split(b'\0')[0].decode('latin-1'),
        'font': u32(r, 32),
        'style': u32(r, 36),
        'size1': s32(r, 40),
        'size2': s32(r, 44),
    }


def map_char(b, font):
    if font == DINGBAT:
        return DINGBAT_CHARS.get(chr(b), chr(b)) if 0x20 <= b < 0x7F else PGS_HIGH[b - 0x80] if b >= 0x80 else ''
    if font == SYMBOL_FONT_ID:
        if 0x20 <= b < 0x7F:
            return SYMBOL_LOW[b - 0x20]
        return SYMBOL_HIGH.get(b, '�')
    if b >= 0x80:
        return PGS_HIGH[b - 0x80]
    if b < 0x20:
        return ''
    return chr(b)


PAGE_MARK = '\ue000'


def decode_flow(doc, text, font):
    """Returns (pieces, boundaries): pieces is a list of (byte offset, string)."""
    pieces = []
    bounds = set()
    k = 0
    n = len(text)
    base_font = font
    while k < n:
        bounds.add(k)
        b = text[k]
        if b == 0 and k + 1 < n:
            c = text[k + 1]
            arg = text[k + 2:k + 2 + (ARGLEN[c] if c < len(ARGLEN) else 0)]
            if c == CMD_PARA:
                pieces.append((k, '\n'))
            elif c == CMD_TAB:
                pieces.append((k, '\t'))
            elif c == CMD_PAGENUM:
                pieces.append((k, PAGE_MARK))
            elif c == CMD_TAG and arg:
                t = arg[0]
                font = base_font
                if 0 < t <= len(doc.tags):
                    tag = doc.tags[t - 1]
                    # The tag name is the only hint that a tag selects a dingbat font.
                    font = DINGBAT if DINGBAT in tag['name'].lower() else tag['font']
            elif c == CMD_FONT and len(arg) == 4:
                base_font = font = u32(arg, 0)
            k += 2 + len(arg)
        else:
            s = map_char(b, font)
            if s:
                pieces.append((k, s))
            k += 1
    bounds.add(n)
    return pieces, bounds


def page_label_for(doc, page):
    return str(page + doc.page_offset) if page > 0 else '#'


def text_chains(doc):
    """Returns lists of linked text frame objects, each starting at the frame that owns the text."""
    chains = []
    for head in doc.objs:
        if head.frame is None or s16(head.frame, 14) >= 0:
            continue
        chain = [head]
        seen = {head.index}
        nxt = doc.next_frame(head)
        while 0 <= nxt < len(doc.objs) and nxt not in seen and doc.objs[nxt].frame is not None:
            chain.append(doc.objs[nxt])
            seen.add(nxt)
            nxt = doc.next_frame(doc.objs[nxt])
        chains.append(chain)
    return chains


def frame_ranges(chain, bounds, text_len):
    """Yields (index, frame, start, end, next valid index) for frames that store a usable text position."""
    starts = [0]
    last = 0
    for ob in chain[1:]:
        off = s32(ob.frame, 30) - 4
        if off in bounds and off >= last:
            starts.append(off)
            last = off
        else:
            starts.append(None)
    for idx, ob in enumerate(chain):
        st = starts[idx]
        if st is None:
            continue
        nxt = idx + 1
        while nxt < len(chain) and starts[nxt] is None:
            nxt += 1
        en = starts[nxt] if nxt < len(chain) else text_len + 1
        yield idx, ob, st, en, nxt


def collect_items(doc, chains, unit_label):
    """Returns (items, notes); items are (frame object, text, chain number, position in chain)."""
    items = []
    notes = []
    for cno, chain in enumerate(chains):
        head = chain[0]
        text = head.text or b''
        pieces, bounds = decode_flow(doc, text, u32(head.frame, 58))
        for idx, ob, st, en, nxt in frame_ranges(chain, bounds, len(text)):
            txt = ''.join(t for off, t in pieces if st <= off < en)
            items.append((ob, txt.replace(PAGE_MARK, page_label_for(doc, ob.page)), cno, idx))
            skipped = chain[idx + 1:nxt]
            if skipped and txt.strip():
                labels = []
                for sk in skipped:
                    lab = unit_label(sk)
                    if lab != unit_label(ob) and lab not in labels:
                        labels.append(lab)
                if labels:
                    notes.append('linked text frames on %s store no text position; their text is '
                                 'included under %s' % ('; '.join(labels), unit_label(ob)))
    return items, notes


def split_by_gaps(items, lo, hi):
    """Groups items whose [lo, hi] extents overlap; groups are ordered along the axis."""
    items = sorted(items, key=lo)
    groups = []
    end = None
    for it in items:
        if groups and lo(it) < end - 144:
            groups[-1].append(it)
            end = max(end, hi(it))
        else:
            groups.append([it])
            end = hi(it)
    return groups


def xy_cut(items, depth=0):
    if len(items) <= 1:
        return list(items)
    if depth < 60:
        bands = split_by_gaps(items, lambda it: it[0].top, lambda it: it[0].bottom)
        if len(bands) > 1:
            return [x for band in bands for x in xy_cut(band, depth + 1)]
        cols = split_by_gaps(items, lambda it: it[0].left, lambda it: it[0].right)
        if len(cols) > 1:
            return [x for col in cols for x in xy_cut(col, depth + 1)]
    return sorted(items, key=lambda it: (it[0].top, it[0].left))


def reading_order(items):
    ordered = xy_cut(items)
    # Frames of one linked flow keep their flow order within the slots the layout gave them.
    slots = {}
    for pos, it in enumerate(ordered):
        slots.setdefault(it[2], []).append(pos)
    result = list(ordered)
    for cno, positions in slots.items():
        if len(positions) > 1:
            frames = sorted((ordered[p] for p in positions), key=lambda it: it[3])
            for p, it in zip(positions, frames):
                result[p] = it
    return result


def clean_text(s):
    lines = [ln.rstrip() for ln in s.replace('\r', '').split('\n')]
    out = []
    blank = 0
    for ln in lines:
        if ln.strip() == '':
            blank += 1
            if blank > 2:
                continue
        else:
            blank = 0
        out.append(ln)
    while out and out[0].strip() == '':
        out.pop(0)
    while out and out[-1].strip() == '':
        out.pop()
    return '\n'.join(out)


def master_name(doc, page):
    if not doc.facing:
        return 'Master page'
    return 'Left master page' if page == -1 else 'Right master page'


def is_booklet(doc, chains):
    """Landscape sheets carrying two page halves whose text flows jump back to earlier sheets."""
    if doc.width <= doc.height:
        return False
    for chain in chains:
        pages = [ob.page for ob in chain]
        if any(b < a for a, b in zip(pages, pages[1:])):
            return True
    return False


def unit_order(doc, chains, units, booklet):
    body = sorted(u for u in units if u[0] > 0)
    masters = sorted(u for u in units if u[0] <= 0)
    if not booklet:
        return body + masters
    seq = []
    for chain in sorted((c for c in chains if len(c) > 1), key=lambda c: (c[0].page, c[0].left)):
        for ob in chain:
            u = (ob.page, half_of(doc, ob))
            if u in units and u not in seq:
                seq.append(u)
    for u in body:
        if u in seq:
            continue
        same = [i for i, v in enumerate(seq) if v[0] == u[0]]
        later = [i for i, v in enumerate(seq) if v[0] > u[0]]
        if same:
            seq.insert(same[-1] + 1, u)
        elif later:
            seq.insert(later[0], u)
        else:
            seq.append(u)
    return seq + masters


def svg_name(doc, name, page):
    """File name of the page rendering written by pgs2svg for this page."""
    if page > 0:
        return '%s.p%03d.svg' % (name, page + doc.page_offset)
    return '%s.m%s.svg' % (name, 'L' if page == -1 else 'R')


def unit_title(doc, u):
    page, half = u
    if page > 0:
        return 'Page %d%s' % (page + doc.page_offset, ', %s half' % half if half else '')
    return '%s (repeated on pages; # = page number)' % master_name(doc, page)


def half_of(doc, ob):
    return 'left' if (ob.left + ob.right) / 2 < doc.width / 2 else 'right'


def convert_document(data, name=''):
    doc = Document(data)
    chains = text_chains(doc)
    booklet = is_booklet(doc, chains)

    def unit(ob):
        return (ob.page, half_of(doc, ob) if booklet and ob.page > 0 else '')

    items, notes = collect_items(doc, chains, lambda ob: unit_title(doc, unit(ob)))

    by_unit = {}
    for it in items:
        by_unit.setdefault(unit(it[0]), []).append(it)
    drawings = {}
    for ob in doc.objs:
        if ob.frame is None and ob.type != OBJ_GROUP:
            u = unit(ob)
            drawings[u] = drawings.get(u, 0) + 1
    out = []
    size = '%.2f x %.2f in' % (doc.width / 7200.0, doc.height / 7200.0)
    extra = ''
    if doc.facing:
        extra += ', facing pages'
    if booklet:
        extra += ', booklet layout: two page halves per sheet, halves listed in text flow order'
    out.append('[PageStream 2 document%s: %s, %d objects%s]' % (
        ' ' + name if name else '', size, len(doc.objs), extra))
    for n in notes:
        out.append('[note: %s]' % n)
    for u in unit_order(doc, chains, set(by_unit) | set(drawings), booklet):
        page, half = u
        parts = []
        for it in reading_order(by_unit.get(u, [])):
            t = clean_text(it[1])
            if t and not (page <= 0 and t == '#'):
                parts.append(t)
        if not parts and not drawings.get(u):
            continue
        out.append('')
        out.append('--- %s ---' % unit_title(doc, u))
        if drawings.get(u):
            out.append('[%d drawing objects, see %s]' % (drawings[u], svg_name(doc, name, page)))
        for t in parts:
            out.append('')
            out.append(t)
    if doc.bitmaps:
        out.append('')
        out.append('[%d embedded bitmap images not extracted]' % doc.bitmaps)
    return '\n'.join(out) + '\n'


def style_names(flags):
    names = [n for bit, n in STYLE_BITS if flags & (1 << bit)]
    rest = flags & ~sum(1 << bit for bit, _ in STYLE_BITS)
    if rest:
        names.append('0x%x' % rest)
    return ', '.join(names) if names else 'normal'


def dump_tags_records(data):
    count = u16(data, 4)
    out = ['[PageStream style sheet, binary TAGS format: %d tags]' % count]
    for i in range(count):
        r = data[6 + i * TAG_SIZE:6 + (i + 1) * TAG_SIZE]
        if len(r) < TAG_SIZE:
            out.append('[truncated record %d]' % (i + 1))
            break
        t = parse_tag_record(r)
        out.append('')
        out.append('Tag %d: %s' % (i + 1, t['name']))
        out.append('  font id:       0x%08X' % t['font'])
        out.append('  style:         %s' % style_names(t['style']))
        out.append('  size:          %.2f pt / %.2f pt' % (t['size1'] / 100.0, t['size2'] / 100.0))
        out.append('  other attributes (raw): %s' % r[48:68].hex(' ', 2))
        out.append('  record flags:  0x%08X' % t['flags'])
    return '\n'.join(out) + '\n'


def read_varint(b, k, signed=False):
    v = 0
    first = True
    neg = False
    while k < len(b):
        c = b[k]
        k += 1
        if first and signed:
            neg = bool(c & 0x40)
            c &= 0xBF
        first = False
        v = (v << 7) | (c & 0x7F)
        if not c & 0x80:
            break
    return (-v if neg else v), k


CTXT_NAMES = {0x1E: 'tag', 0x1F: 'font', 0x20: 'style', 0x21: 'size'}
CTXT_STYLE_LETTERS = {'N': 'normal', 'B': 'bold', 'I': 'italic', 'S': 'shadow', 'O': 'outline',
                      'L': 'light', 'R': 'reverse', 'U': 'underline', '-': 'strikethrough'}


def dump_dtag(data):
    form_len = u32(data, 4)
    out = []
    o = 12
    end = min(len(data), 8 + form_len)
    entries = []
    while o + 8 <= end:
        cid = data[o:o + 4]
        clen = u32(data, o + 4)
        body = data[o + 8:o + 8 + clen]
        if cid == b'DTAG':
            k = 0
            while k + 4 <= len(body):
                elen = u16(body, k)
                ent = body[k + 2:k + 2 + elen]
                k += 2 + elen + (elen & 1)
                if elen == 0:
                    break
                nul = ent.find(b'\0', 2)
                name = ent[2:nul].decode('latin-1')
                attrs = []
                j = nul + 1
                while j + 3 <= len(ent) and ent[j] == 0:
                    cmd = ent[j + 1]
                    ln, j2 = read_varint(ent, j + 3)
                    arg = ent[j2:j2 + ln]
                    j = j2 + ln
                    if cmd == 0x1F:
                        attrs.append(('font', arg.decode('latin-1')))
                    elif cmd == 0x20:
                        letters = arg.decode('latin-1')
                        attrs.append(('style', ', '.join(CTXT_STYLE_LETTERS.get(c, c) for c in letters)))
                    elif cmd == 0x21:
                        vals = []
                        p = 0
                        while p < len(arg):
                            v, p = read_varint(arg, p)
                            vals.append('%.2f pt' % (v / 100.0))
                        attrs.append(('size', ' / '.join(vals)))
                    else:
                        vals = []
                        p = 0
                        while p < len(arg):
                            v, p = read_varint(arg, p, signed=True)
                            vals.append(str(v))
                        attrs.append(('attr 0x%02X' % cmd, ', '.join(vals)))
                entries.append((name, attrs))
        o += 8 + clen + (clen & 1)
    out.append('[PageStream style sheet, IFF FORM DTAG format: %d tags]' % len(entries))
    for i, (name, attrs) in enumerate(entries):
        out.append('')
        out.append('Tag %d: %s' % (i + 1, name))
        for k, v in attrs:
            out.append('  %-14s %s' % (k + ':', v))
    return '\n'.join(out) + '\n'


def convert_bytes(data, name=''):
    if data[:4] == MAGIC:
        return convert_document(data, name)
    if data[:4] == b'TAGS':
        return dump_tags_records(data)
    if data[:4] == b'FORM' and data[8:12] == b'DTAG':
        return dump_dtag(data)
    raise ValueError('unrecognised PageStream file')


def main(argv):
    if len(argv) >= 2 and argv[1] == '--batch':
        src_root, list_file, dst_root = argv[2], argv[3], argv[4]
        ok = 0
        failed = []
        with open(list_file, encoding='utf-8') as fh:
            names = [ln.strip() for ln in fh if ln.strip()]
        for rel in names:
            try:
                with open(os.path.join(src_root, rel), 'rb') as fh:
                    data = fh.read()
                txt = convert_bytes(data, os.path.basename(rel))
                dst = os.path.join(dst_root, rel + '.txt')
                os.makedirs(os.path.dirname(dst), exist_ok=True)
                with open(dst, 'w', encoding='utf-8', newline='\n') as fh:
                    fh.write(txt)
                ok += 1
            except (OSError, ValueError, struct.error, IndexError) as ex:
                failed.append((rel, str(ex)))
        print('converted %d/%d' % (ok, len(names)))
        for rel, err in failed:
            print('FAILED %s: %s' % (rel, err))
        return 1 if failed else 0
    if len(argv) != 2:
        print('usage: pgs2txt.py FILE  |  pgs2txt.py --batch SRC_ROOT LIST DST_ROOT', file=sys.stderr)
        return 2
    try:
        with open(argv[1], 'rb') as fh:
            sys.stdout.write(convert_bytes(fh.read(), os.path.basename(argv[1])))
    except (OSError, ValueError, struct.error, IndexError) as ex:
        print('%s: %s' % (argv[1], ex), file=sys.stderr)
        return 1
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv))
