# ABOUTME: Converts Microsoft Word 1.x binary documents (magic FE 32 00 00, Atari ST "Microsoft Write" flavour) to UTF-8 plain text.
# ABOUTME: Walks the text stream with the paragraph/character property pages; expands tabs to spaces using the stored tab stops.
import argparse
import struct
import sys

PAGE = 0x80
TEXT_START = 0x80

# Atari ST character set, 0x80-0xFF (matches unicode.org VENDORS/MISC/ATARIST.TXT)
ATARI_HIGH = (
    "ÇüéâäàåçêëèïîìÄÅ"
    "ÉæÆôöòûùÿÖÜ¢£¥ßƒ"
    "áíóúñÑªº¿⌐¬½¼¡«»"
    "ãõØøœŒÀÃÕ¨´†¶©®™"
    "ĳĲאבגדהוזחטיכלמנ"
    "סעפצקרשתןךםףץ§∧∞"
    "αβΓπΣσµτΦΘΩδ∮φ∈∩"
    "≡±≥≤⌠⌡÷≈°∙·√ⁿ²³¯"
)
assert len(ATARI_HIGH) == 128

DEFAULT_TAB_TWIPS = 720


class FormatError(Exception):
    pass


def u16(d, o):
    return struct.unpack_from(">H", d, o)[0]


def s16(d, o):
    return struct.unpack_from(">h", d, o)[0]


def u32(d, o):
    return struct.unpack_from(">I", d, o)[0]


def parse_header(d):
    if len(d) < PAGE or d[0:4] != b"\xfe\x32\x00\x00":
        raise FormatError("not a Word 1.x file (magic FE 32 00 00 missing)")
    eot = u32(d, 0x0E)
    limits = [(eot + PAGE - 1) // PAGE] + [u16(d, 0x12 + 2 * i) for i in range(6)]
    size_a, size_b = u32(d, 0x40), u32(d, 0x44)
    if eot < TEXT_START or eot > len(d):
        raise FormatError("text end 0x%x outside file" % eot)
    if any(limits[i] > limits[i + 1] for i in range(6)) or limits[6] * PAGE > len(d):
        raise FormatError("zone page limits inconsistent: %r" % limits)
    warn = []
    if size_a != size_b or TEXT_START + size_a != eot:
        warn.append("text size fields 0x%x/0x%x disagree with text end 0x%x" % (size_a, size_b, eot))
    return eot, limits, warn


def read_fkps(d, first, last):
    """Returns [(fc_first, fc_lim, prop_bytes_or_None)] from 128-byte property pages."""
    runs = []
    for pn in range(first, last):
        pg = d[pn * PAGE:(pn + 1) * PAGE]
        fc = u32(pg, 0)
        n = pg[127]
        if 4 + 6 * n > 127:
            raise FormatError("property page %d has bad count %d" % (pn, n))
        for i in range(n):
            lim = u32(pg, 4 + 6 * i)
            bprop = u16(pg, 8 + 6 * i)
            prop = None
            if bprop != 0xFFFF:
                cch = pg[4 + bprop]
                prop = bytes(pg[5 + bprop:5 + bprop + cch])
            runs.append((fc, lim, prop))
            fc = lim
    return runs


def parse_pap(prop):
    p = (prop or b"") + bytes(max(0, 26 - len(prop or b"")))
    pap = {
        "jc": p[1] >> 6,
        "right": s16(p, 4),
        "left": s16(p, 6),
        "first": s16(p, 8),
        "hf": p[16],
        "tabs": [],
    }
    raw = prop or b""
    i = 22
    while i + 4 <= len(raw):
        pos, fl = s16(raw, i), raw[i + 2]
        if pos == 0 and fl == 0:
            break
        pap["tabs"].append((pos, (fl >> 5) & 3, " .-_"[(fl >> 2) & 3]))
        i += 4
    pap["tabs"].sort()
    return pap


def parse_chp(prop):
    p = (prop or b"") + bytes(6)
    return {
        "caps": ((p[3] >> 2) & 3) == 3,
        "special": bool(p[3] & 0x02),
    }


def find_run(runs, fc, hint):
    """Linear scan helper; runs are sorted and contiguous."""
    i = hint
    while i < len(runs) and runs[i][1] <= fc:
        i += 1
    return i


def hf_label(hf):
    footer = bool(hf & 0x10)
    name = "Footer" if footer else "Header"
    odd_bit, even_bit = (0x40, 0x20) if footer else (0x20, 0x40)
    pages = []
    if hf & odd_bit:
        pages.append("odd")
    if hf & even_bit:
        pages.append("even")
    if hf & 0x80:
        pages.append("first")
    if len(pages) == 3:
        return name
    return "%s (%s pages)" % (name, "/".join(pages) if pages else "no")


class Layout:
    """Lays out one line of a paragraph with spaces, using its tab stops."""

    def __init__(self, pitch, keep_tabs):
        self.pitch = pitch
        self.keep_tabs = keep_tabs

    def col(self, twips):
        return max(0, int(round(twips / self.pitch)))

    def render_line(self, text, pap, first_line):
        if self.keep_tabs:
            return text
        start_twips = pap["left"] + pap["first"] if first_line else pap["left"]
        indent = " " * self.col(start_twips) if text.strip() else ""
        if "\t" not in text:
            return indent + text
        stops = list(pap["tabs"])
        if first_line and pap["first"] < 0 and pap["left"] > 0:
            if not any(t[0] == pap["left"] for t in stops):
                stops.append((pap["left"], 0, " "))
                stops.sort()
        base = self.col(start_twips)
        parts = text.split("\t")
        out = parts[0]
        for seg in parts[1:]:
            cur = base + len(out)
            stop = None
            for pos, align, leader in stops:
                if self.col(pos) > cur:
                    stop = (self.col(pos), align, leader)
                    break
            if stop is None:
                last = max([start_twips] + [t[0] for t in stops])
                twips = (last // DEFAULT_TAB_TWIPS + 1) * DEFAULT_TAB_TWIPS
                while self.col(twips) <= cur:
                    twips += DEFAULT_TAB_TWIPS
                stop = (self.col(twips), 0, " ")
            scol, align, leader = stop
            if align == 1:
                target = scol - len(seg) // 2
            elif align == 2:
                target = scol - len(seg)
            elif align == 3:
                dot = seg.find(".")
                target = scol - (dot if dot >= 0 else len(seg))
            else:
                target = scol
            if target <= cur:
                target = cur + 1
            fill = target - cur
            if leader != " " and fill > 2:
                out += " " + leader * (fill - 2) + " "
            else:
                out += " " * fill
            out += seg
        return indent + out


def convert(d, pitch=120, keep_tabs=False):
    eot, limits, warns = parse_header(d)
    chars = read_fkps(d, limits[0], limits[1])
    paras = read_fkps(d, limits[1], limits[2])
    if limits[2] != limits[3]:
        warns.append("footnote table present; footnote text is emitted where it is stored")
    layout = Layout(pitch, keep_tabs)

    # Paragraph ranges clipped to the text stream; gaps get default properties.
    ranges = []
    pos = TEXT_START
    for a, b, prop in paras:
        a, b = max(a, TEXT_START), min(b, eot)
        if b <= pos:
            continue
        if a > pos:
            ranges.append((pos, a, None))
        ranges.append((max(a, pos), b, prop))
        pos = b
    if pos < eot:
        ranges.append((pos, eot, None))
        warns.append("paragraph properties missing for 0x%x-0x%x" % (pos, eot))

    out_lines = []
    unknown = {}
    ci = 0
    for a, b, prop in ranges:
        pap = parse_pap(prop)
        lines = [""]
        fc = a
        while fc < b:
            ci = find_run(chars, fc, ci)
            chp = parse_chp(chars[ci][2] if ci < len(chars) else None)
            c = d[fc]
            if c == 0x0D and fc + 1 < b and d[fc + 1] == 0x0A:
                fc += 1
                c = 0x0A
            if c in (0x0A, 0x0B, 0x0D):
                lines.append("")
            elif c == 0x0C:
                if lines[-1] == "":
                    lines[-1] = "\f"
                else:
                    lines.append("\f")
                lines.append("")
            elif c == 0x09:
                lines[-1] += "\t"
            elif c == 0x1F:
                pass
            elif c == 0x01 and chp["special"]:
                lines[-1] += "#"
            elif c < 0x20 or c == 0x7F:
                unknown[c] = unknown.get(c, 0) + 1
            else:
                ch = chr(c) if c < 0x80 else ATARI_HIGH[c - 0x80]
                lines[-1] += ch.upper() if chp["caps"] else ch
            fc += 1
        if lines[-1] == "" and len(lines) > 1:
            lines.pop()
        rendered = []
        for i, ln in enumerate(lines):
            if ln == "\f":
                rendered.append(ln)
            else:
                rendered.append(layout.render_line(ln, pap, i == 0).rstrip())
        if pap["hf"] & 0xF0:
            body = " / ".join(r.strip() for r in rendered if r.strip() and r != "\f")
            rendered = ["[%s: %s]" % (hf_label(pap["hf"]), body)]
        out_lines.extend(rendered)

    while out_lines and out_lines[-1] in ("", "\f"):
        out_lines.pop()
    for c, n in sorted(unknown.items()):
        warns.append("dropped %d unhandled control byte(s) 0x%02x" % (n, c))
    return "\n".join(out_lines) + "\n", warns


def dump(d):
    eot, limits, warns = parse_header(d)
    print("text 0x80-0x%x zones(pages)=%r" % (eot, limits))
    for a, b, prop in read_fkps(d, limits[1], limits[2]):
        pap = parse_pap(prop)
        print("%5x-%5x jc%d L%d F%d R%d hf%02x tabs=%s | %r" % (
            a, b, pap["jc"], pap["left"], pap["first"], pap["right"], pap["hf"],
            ",".join("%d%s%s" % (p, "LCRD"[al], ld.strip()) for p, al, ld in pap["tabs"]),
            d[a:min(b, eot)][:80]))


def main():
    ap = argparse.ArgumentParser(description="Convert a Word 1.x (FE 32 00 00) document to UTF-8 plain text.")
    ap.add_argument("input")
    ap.add_argument("output", nargs="?", help="default: stdout")
    ap.add_argument("--pitch", type=int, default=120, help="twips per output column (default 120 = 12 cpi)")
    ap.add_argument("--keep-tabs", action="store_true", help="leave tab characters instead of expanding them")
    ap.add_argument("--dump", action="store_true", help="print paragraph properties instead of text")
    args = ap.parse_args()
    d = open(args.input, "rb").read()
    try:
        if args.dump:
            dump(d)
            return 0
        text, warns = convert(d, args.pitch, args.keep_tabs)
    except FormatError as e:
        print("%s: %s" % (args.input, e), file=sys.stderr)
        return 1
    for w in warns:
        print("%s: warning: %s" % (args.input, w), file=sys.stderr)
    if args.output:
        with open(args.output, "w", encoding="utf-8", newline="\n") as f:
            f.write(text)
    else:
        sys.stdout.write(text)
    return 0


if __name__ == "__main__":
    sys.exit(main())
