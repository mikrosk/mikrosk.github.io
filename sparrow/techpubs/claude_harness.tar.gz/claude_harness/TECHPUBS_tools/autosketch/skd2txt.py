# ABOUTME: Decodes AutoSketch (DOS, "v2" format) .SKD/.BAK drawing databases into a readable text listing and an SVG render.
# ABOUTME: Usage: skd2txt.py SRC_ROOT LIST_FILE DST_ROOT  (or skd2txt.py FILE.SKD OUT_PREFIX)
import html
import math
import os
import struct
import sys

SIGNATURE = b"AutoSketch drawing database\r\n\x1a"
# Size of the fixed header observed in all samples; there is no length field for it.
HEADER_SIZE = 0xC8B
PREVIEW_OFF, PREVIEW_W, PREVIEW_H = 0x1E9, 80, 64
SVG_SCALE = 200

T_LINE, T_POLY, T_MARK5, T_TEXT, T_GROUP, T_FILL = 2, 4, 5, 7, 10, 17
TYPE_NAMES = {T_LINE: "LINE", T_POLY: "POLYLINE", T_MARK5: "TYPE5",
              T_TEXT: "TEXT", T_GROUP: "GROUP", T_FILL: "FILL"}
JUSTIFY = {1: "left", 4: "center"}
COLORS = {0: "#000000", 1: "#ff0000", 2: "#c0a000", 3: "#00a000", 4: "#00a0a0",
          5: "#0000ff", 6: "#c000c0", 7: "#000000"}


def f32(d, o):
    return struct.unpack_from("<f", d, o)[0]


def f64(d, o):
    return struct.unpack_from("<d", d, o)[0]


def u16(d, o):
    return struct.unpack_from("<H", d, o)[0]


def u32(d, o):
    return struct.unpack_from("<I", d, o)[0]


def cstr(b):
    return b.split(b"\0", 1)[0].decode("latin-1")


def points(d, o, n):
    return [struct.unpack_from("<2f", d, o + 8 * i) for i in range(n)]


def parse_header(d):
    h = {
        "entity_count": u32(d, 0x23),
        "extents": struct.unpack_from("<4f", d, 0x2B),
        "limits": struct.unpack_from("<4f", d, 0x3B),
        "f_0x4b": f32(d, 0x4B),
        "cur_layer": u16(d, 0x4F),
        "cur_color": u16(d, 0x51),
        "text_height": f64(d, 0x5F),
        "text_d67": f64(d, 0x67),
        "text_d6f": f64(d, 0x6F),
        "f_0x7f": struct.unpack_from("<2f", d, 0x7F),
        "d_0x99": struct.unpack_from("<2d", d, 0x99),
        "d_0x127": [f64(d, 0x127 + 8 * i) for i in range(3)],
        "d_0x14e": f64(d, 0x14E),
        "font": cstr(d[0x194:0x1A0]),
        "format_marker": cstr(d[0x1D9:0x1DC]),
        "pattern_index": u16(d, 0xC15),
        "pattern": cstr(d[0xC29:0xC32]),
    }
    return h


def parse_record(d, p):
    t = d[p + 2]
    r = {"off": p, "type": t, "handle": u16(d, p),
         "bbox": struct.unpack_from("<4f", d, p + 3),
         "layer": d[p + 19], "color": d[p + 20], "b21": d[p + 21], "b22": d[p + 22]}
    if t == T_POLY:
        if u16(d, p + 33) != 1:
            raise ValueError("polyline with %d vertex blocks at 0x%X" % (u16(d, p + 33), p))
        n = u16(d, p + 43)
        r.update(closed=u16(d, p + 23), length=f32(d, p + 25), pts=points(d, p + 71, n))
        # 16 bytes before the vertices and 63 bytes after them hold stale memory.
        r["size"] = 71 + 8 * n + 63
    elif t == T_LINE:
        x0, y0, x1, y1 = struct.unpack_from("<4f", d, p + 23)
        r.update(pts=[(x0, y0), (x1, y1)], size=39)
    elif t == T_TEXT:
        nl, sl = u16(d, p + 53), u16(d, p + 55)
        lines_off = p + 128
        str_off = lines_off + 26 * nl
        strings = [s.decode("latin-1") for s in d[str_off:str_off + sl].split(b"\0")[:nl]]
        lines = []
        for i in range(nl):
            x0, y0, x1, y1 = struct.unpack_from("<4f", d, lines_off + 26 * i)
            lines.append({"base": (x0, y0, x1, y1), "len": u16(d, lines_off + 26 * i + 16),
                          "text": strings[i] if i < len(strings) else ""})
        r.update(ins=struct.unpack_from("<2f", d, p + 23), height=f32(d, p + 31),
                 params=struct.unpack_from("<3f", d, p + 35), justify=u16(d, p + 51),
                 font=cstr(d[p + 57:p + 124]), lines=lines, size=128 + 26 * nl + sl)
    elif t == T_GROUP:
        r.update(count=u16(d, p + 23), size=29)
    elif t == T_MARK5:
        r.update(size=23)
    elif t == T_FILL:
        n = u16(d, p + 48)
        r.update(loops=u16(d, p + 23), pattern=cstr(d[p + 31:p + 40]),
                 pts=points(d, p + 76, n), size=76 + 8 * n + 44)
    else:
        raise ValueError("unknown record type %d at 0x%X" % (t, p))
    return r


def parse(path):
    d = open(path, "rb").read()
    if not d.startswith(SIGNATURE):
        raise ValueError("not an AutoSketch drawing database")
    hdr = parse_header(d)
    recs, p, err = [], HEADER_SIZE, None
    while p + 23 <= len(d):
        try:
            r = parse_record(d, p)
        except ValueError as e:
            err = str(e)
            break
        recs.append(r)
        p += r["size"]
    # Nest group members: a GROUP record is followed by its members.
    top, i = [], 0
    while i < len(recs):
        r = recs[i]
        i += 1
        if r["type"] == T_GROUP:
            r["children"] = recs[i:i + r["count"]]
            i += r["count"]
        top.append(r)
    return d, hdr, recs, top, p, err


def preview_rows(d):
    rows = []
    for y in range(PREVIEW_H):
        row = d[PREVIEW_OFF + y * PREVIEW_W // 2:PREVIEW_OFF + (y + 1) * PREVIEW_W // 2]
        rows.append("".join("#" if (b >> s) & 15 else "." for b in row for s in (4, 0)))
    while rows and "#" not in rows[-1]:
        rows.pop()
    return rows


def fmt_pt(p):
    return "(%.4f, %.4f)" % p


def fmt_bbox(b):
    return "(%.4f, %.4f)-(%.4f, %.4f)" % b


def describe(r, ind):
    s = ind
    head = "0x%05X %-8s layer %d color %d flags %02x/%02x" % (
        r["off"], TYPE_NAMES[r["type"]], r["layer"], r["color"], r["b21"], r["b22"])
    out = []
    t = r["type"]
    if t == T_POLY:
        out.append(s + head + " %s n=%d length=%.4f" % (
            "closed" if r["closed"] else "open", len(r["pts"]), r["length"]))
        for i in range(0, len(r["pts"]), 4):
            out.append(s + "    " + " ".join(fmt_pt(q) for q in r["pts"][i:i + 4]))
    elif t == T_LINE:
        out.append(s + head + " %s -> %s" % (fmt_pt(r["pts"][0]), fmt_pt(r["pts"][1])))
    elif t == T_TEXT:
        out.append(s + head + " at %s height %.4f just %s font %s p35/39/43=%g/%g/%g" % (
            fmt_pt(r["ins"]), r["height"], JUSTIFY.get(r["justify"], r["justify"]),
            r["font"], *r["params"]))
        for ln in r["lines"]:
            out.append(s + "    %-28s baseline %s-%s" % (
                '"%s"' % ln["text"], fmt_pt(ln["base"][:2]), fmt_pt(ln["base"][2:])))
    elif t == T_FILL:
        out.append(s + head + " pattern %s loops %d n=%d" % (r["pattern"], r["loops"], len(r["pts"])))
        out.append(s + "    " + " ".join(fmt_pt(q) for q in r["pts"]))
    elif t == T_GROUP:
        out.append(s + head + " members=%d extents %s" % (r["count"], fmt_bbox(r["bbox"])))
        for c in r.get("children", []):
            out.extend(describe(c, ind + "    "))
    elif t == T_MARK5:
        out.append(s + head + " (23-byte record, extents %s, purpose unknown)" % fmt_bbox(r["bbox"]))
    return out


def signature(r):
    if r["type"] == T_TEXT:
        return ("TEXT", tuple(l["text"] for l in r["lines"]), round(r["ins"][0], 4), round(r["ins"][1], 4))
    if "pts" in r:
        return (TYPE_NAMES[r["type"]], tuple((round(x, 4), round(y, 4)) for x, y in r["pts"]))
    return (TYPE_NAMES[r["type"]], tuple(round(v, 4) for v in r["bbox"]))


def sibling_diff(path, recs):
    base, ext = os.path.splitext(path)
    other = None
    for e in ((".BAK", ".bak") if ext.upper() == ".SKD" else (".SKD", ".skd")):
        if os.path.exists(base + e):
            other = base + e
            break
    if not other:
        return []
    try:
        _, ohdr, orecs, _, _, _ = parse(other)
    except ValueError:
        return []
    mine = [signature(r) for r in recs]
    theirs = [signature(r) for r in orecs]
    only_mine = [s for s in mine if s not in theirs]
    only_theirs = [s for s in theirs if s not in mine]
    out = ["", "== Compared with %s ==" % os.path.basename(other),
           "records here: %d, there: %d; only here: %d, only there: %d" % (
               len(mine), len(theirs), len(only_mine), len(only_theirs))]
    for label, lst in (("only here", only_mine), ("only there", only_theirs)):
        for s in lst:
            out.append("  %s: %s %s" % (label, s[0], " ".join(
                "(%.4f, %.4f)" % q if isinstance(q, tuple) else str(q) for q in s[1])))
    return out


def write_txt(path, out_path, rel, d, hdr, recs, top, end, err):
    counts = {}
    for r in recs:
        counts[TYPE_NAMES[r["type"]]] = counts.get(TYPE_NAMES[r["type"]], 0) + 1
    layers = sorted({r["layer"] for r in recs})
    colors = sorted({r["color"] for r in recs})
    L = []
    L.append("AutoSketch drawing database: %s" % rel)
    L.append("File size %d bytes; SKD format marker \"%s\" at 0x1D9; fixed header 0x%X bytes" % (
        len(d), hdr["format_marker"], HEADER_SIZE))
    L.append("")
    L.append("== Header ==")
    L.append("entity count field (0x23):   %d" % hdr["entity_count"])
    L.append("drawing extents (0x2B):      %s" % fmt_bbox(hdr["extents"]))
    L.append("limits (0x3B):               %s" % fmt_bbox(hdr["limits"]))
    L.append("units:                       no units field identified")
    L.append("current layer / color:       %d / %d" % (hdr["cur_layer"], hdr["cur_color"]))
    L.append("text height (0x5F):          %g   (then %g, %g)" % (
        hdr["text_height"], hdr["text_d67"], hdr["text_d6f"]))
    L.append("current font (0x194):        %s" % hdr["font"])
    L.append("current fill pattern:        %s (index %d)" % (hdr["pattern"], hdr["pattern_index"]))
    L.append("unidentified values:         f32@0x4B=%g f32@0x7F=%g,%g d@0x99=%g,%g d@0x127=%s d@0x14E=%g" % (
        hdr["f_0x4b"], hdr["f_0x7f"][0], hdr["f_0x7f"][1], hdr["d_0x99"][0], hdr["d_0x99"][1],
        ",".join("%g" % v for v in hdr["d_0x127"]), hdr["d_0x14e"]))
    L.append("preview bitmap (0x1E9):      %dx%d, 4 bits per pixel" % (PREVIEW_W, PREVIEW_H))
    L.append("")
    L.append("== Summary ==")
    L.append("records: %d (%s)" % (len(recs), ", ".join("%s %d" % kv for kv in sorted(counts.items()))))
    L.append("top-level entities: %d" % len(top))
    L.append("layers used: %s; colors used: %s" % (" ".join(map(str, layers)), " ".join(map(str, colors))))
    tail = d[end:]
    L.append("records end at 0x%X; trailing bytes: %s" % (end, tail.hex(" ") if len(tail) <= 16 else "%d" % len(tail)))
    if err:
        L.append("PARSE STOPPED: %s" % err)
    L.append("")
    L.append("== Text strings (file order) ==")
    for r in recs:
        if r["type"] == T_TEXT:
            L.append("  " + " / ".join(l["text"] for l in r["lines"]))
    L.append("")
    L.append("== Entities ==")
    L.append("offset  type     layer color flags(b21/b22) details; coordinates as stored")
    for r in top:
        L.extend(describe(r, ""))
    L.extend(sibling_diff(path, recs))
    L.append("")
    L.append("== Preview bitmap (# = set pixel) ==")
    L.extend(preview_rows(d))
    with open(out_path, "w", encoding="utf-8", newline="\n") as f:
        f.write("\n".join(L) + "\n")


def svg_items(r, out, k):
    col = COLORS.get(r["color"], "#000000")
    t = r["type"]
    if t in (T_POLY, T_LINE, T_FILL):
        pts = " ".join("%.2f,%.2f" % (x * k, -y * k) for x, y in r["pts"])
        if t == T_FILL:
            fill = col if r["pattern"] == "SOLID" else "#bbbbbb"
            out.append('<polygon points="%s" fill="%s" stroke="%s"><title>%s</title></polygon>' % (
                pts, fill, col, html.escape(r["pattern"])))
        else:
            out.append('<polyline points="%s" fill="none" stroke="%s"/>' % (pts, col))
    elif t == T_TEXT:
        for ln in r["lines"]:
            x0, y0, x1, y1 = (v * k for v in ln["base"])
            width = math.hypot(x1 - x0, y1 - y0)
            ang = -math.degrees(math.atan2(y1 - y0, x1 - x0))
            rot = ' transform="rotate(%.3f %.2f %.2f)"' % (ang, x0, -y0) if abs(ang) > 1e-3 else ""
            fit = ' textLength="%.2f" lengthAdjust="spacingAndGlyphs"' % width if width > 0 else ""
            out.append('<text x="%.2f" y="%.2f" font-size="%.2f" fill="%s"%s%s>%s</text>' % (
                x0, -y0, r["height"] * k / 0.72, col, fit, rot, html.escape(ln["text"])))
    elif t == T_GROUP:
        out.append('<g class="group">')
        for c in r.get("children", []):
            svg_items(c, out, k)
        out.append("</g>")


def write_svg(path, hdr, recs, top):
    xs, ys = [], []
    for r in recs:
        if r["type"] in (T_POLY, T_LINE, T_FILL, T_TEXT, T_GROUP):
            xs += [r["bbox"][0], r["bbox"][2]]
            ys += [r["bbox"][1], r["bbox"][3]]
    if not xs:
        xs, ys = [0, 1], [0, 1]
    m = 0.1
    x0, x1, y0, y1 = min(xs) - m, max(xs) + m, min(ys) - m, max(ys) + m
    # SVG units per drawing unit; y axis is flipped.
    k = SVG_SCALE
    w, h = (x1 - x0) * k, (y1 - y0) * k
    out = ['<?xml version="1.0" encoding="UTF-8"?>',
           '<svg xmlns="http://www.w3.org/2000/svg" width="%.0f" height="%.0f" viewBox="%.2f %.2f %.2f %.2f">' % (
               w, h, x0 * k, -y1 * k, w, h),
           "<desc>%d SVG units = 1 drawing unit; drawing y axis points up</desc>" % k,
           '<rect x="%.2f" y="%.2f" width="%.2f" height="%.2f" fill="#ffffff"/>' % (x0 * k, -y1 * k, w, h),
           '<g stroke-width="1.2" stroke-linejoin="round" stroke-linecap="round" font-family="Helvetica, Arial, sans-serif">']
    for r in top:
        svg_items(r, out, k)
    out += ["</g>", "</svg>"]
    with open(path, "w", encoding="utf-8", newline="\n") as f:
        f.write("\n".join(out) + "\n")


def convert(src, prefix, rel):
    d, hdr, recs, top, end, err = parse(src)
    os.makedirs(os.path.dirname(prefix) or ".", exist_ok=True)
    write_txt(src, prefix + ".txt", rel, d, hdr, recs, top, end, err)
    write_svg(prefix + ".svg", hdr, recs, top)
    return len(recs), err


def main(argv):
    if len(argv) == 4:
        src_root, lst, dst_root = argv[1:]
        for rel in open(lst, encoding="utf-8").read().split("\n"):
            rel = rel.strip()
            if not rel:
                continue
            n, err = convert(os.path.join(src_root, rel), os.path.join(dst_root, rel), rel)
            print("%s: %d records%s" % (rel, n, "; " + err if err else ""))
    elif len(argv) == 3:
        n, err = convert(argv[1], argv[2], argv[1])
        print("%s: %d records%s" % (argv[1], n, "; " + err if err else ""))
    else:
        sys.exit("usage: skd2txt.py SRC_ROOT LIST_FILE DST_ROOT | skd2txt.py FILE OUT_PREFIX")


if __name__ == "__main__":
    main(sys.argv)
