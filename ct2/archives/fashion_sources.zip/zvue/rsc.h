/* Indice du ressource pour RSC */

#define MENU     0   /* Arbre menu */
#define M_INFO   7   /* STRING dans l'arbre MENU */
#define M_QUIT   16  /* STRING dans l'arbre MENU */

#define INFO     1   /* Formulaire/Dialogue */

#define WAIT     2   /* Formulaire/Dialogue */
#define WAIT_BOX 1   /* BOX dans l'arbre WAIT */
#define WAIT_BAR 2   /* BOX dans l'arbre WAIT */
#define WAIT_TXT1 3   /* TEXT dans l'arbre WAIT */
#define WAIT_TXT2 4   /* TEXT dans l'arbre WAIT */
#define WAIT_TXT3 5   /* TEXT dans l'arbre WAIT */

#define Z_LIB_INFO 3   /* Formulaire/Dialogue */

#define EDIT     4   /* Formulaire/Dialogue */
#define EDIT_EDIT 1   /* FTEXT dans l'arbre EDIT */
