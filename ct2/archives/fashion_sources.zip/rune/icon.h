/* Indice du ressource pour ICON */

#define BIG_ICON 0   /* Formulaire/Dialogue */

#define SMALL_ICON 1   /* Formulaire/Dialogue */
