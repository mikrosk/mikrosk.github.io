#define ARBRE1 000	/*  */
#define OBJET1_0 000	/*  */
#define OBJET1_2 002	/*  */
#define ARBRE2 001	/*  */
#define OBJET2_0 000	/*  */
