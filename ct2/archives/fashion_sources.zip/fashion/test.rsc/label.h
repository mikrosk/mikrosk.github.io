/* Indice du ressource pour LABEL */

#define ARBRE1   0   /* Formulaire/Dialogue */
#define OBJET1_0 0   /* BOX dans l'arbre ARBRE1 */
#define OBJET1_2 2   /* BOX dans l'arbre ARBRE1 */

#define ARBRE2   1   /* Formulaire/Dialogue */
#define OBJET2_0 0   /* BOX dans l'arbre ARBRE2 */
