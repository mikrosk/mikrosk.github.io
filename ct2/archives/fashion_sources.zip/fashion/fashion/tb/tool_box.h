/* Indice du ressource pour TOOL_BOX */

#define TOOL_BOX 0   /* Formulaire/Dialogue */
#define DRAGING_BOX 0   /* BOX dans l'arbre TOOL_BOX */
