/* C_ASM.C
   Demoprogramm zum Aufruf von Assemblerroutinen aus
   C-Programmen und umgekehrt
*/

#include <stdio.h>

void SumMulFac( int x, int y );    /* definiert in ASM.S */

int temp = 0x10;   /*
                    * Diese Variable dient zur Demonstration des neuen
                    * BUG-68K Kommandos 'watch'.
                    * Starten Sie den Debugger, laden Sie das Programm
                    * 'MASDEMO.TOS' und starten Sie es durch Eingabe
                    * der Befehlszeile "J@temp.w<>$10".
                    */

void fakult( int x )
{
    double y;
    int i;

    printf( "Die Fakult�t von %d ist ", x );
    if( x < 0 )
    {
        puts( "nicht definiert" );
    }
    else
    {
        for( i = 2, y = 1.0; i <= x; i++ )
            y *= i;

        printf( "%lg\n", y );
    }
}

int main( void )
{
    int x, y;

    puts( "Bitte zwei Integerzahlen eingeben:" );
    scanf( "%d %d\n", &x, &y );
    temp = 0x25;
    /*
     * Der Debugger wird das Programm an dieser Stelle unterbrechen,
     * falls Sie es mit dem Kommando "J@temp.w<>$10" gestartet haben.
     */
    SumMulFac( x, y );

    puts( "Bitte <RETURN> dr�cken" );
    getchar();
    return( 0 );
}
