/* Ausgabeprogramm */
#include <d:\turbo_c\include\string.h>;
#include <d:\turbo_c\include\stdio.h>;
int zahl;
char string[10];

void main()
{
  printf("Geben sie bitte eine Zahl ein:");
  scanf("%d",&zahl);
  strcpy(string,"Zahl");
  printf(" %s %d",string,zahl);
  scanf("\n %s",string);
  
}
