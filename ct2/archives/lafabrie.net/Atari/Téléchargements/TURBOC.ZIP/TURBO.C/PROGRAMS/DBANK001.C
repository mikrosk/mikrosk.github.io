/* Diskettenverwaltungsprogramm Version 0.01 */
#include <stdio.h>;
#include <string.h>;
#include <stdlib.h>;

int taste;

void main()
{
menu();
}

menu()
{
  printf("\n (1) Eingabe");
  printf("\n (2) Ausgabe");
  scanf("%d",&taste);
  switch(taste)
  {
    case 1: eingabe();
    break;
    case 2: ausgabe();
    break;
    case 3: abort();
    break;
  }
}

eingabe()
{
  printf("\n Eingabe");
  scanf("%d",&taste);
 abort();
}

ausgabe()
{
  printf("\n Ausgabe");
  scanf("%d",&taste);
  abort();
}
 