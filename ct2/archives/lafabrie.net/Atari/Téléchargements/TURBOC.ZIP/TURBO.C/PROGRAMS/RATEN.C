/* Zahlenratprogramm */
#include <d:\turbo_c\include\stdio.h>;
int zahl,ratzahl,i;
void main()
{
  i=0;
  zahl=25;
  while(ratzahl != zahl)
    {printf("raten sie eine Zahl:");
    i=i+1;
    scanf("%d \n",&ratzahl);
    if(ratzahl>zahl)
      printf("kleiner \n");
    if (ratzahl<zahl)
      printf("gr��er \n");
      }
  
  printf("Super. Sie haben die Zahl in %d versuchen erraten",i);
}  
  