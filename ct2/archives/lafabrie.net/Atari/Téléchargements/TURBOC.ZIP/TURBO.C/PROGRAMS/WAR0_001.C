/* Wargame Version 0.001 von Andreas Kr�ber*/
#include <\turbo_c\include\stdio.h>
#include <\turbo_c\include\vdi.h>
#include <\turbo_c\include\aes.h>
int work_in[12],work_out[57];
int ap_id;  /*Applikationsnummer*/
int p_handle;
int handle;
int zb,zh,bb,bh;
void open_work(void)
{
ap_id=appl_init();
p_handle=graf_handle(&zb,&zh,&bb,&bh);
handle=p_handle;
}
main()
  {open_work();
  Bildplot();
  }
Bildplot()
  {
   v_gtext(handle,0,20,"Dies ist der Text");
  }
   