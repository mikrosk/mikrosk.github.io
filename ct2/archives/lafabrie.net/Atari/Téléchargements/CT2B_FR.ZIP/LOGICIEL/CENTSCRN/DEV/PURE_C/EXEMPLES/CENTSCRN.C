#include <stdio.h>
#include <string.h>
#include <dolmen.h>

/*---------------------------------------------------------
* Exemple d'utilidation de la librairie Xbios DOLMEN, pour
* CENTscreen. Attention, les exemples ci-dessous sont �
* compl�t� et surtout � v�rifier. Donc si vous avez le temps
* Testez toutes les fonctions DOLMEN, serait sympa.
*
*	David REN� & CENTEK 23/02/98 
*--------------------------------------------------------*/
VDO_PARAM ParamEcran;

void main(void)
{
VDO_PARAM Retour;
VPOS position;
int reponse;

	printf("Essai des nouvelles fonctions CENTscreen III \n");
	Vread(&ParamEcran);
	Vattrib(&ParamEcran , &Retour);
	
	printf("Handle du mode vid�o :%d \n", ParamEcran.V_Hdl);
	printf("    Largeur physique :%d \n", ParamEcran.V_physw);
	printf("    Hauteur physique :%d \n", ParamEcran.V_physh);
	printf("      Nombre de plan :%d \n", ParamEcran.V_plan);
	printf("   Largeur virtuelle :%d \n", ParamEcran.V_logw);
	printf("   Hauteur virtuelle :%d \n", ParamEcran.V_logh);
	printf("   D�lais pour l'�co :%d \n", ParamEcran.V_eco);
	printf("   D�lais pour EStar :%d \n", ParamEcran.V_eco2);
	printf("   Nom du mode vid�o :%s \n", ParamEcran.V_name);
	printf("    Taille du buffer :%ld \n",ParamEcran.V_length);

	*(long *)&position = Voffset();
	
	printf(" Position de l'�cran virtuel X %d Y %d\n",position.x, position.y);
	
	
	reponse = Vfirst(&ParamEcran, &Retour);
	if(reponse == -1)
	{
		printf("r�sol non trouv� \n");
	}
	else
	{
		while(reponse == 0)
		{
			printf("   Nom du mode vid�o :%s \n", Retour.V_name);
			memcpy(&ParamEcran, &Retour, sizeof(VDO_PARAM));
			reponse = Vnext(&ParamEcran, &Retour);	
		}
	}
	getchar();
	Vclose();			/* Eteint l'�cran */
	getchar();
	Vopen();			/* le Rallume */
	getchar();
	Vload();			/* Charge le DAT */
	Vsave();			/* Le sauve */
}